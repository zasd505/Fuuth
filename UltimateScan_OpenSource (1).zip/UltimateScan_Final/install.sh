#!/bin/bash
# UltimateScan - أداة فحص الثغرات الأمنية الشاملة
# سكربت التثبيت المتوافق مع Termux

# تعيين الألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# طباعة الشعار
echo -e "${CYAN}"
echo "██╗   ██╗██╗  ████████╗██╗███╗   ███╗ █████╗ ████████╗███████╗    ███████╗ ██████╗ █████╗ ███╗   ██╗"
echo "██║   ██║██║  ╚══██╔══╝██║████╗ ████║██╔══██╗╚══██╔══╝██╔════╝    ██╔════╝██╔════╝██╔══██╗████╗  ██║"
echo "██║   ██║██║     ██║   ██║██╔████╔██║███████║   ██║   █████╗      ███████╗██║     ███████║██╔██╗ ██║"
echo "██║   ██║██║     ██║   ██║██║╚██╔╝██║██╔══██║   ██║   ██╔══╝      ╚════██║██║     ██╔══██║██║╚██╗██║"
echo "╚██████╔╝███████╗██║   ██║██║ ╚═╝ ██║██║  ██║   ██║   ███████╗    ███████║╚██████╗██║  ██║██║ ╚████║"
echo " ╚═════╝ ╚══════╝╚═╝   ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝    ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝"
echo -e "${NC}"
echo -e "${YELLOW}أداة فحص الثغرات الأمنية الشاملة - الإصدار 2.0${NC}"
echo -e "${YELLOW}متوافقة مع Termux على الأجهزة المحمولة${NC}"
echo -e "${YELLOW}تدعم فحص واستغلال أكثر من 88 نوع من الثغرات الأمنية${NC}"
echo ""

# التحقق من نوع النظام
echo -e "${BLUE}[*] التحقق من نوع النظام...${NC}"
if [ -d "/data/data/com.termux" ]; then
    echo -e "${GREEN}[+] تم اكتشاف Termux${NC}"
    IS_TERMUX=true
    PREFIX="/data/data/com.termux/files/usr"
else
    echo -e "${GREEN}[+] تم اكتشاف نظام Linux${NC}"
    IS_TERMUX=false
    PREFIX="/usr"
fi

# التحقق من وجود Python
echo -e "${BLUE}[*] التحقق من وجود Python...${NC}"
if command -v python3 &>/dev/null; then
    echo -e "${GREEN}[+] Python موجود${NC}"
else
    echo -e "${YELLOW}[!] Python غير موجود، جاري التثبيت...${NC}"
    if [ "$IS_TERMUX" = true ]; then
        pkg update -y
        pkg install -y python
    else
        if command -v apt &>/dev/null; then
            sudo apt update
            sudo apt install -y python3 python3-pip
        elif command -v dnf &>/dev/null; then
            sudo dnf install -y python3 python3-pip
        elif command -v yum &>/dev/null; then
            sudo yum install -y python3 python3-pip
        elif command -v pacman &>/dev/null; then
            sudo pacman -Sy python python-pip
        else
            echo -e "${RED}[-] لا يمكن تثبيت Python تلقائيًا، يرجى تثبيته يدويًا${NC}"
            exit 1
        fi
    fi
fi

# تثبيت المتطلبات
echo -e "${BLUE}[*] تثبيت المتطلبات...${NC}"
if [ "$IS_TERMUX" = true ]; then
    pkg update -y
    pkg install -y python nmap git openssl curl wget libxml2 libxslt
    pip install requests beautifulsoup4 lxml jinja2 python-nmap paramiko colorama tqdm
else
    if command -v apt &>/dev/null; then
        sudo apt update
        sudo apt install -y python3-pip nmap git openssl curl wget libxml2-dev libxslt-dev
    elif command -v dnf &>/dev/null; then
        sudo dnf install -y python3-pip nmap git openssl curl wget libxml2-devel libxslt-devel
    elif command -v yum &>/dev/null; then
        sudo yum install -y python3-pip nmap git openssl curl wget libxml2-devel libxslt-devel
    elif command -v pacman &>/dev/null; then
        sudo pacman -Sy python-pip nmap git openssl curl wget libxml2 libxslt
    fi
    pip3 install requests beautifulsoup4 lxml jinja2 python-nmap paramiko colorama tqdm
fi

# إنشاء الدليل الرئيسي
echo -e "${BLUE}[*] إنشاء الدليل الرئيسي...${NC}"
if [ "$IS_TERMUX" = true ]; then
    INSTALL_DIR="$PREFIX/share/ultimatescan"
    BIN_DIR="$PREFIX/bin"
else
    INSTALL_DIR="/opt/ultimatescan"
    BIN_DIR="/usr/local/bin"
fi

# إنشاء الدليل الرئيسي
if [ -d "$INSTALL_DIR" ]; then
    echo -e "${YELLOW}[!] الدليل $INSTALL_DIR موجود بالفعل، جاري الحذف...${NC}"
    if [ "$IS_TERMUX" = true ]; then
        rm -rf "$INSTALL_DIR"
    else
        sudo rm -rf "$INSTALL_DIR"
    fi
fi

# إنشاء الدليل الرئيسي
if [ "$IS_TERMUX" = true ]; then
    mkdir -p "$INSTALL_DIR"
else
    sudo mkdir -p "$INSTALL_DIR"
fi

# نسخ الملفات
echo -e "${BLUE}[*] نسخ الملفات...${NC}"
if [ "$IS_TERMUX" = true ]; then
    cp -r ./* "$INSTALL_DIR/"
    chmod +x "$INSTALL_DIR/ultimatescan.py"
else
    sudo cp -r ./* "$INSTALL_DIR/"
    sudo chmod +x "$INSTALL_DIR/ultimatescan.py"
fi

# إنشاء رابط رمزي
echo -e "${BLUE}[*] إنشاء رابط رمزي...${NC}"
if [ "$IS_TERMUX" = true ]; then
    if [ -f "$BIN_DIR/ultimatescan" ]; then
        rm "$BIN_DIR/ultimatescan"
    fi
    echo '#!/bin/sh' > "$BIN_DIR/ultimatescan"
    echo "python $INSTALL_DIR/ultimatescan.py \"\$@\"" >> "$BIN_DIR/ultimatescan"
    chmod +x "$BIN_DIR/ultimatescan"
else
    if [ -f "$BIN_DIR/ultimatescan" ]; then
        sudo rm "$BIN_DIR/ultimatescan"
    fi
    sudo bash -c "echo '#!/bin/sh' > $BIN_DIR/ultimatescan"
    sudo bash -c "echo \"python3 $INSTALL_DIR/ultimatescan.py \\\"\\\$@\\\"\" >> $BIN_DIR/ultimatescan"
    sudo chmod +x "$BIN_DIR/ultimatescan"
fi

# إنشاء دليل التقارير
echo -e "${BLUE}[*] إنشاء دليل التقارير...${NC}"
if [ "$IS_TERMUX" = true ]; then
    mkdir -p "$INSTALL_DIR/reports"
else
    sudo mkdir -p "$INSTALL_DIR/reports"
    sudo chmod 777 "$INSTALL_DIR/reports"
fi

# اكتمال التثبيت
echo -e "${GREEN}[+] تم تثبيت UltimateScan بنجاح!${NC}"
echo -e "${YELLOW}[!] يمكنك تشغيل الأداة باستخدام الأمر: ultimatescan${NC}"
echo -e "${YELLOW}[!] مثال: ultimatescan -t example.com -v${NC}"
echo -e "${YELLOW}[!] للمساعدة: ultimatescan --help${NC}"
echo ""
