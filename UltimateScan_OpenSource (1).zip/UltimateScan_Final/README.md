#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ملف README لأداة UltimateScan المحسنة
"""

# UltimateScan - أداة فحص الثغرات الأمنية الشاملة

![UltimateScan Logo](https://example.com/logo.png)

## نظرة عامة

UltimateScan هي أداة فحص الثغرات الأمنية الشاملة التي تدعم فحص واستغلال أكثر من 88 نوع من الثغرات الأمنية. الأداة متوافقة مع أنظمة Linux وTermux على الأجهزة المحمولة، مما يتيح لك إجراء اختبارات الاختراق من أي مكان.

### الميزات الرئيسية

- **فحص شامل**: يدعم أكثر من 88 نوع من الثغرات الأمنية
- **استغلال تفاعلي**: أدوات مدمجة لاستغلال الثغرات المكتشفة
- **تقارير مفصلة**: تقارير HTML تفاعلية مع رسوم بيانية وتفاصيل دقيقة
- **متوافق مع الأجهزة المحمولة**: يعمل على Termux بكفاءة عالية
- **واجهة سهلة الاستخدام**: واجهة سطر أوامر بسيطة وفعالة
- **تحديثات مستمرة**: إضافة ثغرات وأدوات استغلال جديدة باستمرار

## قائمة الثغرات المدعومة

1. SQL Injection
2. Command Injection
3. Cross-Site Scripting (XSS)
4. Cross-Site Request Forgery (CSRF)
5. Session Hijacking
6. File Upload Vulnerabilities
7. Unrestricted File Upload
8. Local/Remote File Inclusion (LFI/RFI)
9. Authentication Bypass
10. Information Disclosure
11. Denial of Service (DoS/DDoS)
12. Man-in-the-Middle (MITM)
13. Xpath Injection
14. Server-Side Request Forgery (SSRF)
15. Clickjacking
16. Broken Access Control
17. Outdated Software Vulnerabilities
18. Cache Poisoning
19. XML External Entity (XXE)
20. Cross-Site Request Forgery (CSRF)
21. LDAP Injection
22. Command Injection
23. Template Injection
24. Expression Language Injection
25. Directory Traversal
26. Insecure Direct Object References (IDOR)
27. Open Redirect
28. Security Misconfiguration
29. Sensitive Data Exposure
30. Insufficient Logging and Monitoring
31. Broken Cryptography
32. Insecure Deserialization
33. Business Logic Flaws
34. Clickjacking
35. Subdomain Takeover
36. API Security Issues
37. Race Condition
38. Buffer Overflow
39. XML Injection
40. Heap Overflow
41. Memory Corruption
42. Format String Attack
43. Side-channel Attacks
44. Password Spraying and Brute Force
45. Social Engineering
46. Zero-day Vulnerabilities
47. Remote Code Execution (RCE)
48. Privilege Escalation
49. Cloud Security Issues
50. Supply Chain Attacks
51. Mobile App Security
52. WebSocket Vulnerabilities
53. Cryptojacking
54. DNS Spoofing / DNS Hijacking
55. Click Fraud
56. Watering Hole Attack
57. Supply Chain Attacks on Open Source Software
58. Advanced Side-channel Attacks
59. Cache Timing Attack
60. Logic Bombs
61. Zero Interaction Attacks (e.g. IoT)
62. Quantum Attacks (theoretical)
63. Advanced Persistent Threats (APT)
64. Bluetooth Attacks
65. NFC Attacks
66. RFID Attacks
67. Evil Twin Attack
68. Session Fixation
69. Cookie Poisoning
70. HTTP Header Injection
71. HTTP Response Splitting
72. User Enumeration
73. HTML Injection
74. TLS/SSL Attacks
75. Malicious Redirects
76. Browser Exploits
77. Memory Leak
78. Race Condition Exploits in Blockchain
79. Data Exfiltration via Covert Channels
80. Social Media Exploits
81. Phishing Kits
82. DNS Tunneling
83. PowerShell Attacks
84. Image Metadata Attacks
85. Firmware Attacks
86. Supply Chain Compromise via Hardware
87. Out-of-Band Exploits
88. Malvertising

## متطلبات النظام

- Python 3.6 أو أحدث
- نظام Linux أو Termux على Android
- اتصال بالإنترنت لتثبيت التبعيات

### المتطلبات الإضافية لـ Termux

- تطبيق Termux محدث
- حزمة Python مثبتة
- مساحة تخزين كافية (على الأقل 500 ميجابايت)

## التثبيت

### على نظام Linux

```bash
git clone https://github.com/username/UltimateScan.git
cd UltimateScan
chmod +x install.sh
sudo ./install.sh
```

### على Termux

```bash
pkg update && pkg upgrade
pkg install git python
git clone https://github.com/username/UltimateScan.git
cd UltimateScan
chmod +x install.sh
./install.sh
```

## الاستخدام الأساسي

### فحص هدف واحد

```bash
ultimatescan -t example.com -v
```

### فحص قائمة من الأهداف

```bash
ultimatescan -f targets.txt -v
```

### تحديد منافذ معينة

```bash
ultimatescan -t example.com -p 80,443,8080 -v
```

### إنشاء تقرير بتنسيق معين

```bash
ultimatescan -t example.com -r html -o report.html -v
```

## خيارات سطر الأوامر

```
الاستخدام: ultimatescan.py [-h] [-t TARGET] [-f FILE] [-p PORTS] [-m MODULES] [-a] [-o OUTPUT] [-r {html,json,text}] [-v] [--version]

UltimateScan - أداة فحص الثغرات الأمنية الشاملة

خيارات:
  -h, --help            عرض رسالة المساعدة هذه والخروج
  -v, --verbose         عرض معلومات مفصلة
  --version             عرض رقم الإصدار والخروج

الهدف:
  -t TARGET, --target TARGET
                        هدف الفحص (عنوان IP أو اسم مضيف)
  -f FILE, --file FILE  ملف يحتوي على قائمة بالأهداف (سطر لكل هدف)

الفحص:
  -p PORTS, --ports PORTS
                        المنافذ للفحص (مثال: 80,443,8080)
  -m MODULES, --modules MODULES
                        وحدات الفحص للاستخدام (مثال: web,network,api)
  -a, --all             استخدام جميع وحدات الفحص

التقرير:
  -o OUTPUT, --output OUTPUT
                        ملف الإخراج للتقرير
  -r {html,json,text}, --report-type {html,json,text}
                        نوع التقرير
```

## نصائح لاستخدام الأداة على Termux

1. **تحديث Termux**: تأكد من تحديث Termux قبل التثبيت:
   ```bash
   pkg update && pkg upgrade
   ```

2. **منح الأذونات**: قد تحتاج إلى منح أذونات الوصول للتخزين:
   ```bash
   termux-setup-storage
   ```

3. **حل مشاكل الذاكرة**: إذا واجهت مشاكل في الذاكرة، يمكنك تعديل ملف `ultimatescan.py` لتقليل استهلاك الموارد.

4. **استخدام شاشة افتراضية**: للتشغيل في الخلفية، استخدم:
   ```bash
   pkg install tmux
   tmux
   # ثم قم بتشغيل الأداة
   # للانفصال: CTRL+B ثم D
   # للاتصال مرة أخرى: tmux attach
   ```

## استكشاف الأخطاء وإصلاحها

### مشاكل التثبيت

- **خطأ في تثبيت المكتبات**: تأكد من تحديث pip:
  ```bash
  pip install --upgrade pip
  ```

- **مشاكل الأذونات**: استخدم `sudo` على Linux أو تأكد من تثبيت الحزم الأساسية على Termux:
  ```bash
  pkg install python-dev clang libffi-dev openssl-dev
  ```

### مشاكل التشغيل

- **بطء الفحص**: قلل عدد الوحدات المستخدمة أو المنافذ المفحوصة.
- **أخطاء الاتصال**: تأكد من اتصالك بالإنترنت واستخدم `-v` لمزيد من المعلومات.
- **تعطل الأداة**: تحقق من سجلات الأخطاء في مجلد `logs/`.

## المساهمة

نرحب بالمساهمات! إذا كنت ترغب في المساهمة، يرجى اتباع الخطوات التالية:

1. Fork المستودع
2. إنشاء فرع للميزة الجديدة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add some amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## الترخيص

هذا المشروع مرخص تحت رخصة MIT - انظر ملف [LICENSE](LICENSE) للتفاصيل.

## إخلاء المسؤولية

هذه الأداة مخصصة للاستخدام في اختبارات الاختراق القانونية وتقييم الأمان فقط. المؤلف غير مسؤول عن أي استخدام غير قانوني أو غير مصرح به لهذه الأداة.

## الاتصال

- المؤلف: [اسم المؤلف]
- البريد الإلكتروني: [البريد الإلكتروني]
- Twitter: [@username]
- GitHub: [username]

---

شكراً لاستخدام UltimateScan! نأمل أن تساعدك هذه الأداة في تحسين أمان أنظمتك ومواقعك.
