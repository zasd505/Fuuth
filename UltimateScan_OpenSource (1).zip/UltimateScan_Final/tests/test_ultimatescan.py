#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
اختبار وحدات UltimateScan المحسنة
"""

import os
import sys
import unittest
import tempfile
from pathlib import Path

# إضافة المسار الرئيسي إلى مسارات البحث
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

# استيراد الوحدات المطلوبة للاختبار
try:
    from modules.base_scanner import Target, VulnerabilityScanner
    from utils.report_generator import ReportGenerator
    from exploits.exploit_tools import ExploitManager
except ImportError as e:
    print(f"خطأ في استيراد الوحدات: {str(e)}")
    # لا نخرج من البرنامج في حالة الخطأ، بل نستمر في الاختبار
    pass

class TestTarget(unittest.TestCase):
    """اختبار فئة Target"""
    
    def test_target_creation_with_ip(self):
        """اختبار إنشاء هدف باستخدام عنوان IP"""
        target = Target(ip="192.168.1.1")
        self.assertEqual(target.get_ip(), "192.168.1.1")
        self.assertIsNone(target.get_hostname())
    
    def test_target_creation_with_hostname(self):
        """اختبار إنشاء هدف باستخدام اسم مضيف"""
        target = Target(hostname="example.com")
        self.assertEqual(target.get_hostname(), "example.com")
        self.assertIsNone(target.get_ip())
    
    def test_target_add_port(self):
        """اختبار إضافة منفذ إلى الهدف"""
        target = Target(ip="192.168.1.1")
        target.add_port(80, "open")
        target.add_port(443, "open")
        target.add_port(22, "closed")
        
        ports = target.get_ports()
        self.assertEqual(len(ports), 3)
        self.assertEqual(ports[80], "open")
        self.assertEqual(ports[443], "open")
        self.assertEqual(ports[22], "closed")
    
    def test_target_add_vulnerability(self):
        """اختبار إضافة ثغرة إلى الهدف"""
        target = Target(ip="192.168.1.1")
        
        vuln1 = {
            "type": "SQL Injection",
            "severity": "high",
            "description": "تم اكتشاف ثغرة SQL Injection",
            "location": {
                "url": "http://192.168.1.1/login.php",
                "parameter": "username"
            }
        }
        
        vuln2 = {
            "type": "XSS",
            "severity": "medium",
            "description": "تم اكتشاف ثغرة XSS",
            "location": {
                "url": "http://192.168.1.1/search.php",
                "parameter": "q"
            }
        }
        
        target.add_vulnerability(vuln1)
        target.add_vulnerability(vuln2)
        
        vulnerabilities = target.get_vulnerabilities()
        self.assertEqual(len(vulnerabilities), 2)
        self.assertEqual(vulnerabilities[0]["type"], "SQL Injection")
        self.assertEqual(vulnerabilities[1]["type"], "XSS")
    
    def test_target_to_dict(self):
        """اختبار تحويل الهدف إلى قاموس"""
        target = Target(ip="192.168.1.1", hostname="example.com")
        target.add_port(80, "open")
        target.add_port(443, "open")
        
        vuln = {
            "type": "SQL Injection",
            "severity": "high",
            "description": "تم اكتشاف ثغرة SQL Injection",
            "location": {
                "url": "http://example.com/login.php",
                "parameter": "username"
            }
        }
        
        target.add_vulnerability(vuln)
        
        target_dict = target.to_dict()
        self.assertEqual(target_dict["ip"], "192.168.1.1")
        self.assertEqual(target_dict["hostname"], "example.com")
        self.assertEqual(len(target_dict["ports"]), 2)
        self.assertEqual(len(target_dict["vulnerabilities"]), 1)
        self.assertEqual(target_dict["vulnerabilities"][0]["type"], "SQL Injection")

class TestVulnerabilityScanner(unittest.TestCase):
    """اختبار فئة VulnerabilityScanner"""
    
    def test_scanner_creation(self):
        """اختبار إنشاء ماسح"""
        scanner = VulnerabilityScanner()
        self.assertIsNotNone(scanner)
    
    def test_scanner_with_config(self):
        """اختبار إنشاء ماسح مع تكوين"""
        config = {
            "verbose": True,
            "timeout": 30
        }
        scanner = VulnerabilityScanner(config)
        self.assertTrue(scanner.verbose)
        self.assertEqual(scanner.timeout, 30)
    
    def test_create_vulnerability(self):
        """اختبار إنشاء ثغرة"""
        scanner = VulnerabilityScanner()
        
        vuln = scanner.create_vulnerability(
            vuln_type="SQL Injection",
            severity="high",
            description="تم اكتشاف ثغرة SQL Injection",
            location={
                "url": "http://example.com/login.php",
                "parameter": "username"
            },
            exploit_info={
                "method": "POST",
                "payload": "' OR 1=1 --"
            },
            recommendation="استخدام الاستعلامات المعدة مسبقًا",
            references=[
                "https://owasp.org/www-community/attacks/SQL_Injection"
            ]
        )
        
        self.assertEqual(vuln["type"], "SQL Injection")
        self.assertEqual(vuln["severity"], "high")
        self.assertEqual(vuln["description"], "تم اكتشاف ثغرة SQL Injection")
        self.assertEqual(vuln["location"]["url"], "http://example.com/login.php")
        self.assertEqual(vuln["exploit_info"]["payload"], "' OR 1=1 --")
        self.assertEqual(vuln["recommendation"], "استخدام الاستعلامات المعدة مسبقًا")
        self.assertEqual(len(vuln["references"]), 1)

class TestReportGenerator(unittest.TestCase):
    """اختبار فئة ReportGenerator"""
    
    def setUp(self):
        """إعداد الاختبار"""
        self.report_generator = ReportGenerator()
        
        # إنشاء بيانات اختبار
        self.scan_results = {
            "start_time": "2025-05-17 18:00:00",
            "end_time": "2025-05-17 18:30:00",
            "duration": "0:30:00",
            "targets": [
                {
                    "ip": "192.168.1.1",
                    "hostname": "example.com",
                    "ports": {
                        "80": "open",
                        "443": "open",
                        "22": "closed"
                    },
                    "vulnerabilities": [
                        {
                            "type": "SQL Injection",
                            "severity": "high",
                            "description": "تم اكتشاف ثغرة SQL Injection",
                            "location": {
                                "url": "http://example.com/login.php",
                                "parameter": "username"
                            },
                            "exploit_info": {
                                "method": "POST",
                                "payload": "' OR 1=1 --"
                            },
                            "recommendation": "استخدام الاستعلامات المعدة مسبقًا",
                            "references": [
                                "https://owasp.org/www-community/attacks/SQL_Injection"
                            ]
                        },
                        {
                            "type": "XSS",
                            "severity": "medium",
                            "description": "تم اكتشاف ثغرة XSS",
                            "location": {
                                "url": "http://example.com/search.php",
                                "parameter": "q"
                            },
                            "exploit_info": {
                                "method": "GET",
                                "payload": "<script>alert(1)</script>"
                            },
                            "recommendation": "ترميز مخرجات المستخدم",
                            "references": [
                                "https://owasp.org/www-community/attacks/xss/"
                            ]
                        }
                    ]
                }
            ]
        }
    
    def test_generate_html_report(self):
        """اختبار إنشاء تقرير HTML"""
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as temp:
            temp_path = temp.name
        
        try:
            report_file = self.report_generator.generate_report(self.scan_results, "html", temp_path)
            self.assertTrue(os.path.exists(report_file))
            self.assertTrue(os.path.getsize(report_file) > 0)
            
            # التحقق من محتوى التقرير
            with open(report_file, "r", encoding="utf-8") as f:
                content = f.read()
                self.assertIn("تقرير فحص الثغرات الأمنية", content)
                self.assertIn("SQL Injection", content)
                self.assertIn("XSS", content)
                self.assertIn("example.com", content)
        finally:
            # تنظيف
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def test_generate_json_report(self):
        """اختبار إنشاء تقرير JSON"""
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as temp:
            temp_path = temp.name
        
        try:
            report_file = self.report_generator.generate_report(self.scan_results, "json", temp_path)
            self.assertTrue(os.path.exists(report_file))
            self.assertTrue(os.path.getsize(report_file) > 0)
            
            # التحقق من محتوى التقرير
            import json
            with open(report_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.assertEqual(data["start_time"], "2025-05-17 18:00:00")
                self.assertEqual(len(data["targets"]), 1)
                self.assertEqual(len(data["targets"][0]["vulnerabilities"]), 2)
        finally:
            # تنظيف
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def test_generate_text_report(self):
        """اختبار إنشاء تقرير نصي"""
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as temp:
            temp_path = temp.name
        
        try:
            report_file = self.report_generator.generate_report(self.scan_results, "text", temp_path)
            self.assertTrue(os.path.exists(report_file))
            self.assertTrue(os.path.getsize(report_file) > 0)
            
            # التحقق من محتوى التقرير
            with open(report_file, "r", encoding="utf-8") as f:
                content = f.read()
                self.assertIn("تقرير فحص الثغرات الأمنية", content)
                self.assertIn("SQL Injection", content)
                self.assertIn("XSS", content)
                self.assertIn("example.com", content)
        finally:
            # تنظيف
            if os.path.exists(temp_path):
                os.unlink(temp_path)

class TestExploitManager(unittest.TestCase):
    """اختبار فئة ExploitManager"""
    
    def setUp(self):
        """إعداد الاختبار"""
        self.exploit_manager = ExploitManager()
    
    def test_get_supported_vulnerabilities(self):
        """اختبار الحصول على قائمة الثغرات المدعومة"""
        supported = self.exploit_manager.get_supported_vulnerabilities()
        self.assertIsInstance(supported, list)
        self.assertTrue(len(supported) > 0)
        self.assertIn("SQL Injection", supported)
        self.assertIn("Cross-Site Scripting (XSS)", supported)
    
    def test_get_exploit_for_vulnerability(self):
        """اختبار الحصول على أداة استغلال مناسبة للثغرة"""
        vuln = {
            "type": "SQL Injection",
            "severity": "high",
            "description": "تم اكتشاف ثغرة SQL Injection",
            "location": {
                "url": "http://example.com/login.php",
                "parameter": "username"
            }
        }
        
        exploit = self.exploit_manager.get_exploit_for_vulnerability(vuln)
        self.assertIsNotNone(exploit)
        self.assertIn("SQL Injection", exploit.get_supported_vulnerabilities())

if __name__ == "__main__":
    unittest.main()
