#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة إنشاء التقارير
تتضمن فئات وأدوات إنشاء تقارير ملونة وتفاعلية
"""

import os
import json
import datetime
import webbrowser
import platform
import subprocess
from pathlib import Path

class ReportGenerator:
    """فئة إنشاء التقارير"""
    
    def __init__(self, config=None):
        """تهيئة منشئ التقارير"""
        self.config = config or {}
        self.verbose = self.config.get('verbose', False)
        
        # تحديد مسار مجلد التقارير
        self.reports_dir = self.config.get('reports_dir', os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'reports'))
        
        # إنشاء مجلد التقارير إذا لم يكن موجودًا
        os.makedirs(self.reports_dir, exist_ok=True)
    
    def generate_report(self, scan_results, report_type='html', output_file=None):
        """إنشاء تقرير"""
        if not output_file:
            timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = os.path.join(self.reports_dir, f"report_{timestamp}.{report_type}")
        else:
            # إذا كان المسار نسبيًا، أضفه إلى مجلد التقارير
            if not os.path.isabs(output_file):
                output_file = os.path.join(self.reports_dir, output_file)
        
        # إنشاء مجلد التقارير إذا لم يكن موجودًا
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        if report_type == 'html':
            self._generate_html_report(scan_results, output_file)
        elif report_type == 'json':
            self._generate_json_report(scan_results, output_file)
        elif report_type == 'text':
            self._generate_text_report(scan_results, output_file)
        else:
            raise ValueError(f"نوع التقرير غير مدعوم: {report_type}")
        
        return output_file
    
    def _generate_html_report(self, scan_results, output_file):
        """إنشاء تقرير HTML"""
        # قالب HTML
        html_template = """<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير فحص الثغرات الأمنية - UltimateScan</title>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --info-color: #3498db;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --text-color: #333;
            --background-color: #f8f9fa;
            --card-background: #fff;
            --border-color: #ddd;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
        }
        
        .header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 700;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
            position: relative;
        }
        
        .header p {
            margin: 10px 0 0;
            font-size: 16px;
            opacity: 0.9;
            position: relative;
        }
        
        .summary {
            background-color: var(--card-background);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        
        .summary h2 {
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 10px;
            font-size: 22px;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .summary-item {
            background-color: var(--light-color);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .summary-item:hover {
            transform: translateY(-5px);
        }
        
        .summary-item h3 {
            margin: 0;
            font-size: 16px;
            color: var(--dark-color);
        }
        
        .summary-item p {
            margin: 10px 0 0;
            font-size: 24px;
            font-weight: bold;
            color: var(--secondary-color);
        }
        
        .chart-container {
            background-color: var(--card-background);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        
        .chart-container h2 {
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 10px;
            font-size: 22px;
        }
        
        .chart-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .chart {
            height: 300px;
            position: relative;
        }
        
        .target {
            background-color: var(--card-background);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease;
        }
        
        .target:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .target h2 {
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 10px;
            font-size: 22px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .target-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .target-info-item {
            background-color: var(--light-color);
            padding: 15px;
            border-radius: 8px;
        }
        
        .target-info-item h3 {
            margin: 0;
            font-size: 16px;
            color: var(--dark-color);
        }
        
        .target-info-item p {
            margin: 10px 0 0;
            font-size: 16px;
            color: var(--secondary-color);
            word-break: break-all;
        }
        
        .ports {
            margin-top: 20px;
        }
        
        .ports h3 {
            margin-top: 0;
            color: var(--primary-color);
            font-size: 18px;
        }
        
        .ports-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 10px;
            margin-top: 10px;
        }
        
        .port {
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }
        
        .port.open {
            background-color: var(--success-color);
            color: white;
        }
        
        .port.closed {
            background-color: var(--danger-color);
            color: white;
        }
        
        .port.filtered {
            background-color: var(--warning-color);
            color: white;
        }
        
        .vulnerabilities {
            margin-top: 20px;
        }
        
        .vulnerabilities h3 {
            margin-top: 0;
            color: var(--primary-color);
            font-size: 18px;
        }
        
        .vulnerability {
            background-color: var(--light-color);
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            border-right: 5px solid;
            transition: transform 0.3s ease;
        }
        
        .vulnerability:hover {
            transform: translateX(-5px);
        }
        
        .vulnerability.high {
            border-right-color: var(--danger-color);
        }
        
        .vulnerability.medium {
            border-right-color: var(--warning-color);
        }
        
        .vulnerability.low {
            border-right-color: var(--info-color);
        }
        
        .vulnerability h4 {
            margin: 0;
            font-size: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .vulnerability-severity {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            color: white;
        }
        
        .vulnerability-severity.high {
            background-color: var(--danger-color);
        }
        
        .vulnerability-severity.medium {
            background-color: var(--warning-color);
        }
        
        .vulnerability-severity.low {
            background-color: var(--info-color);
        }
        
        .vulnerability-details {
            margin-top: 15px;
        }
        
        .vulnerability-detail {
            margin-bottom: 10px;
        }
        
        .vulnerability-detail h5 {
            margin: 0 0 5px;
            font-size: 14px;
            color: var(--dark-color);
        }
        
        .vulnerability-detail p {
            margin: 0;
            font-size: 14px;
            word-break: break-all;
        }
        
        .vulnerability-location {
            background-color: rgba(0, 0, 0, 0.05);
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-family: monospace;
            overflow-x: auto;
        }
        
        .vulnerability-exploit {
            margin-top: 15px;
        }
        
        .exploit-button {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        
        .exploit-button:hover {
            background-color: #c0392b;
        }
        
        .vulnerability-references {
            margin-top: 15px;
        }
        
        .vulnerability-references h5 {
            margin: 0 0 5px;
            font-size: 14px;
            color: var(--dark-color);
        }
        
        .vulnerability-references ul {
            margin: 0;
            padding-right: 20px;
        }
        
        .vulnerability-references li {
            margin-bottom: 5px;
        }
        
        .vulnerability-references a {
            color: var(--secondary-color);
            text-decoration: none;
        }
        
        .vulnerability-references a:hover {
            text-decoration: underline;
        }
        
        .footer {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            text-align: center;
        }
        
        .footer p {
            margin: 0;
        }
        
        .footer a {
            color: var(--light-color);
            text-decoration: none;
        }
        
        .footer a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            
            .header {
                padding: 15px;
            }
            
            .header h1 {
                font-size: 24px;
            }
            
            .summary-grid, .chart-grid, .target-info {
                grid-template-columns: 1fr;
            }
            
            .ports-grid {
                grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
            }
        }
        
        /* تأثيرات حركية */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .pulse {
            animation: pulse 2s infinite;
        }
        
        /* تبديل الوضع المظلم/الفاتح */
        .theme-switch {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: background-color 0.3s ease;
        }
        
        .theme-switch:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }
        
        body.dark-theme {
            --background-color: #1a1a2e;
            --card-background: #16213e;
            --text-color: #e6e6e6;
            --light-color: #0f3460;
            --border-color: #2a2a4a;
        }
        
        body.dark-theme .summary-item {
            background-color: #0f3460;
            color: #e6e6e6;
        }
        
        body.dark-theme .summary-item h3 {
            color: #e6e6e6;
        }
        
        body.dark-theme .target-info-item {
            background-color: #0f3460;
        }
        
        body.dark-theme .target-info-item h3 {
            color: #e6e6e6;
        }
        
        body.dark-theme .vulnerability {
            background-color: #0f3460;
        }
        
        /* طباعة التقرير */
        @media print {
            body {
                background-color: white;
                color: black;
            }
            
            .container {
                max-width: 100%;
                padding: 0;
            }
            
            .header, .footer {
                background: none;
                color: black;
                padding: 10px 0;
                box-shadow: none;
            }
            
            .header::before {
                display: none;
            }
            
            .theme-switch, .exploit-button {
                display: none;
            }
            
            .summary, .chart-container, .target {
                box-shadow: none;
                margin-bottom: 30px;
                break-inside: avoid;
            }
            
            .vulnerability {
                break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <button class="theme-switch" id="themeSwitch">🌓</button>
        
        <div class="header">
            <h1>تقرير فحص الثغرات الأمنية</h1>
            <p>تم إنشاؤه بواسطة UltimateScan (مفتوح المصدر) - الإصدار 2.1</p>
        </div>
        
        <div class="summary">
            <h2>ملخص الفحص</h2>
            <div class="summary-grid">
                <div class="summary-item">
                    <h3>تاريخ الفحص</h3>
                    <p>{{scan_date}}</p>
                </div>
                <div class="summary-item">
                    <h3>مدة الفحص</h3>
                    <p>{{scan_duration}}</p>
                </div>
                <div class="summary-item">
                    <h3>عدد الأهداف</h3>
                    <p>{{targets_count}}</p>
                </div>
                <div class="summary-item">
                    <h3>إجمالي الثغرات</h3>
                    <p>{{total_vulnerabilities}}</p>
                </div>
                <div class="summary-item">
                    <h3>ثغرات عالية الخطورة</h3>
                    <p class="pulse" style="color: var(--danger-color);">{{high_vulnerabilities}}</p>
                </div>
                <div class="summary-item">
                    <h3>ثغرات متوسطة الخطورة</h3>
                    <p style="color: var(--warning-color);">{{medium_vulnerabilities}}</p>
                </div>
                <div class="summary-item">
                    <h3>ثغرات منخفضة الخطورة</h3>
                    <p style="color: var(--info-color);">{{low_vulnerabilities}}</p>
                </div>
            </div>
        </div>
        
        <div class="chart-container">
            <h2>الرسوم البيانية</h2>
            <div class="chart-grid">
                <div class="chart">
                    <canvas id="severityChart"></canvas>
                </div>
                <div class="chart">
                    <canvas id="vulnerabilityTypesChart"></canvas>
                </div>
            </div>
        </div>
        
        {{targets_html}}
        
        <div class="footer">
            <p>© {{current_year}} UltimateScan - أداة مفتوحة المصدر تحت رخصة MIT</p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // تبديل الوضع المظلم/الفاتح
        document.getElementById('themeSwitch').addEventListener('click', function() {
            document.body.classList.toggle('dark-theme');
            localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
        });
        
        // استعادة الوضع المفضل
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-theme');
        }
        
        // إنشاء الرسوم البيانية
        document.addEventListener('DOMContentLoaded', function() {
            // مخطط توزيع الخطورة
            const severityCtx = document.getElementById('severityChart').getContext('2d');
            const severityChart = new Chart(severityCtx, {
                type: 'pie',
                data: {
                    labels: ['عالية', 'متوسطة', 'منخفضة'],
                    datasets: [{
                        data: [{{high_vulnerabilities}}, {{medium_vulnerabilities}}, {{low_vulnerabilities}}],
                        backgroundColor: ['#e74c3c', '#f39c12', '#3498db'],
                        borderColor: ['#c0392b', '#d35400', '#2980b9'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        title: {
                            display: true,
                            text: 'توزيع الثغرات حسب الخطورة'
                        }
                    }
                }
            });
            
            // مخطط أنواع الثغرات
            const typesCtx = document.getElementById('vulnerabilityTypesChart').getContext('2d');
            const typesChart = new Chart(typesCtx, {
                type: 'bar',
                data: {
                    labels: {{vulnerability_types_labels}},
                    datasets: [{
                        label: 'عدد الثغرات',
                        data: {{vulnerability_types_data}},
                        backgroundColor: '#3498db',
                        borderColor: '#2980b9',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        },
                        title: {
                            display: true,
                            text: 'أنواع الثغرات المكتشفة'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
        });
        
        // توسيع/طي تفاصيل الثغرات
        document.querySelectorAll('.vulnerability h4').forEach(header => {
            header.addEventListener('click', function() {
                const details = this.nextElementSibling;
                if (details.style.display === 'none') {
                    details.style.display = 'block';
                    this.querySelector('.toggle-icon').textContent = '▼';
                } else {
                    details.style.display = 'none';
                    this.querySelector('.toggle-icon').textContent = '►';
                }
            });
        });
    </script>
</body>
</html>
"""
        
        # حساب إحصائيات الثغرات
        high_vulnerabilities = 0
        medium_vulnerabilities = 0
        low_vulnerabilities = 0
        total_vulnerabilities = 0
        vulnerability_types = {}
        
        for target in scan_results.get('targets', []):
            for vuln in target.get('vulnerabilities', []):
                total_vulnerabilities += 1
                
                severity = vuln.get('severity', '').lower()
                if severity == 'high':
                    high_vulnerabilities += 1
                elif severity == 'medium':
                    medium_vulnerabilities += 1
                else:
                    low_vulnerabilities += 1
                
                vuln_type = vuln.get('type', 'غير معروف')
                if vuln_type in vulnerability_types:
                    vulnerability_types[vuln_type] += 1
                else:
                    vulnerability_types[vuln_type] = 1
        
        # إنشاء HTML للأهداف
        targets_html = ""
        for target in scan_results.get('targets', []):
            target_html = f"""
            <div class="target">
                <h2>
                    {target.get('hostname') or target.get('ip', 'هدف غير معروف')}
                    <span style="font-size: 14px; color: var(--secondary-color);">{target.get('ip', '')}</span>
                </h2>
                
                <div class="target-info">
                    <div class="target-info-item">
                        <h3>اسم المضيف</h3>
                        <p>{target.get('hostname', 'غير متاح')}</p>
                    </div>
                    <div class="target-info-item">
                        <h3>عنوان IP</h3>
                        <p>{target.get('ip', 'غير متاح')}</p>
                    </div>
                    <div class="target-info-item">
                        <h3>عدد الثغرات</h3>
                        <p>{len(target.get('vulnerabilities', []))}</p>
                    </div>
                </div>
            """
            
            # إضافة المنافذ
            ports = target.get('ports', {})
            if ports:
                target_html += """
                <div class="ports">
                    <h3>المنافذ المفتوحة</h3>
                    <div class="ports-grid">
                """
                
                for port, status in ports.items():
                    status_class = status.lower() if status.lower() in ['open', 'closed', 'filtered'] else 'filtered'
                    target_html += f"""
                    <div class="port {status_class}">
                        {port}
                    </div>
                    """
                
                target_html += """
                    </div>
                </div>
                """
            
            # إضافة الثغرات
            vulnerabilities = target.get('vulnerabilities', [])
            if vulnerabilities:
                target_html += """
                <div class="vulnerabilities">
                    <h3>الثغرات المكتشفة</h3>
                """
                
                for vuln in vulnerabilities:
                    severity = vuln.get('severity', 'low').lower()
                    severity_class = severity if severity in ['high', 'medium', 'low'] else 'low'
                    severity_text = {
                        'high': 'عالية',
                        'medium': 'متوسطة',
                        'low': 'منخفضة'
                    }.get(severity, 'منخفضة')
                    
                    target_html += f"""
                    <div class="vulnerability {severity_class}">
                        <h4>
                            {vuln.get('type', 'ثغرة غير معروفة')}
                            <span class="vulnerability-severity {severity_class}">{severity_text}</span>
                            <span class="toggle-icon">►</span>
                        </h4>
                        <div class="vulnerability-details" style="display: none;">
                            <div class="vulnerability-detail">
                                <h5>الوصف</h5>
                                <p>{vuln.get('description', 'لا يوجد وصف متاح')}</p>
                            </div>
                    """
                    
                    # إضافة موقع الثغرة
                    location = vuln.get('location', {})
                    if location:
                        target_html += """
                        <div class="vulnerability-detail">
                            <h5>الموقع</h5>
                            <div class="vulnerability-location">
                        """
                        
                        for key, value in location.items():
                            target_html += f"<div><strong>{key}:</strong> {value}</div>"
                        
                        target_html += """
                            </div>
                        </div>
                        """
                    
                    # إضافة معلومات الاستغلال
                    exploit_info = vuln.get('exploit_info', {})
                    if exploit_info:
                        target_html += """
                        <div class="vulnerability-exploit">
                            <h5>معلومات الاستغلال</h5>
                            <div class="vulnerability-location">
                        """
                        
                        for key, value in exploit_info.items():
                            target_html += f"<div><strong>{key}:</strong> {value}</div>"
                        
                        target_html += """
                            </div>
                            <button class="exploit-button" onclick="alert('ميزة الاستغلال متاحة فقط في واجهة سطر الأوامر')">استغلال الثغرة</button>
                        </div>
                        """
                    
                    # إضافة التوصيات
                    recommendation = vuln.get('recommendation')
                    if recommendation:
                        target_html += f"""
                        <div class="vulnerability-detail">
                            <h5>التوصيات</h5>
                            <p>{recommendation}</p>
                        </div>
                        """
                    
                    # إضافة المراجع
                    references = vuln.get('references', [])
                    if references:
                        target_html += """
                        <div class="vulnerability-references">
                            <h5>المراجع</h5>
                            <ul>
                        """
                        
                        for ref in references:
                            target_html += f"<li><a href='{ref}' target='_blank'>{ref}</a></li>"
                        
                        target_html += """
                            </ul>
                        </div>
                        """
                    
                    target_html += """
                        </div>
                    </div>
                    """
                
                target_html += """
                </div>
                """
            
            target_html += """
            </div>
            """
            
            targets_html += target_html
        
        # تحضير بيانات الرسوم البيانية
        vulnerability_types_labels = json.dumps(list(vulnerability_types.keys()))
        vulnerability_types_data = json.dumps(list(vulnerability_types.values()))
        
        # استبدال المتغيرات في القالب
        html_content = html_template.replace('{{scan_date}}', scan_results.get('start_time', 'غير متاح'))
        html_content = html_content.replace('{{scan_duration}}', scan_results.get('duration', 'غير متاح'))
        html_content = html_content.replace('{{targets_count}}', str(len(scan_results.get('targets', []))))
        html_content = html_content.replace('{{total_vulnerabilities}}', str(total_vulnerabilities))
        html_content = html_content.replace('{{high_vulnerabilities}}', str(high_vulnerabilities))
        html_content = html_content.replace('{{medium_vulnerabilities}}', str(medium_vulnerabilities))
        html_content = html_content.replace('{{low_vulnerabilities}}', str(low_vulnerabilities))
        html_content = html_content.replace('{{vulnerability_types_labels}}', vulnerability_types_labels)
        html_content = html_content.replace('{{vulnerability_types_data}}', vulnerability_types_data)
        html_content = html_content.replace('{{targets_html}}', targets_html)
        html_content = html_content.replace('{{current_year}}', str(datetime.datetime.now().year))
        
        # كتابة التقرير إلى ملف
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    def _generate_json_report(self, scan_results, output_file):
        """إنشاء تقرير JSON"""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(scan_results, f, ensure_ascii=False, indent=4)
    
    def _generate_text_report(self, scan_results, output_file):
        """إنشاء تقرير نصي"""
        text_content = "تقرير فحص الثغرات الأمنية - UltimateScan\n"
        text_content += "=" * 50 + "\n\n"
        
        # معلومات الفحص
        text_content += "معلومات الفحص:\n"
        text_content += "-" * 20 + "\n"
        text_content += f"تاريخ البدء: {scan_results.get('start_time', 'غير متاح')}\n"
        text_content += f"تاريخ الانتهاء: {scan_results.get('end_time', 'غير متاح')}\n"
        text_content += f"المدة: {scan_results.get('duration', 'غير متاح')}\n"
        text_content += f"عدد الأهداف: {len(scan_results.get('targets', []))}\n\n"
        
        # الأهداف
        for target_index, target in enumerate(scan_results.get('targets', [])):
            text_content += f"الهدف {target_index + 1}: {target.get('hostname') or target.get('ip', 'هدف غير معروف')}\n"
            text_content += "-" * 40 + "\n"
            text_content += f"اسم المضيف: {target.get('hostname', 'غير متاح')}\n"
            text_content += f"عنوان IP: {target.get('ip', 'غير متاح')}\n"
            
            # المنافذ
            ports = target.get('ports', {})
            if ports:
                text_content += "\nالمنافذ:\n"
                for port, status in ports.items():
                    text_content += f"  {port}: {status}\n"
            
            # الثغرات
            vulnerabilities = target.get('vulnerabilities', [])
            if vulnerabilities:
                text_content += f"\nالثغرات المكتشفة ({len(vulnerabilities)}):\n"
                
                for vuln_index, vuln in enumerate(vulnerabilities):
                    text_content += f"\n  {vuln_index + 1}. {vuln.get('type', 'ثغرة غير معروفة')} (الخطورة: {vuln.get('severity', 'منخفضة')})\n"
                    text_content += f"     الوصف: {vuln.get('description', 'لا يوجد وصف متاح')}\n"
                    
                    # موقع الثغرة
                    location = vuln.get('location', {})
                    if location:
                        text_content += "     الموقع:\n"
                        for key, value in location.items():
                            text_content += f"       {key}: {value}\n"
                    
                    # معلومات الاستغلال
                    exploit_info = vuln.get('exploit_info', {})
                    if exploit_info:
                        text_content += "     معلومات الاستغلال:\n"
                        for key, value in exploit_info.items():
                            text_content += f"       {key}: {value}\n"
                    
                    # التوصيات
                    recommendation = vuln.get('recommendation')
                    if recommendation:
                        text_content += f"     التوصيات: {recommendation}\n"
                    
                    # المراجع
                    references = vuln.get('references', [])
                    if references:
                        text_content += "     المراجع:\n"
                        for ref in references:
                            text_content += f"       - {ref}\n"
            
            text_content += "\n" + "=" * 50 + "\n\n"
        
        # كتابة التقرير إلى ملف
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(text_content)
    
    def open_report(self, report_file):
        """فتح التقرير"""
        if not os.path.exists(report_file):
            raise FileNotFoundError(f"ملف التقرير غير موجود: {report_file}")
        
        # محاولة فتح التقرير في المتصفح
        try:
            # التحقق مما إذا كنا في بيئة Termux
            is_termux = 'com.termux' in os.environ.get('PREFIX', '')
            
            if is_termux:
                # في Termux، استخدم am لفتح المتصفح
                subprocess.Popen(['am', 'start', '-a', 'android.intent.action.VIEW', '-d', f"file://{report_file}"])
            else:
                # في أنظمة أخرى، استخدم webbrowser
                webbrowser.open(f"file://{report_file}")
            
            return True
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فتح التقرير: {str(e)}")
            return False
