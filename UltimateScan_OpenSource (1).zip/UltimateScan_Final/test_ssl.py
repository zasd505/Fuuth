#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
اختبار التحقق من شهادات SSL
"""

import os
import requests
import urllib3

print("=== اختبار التحقق من شهادات SSL ===")

# اختبار الطلب الافتراضي مع تفعيل التحقق من SSL
print("\n1. اختبار الطلب الافتراضي مع تفعيل التحقق من SSL:")
try:
    r = requests.get('https://example.com')
    print(f"✅ نجح الطلب مع التحقق من SSL")
    print(f"كود الاستجابة: {r.status_code}")
except requests.exceptions.SSLError as e:
    print(f"❌ فشل الطلب بسبب خطأ SSL: {e}")
except Exception as e:
    print(f"❌ فشل الطلب: {e}")

# اختبار الطلب مع تعطيل التحقق من SSL
print("\n2. اختبار الطلب مع تعطيل التحقق من SSL:")
try:
    r = requests.get('https://example.com', verify=False)
    print(f"✅ نجح الطلب مع تعطيل التحقق من SSL")
    print(f"كود الاستجابة: {r.status_code}")
except Exception as e:
    print(f"❌ فشل الطلب: {e}")

# اختبار تعطيل تحذيرات SSL
print("\n3. اختبار تعطيل تحذيرات SSL:")
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
try:
    r = requests.get('https://example.com', verify=False)
    print(f"✅ نجح الطلب مع تعطيل التحذيرات")
    print(f"كود الاستجابة: {r.status_code}")
except Exception as e:
    print(f"❌ فشل الطلب: {e}")

# اختبار التكامل مع وحدة base_scanner
print("\n4. اختبار التكامل مع وحدة base_scanner:")
try:
    from modules.base_scanner import VulnerabilityScanner
    
    # إنشاء ماسح مع تفعيل التحقق من SSL (افتراضي)
    scanner = VulnerabilityScanner()
    print(f"✅ تم إنشاء الماسح بنجاح مع تفعيل التحقق من SSL افتراضياً")
    
    # إنشاء ماسح مع تعطيل التحقق من SSL
    scanner_no_ssl = VulnerabilityScanner({'verify_ssl': False})
    print(f"✅ تم إنشاء الماسح بنجاح مع تعطيل التحقق من SSL")
    
except Exception as e:
    print(f"❌ فشل اختبار التكامل: {e}")

print("\n=== اكتمل اختبار التحقق من شهادات SSL ===")
