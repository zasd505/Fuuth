#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص ثغرات الويب
تتضمن فحوصات لثغرات الويب الشائعة مثل SQL Injection و XSS وغيرها
"""

import re
import requests
import urllib.parse
from bs4 import BeautifulSoup
from .base_scanner import VulnerabilityScanner

class WebVulnerabilityScanner(VulnerabilityScanner):
    """فاحص ثغرات الويب"""
    
    def __init__(self, config=None):
        """تهيئة الفاحص"""
        super().__init__(config)
        self.user_agent = self.config.get('user_agent', 'UltimateScan/1.0')
        self.headers = {
            'User-Agent': self.user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
    def get_description(self):
        """الحصول على وصف الفاحص"""
        return "فاحص ثغرات الويب الشامل"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return [
            'SQL Injection',
            'Cross-Site Scripting (XSS)',
            'Cross-Site Request Forgery (CSRF)',
            'Server-Side Request Forgery (SSRF)',
            'XML External Entity (XXE)',
            'XML Injection',
            'XPath Injection',
            'LDAP Injection',
            'Template Injection',
            'Expression Language Injection',
            'HTML Injection',
            'HTTP Header Injection',
            'HTTP Response Splitting',
            'Open Redirect',
            'Clickjacking',
            'Session Fixation',
            'Session Hijacking',
            'Cookie Poisoning',
            'Cache Poisoning',
            'Insecure Direct Object References (IDOR)',
            'Broken Access Control',
            'Malicious Redirects',
            'Subdomain Takeover',
            'WebSocket Vulnerabilities'
        ]
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        vulnerabilities = []
        
        # الحصول على عنوان URL للهدف
        if target.get_hostname():
            base_url = f"http://{target.get_hostname()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_hostname()}"
        else:
            base_url = f"http://{target.get_ip()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_ip()}"
        
        # فحص الصفحة الرئيسية
        try:
            response = self._make_request(base_url)
            if response:
                # استخراج النماذج والروابط
                forms = self._extract_forms(response)
                links = self._extract_links(response, base_url)
                
                # فحص الثغرات في النماذج
                for form in forms:
                    # فحص SQL Injection
                    sql_vulns = self._check_sql_injection(base_url, form)
                    vulnerabilities.extend(sql_vulns)
                    
                    # فحص XSS
                    xss_vulns = self._check_xss(base_url, form)
                    vulnerabilities.extend(xss_vulns)
                    
                    # فحص CSRF
                    csrf_vulns = self._check_csrf(base_url, form)
                    vulnerabilities.extend(csrf_vulns)
                
                # فحص الثغرات في الروابط
                for link in links:
                    # فحص SQL Injection
                    sql_vulns = self._check_sql_injection_in_url(link)
                    vulnerabilities.extend(sql_vulns)
                    
                    # فحص XSS
                    xss_vulns = self._check_xss_in_url(link)
                    vulnerabilities.extend(xss_vulns)
                    
                    # فحص Open Redirect
                    redirect_vulns = self._check_open_redirect(link)
                    vulnerabilities.extend(redirect_vulns)
                
                # فحص Clickjacking
                clickjacking_vulns = self._check_clickjacking(base_url)
                vulnerabilities.extend(clickjacking_vulns)
                
                # فحص HTTP Headers
                header_vulns = self._check_security_headers(base_url)
                vulnerabilities.extend(header_vulns)
        
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص ثغرات الويب: {str(e)}")
        
        # إضافة الثغرات إلى الهدف
        for vuln in vulnerabilities:
            target.add_vulnerability(vuln)
        
        return vulnerabilities
    
    def _make_request(self, url, method='GET', data=None, params=None, follow_redirects=True):
        """إجراء طلب HTTP"""
        try:
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=self.headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                response = requests.post(
                    url,
                    data=data,
                    headers=self.headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            else:
                return None
            
            return response
        except Exception as e:
            if self.verbose:
                print(f"خطأ في إجراء طلب HTTP: {str(e)}")
            return None
    
    def _extract_forms(self, response):
        """استخراج النماذج من صفحة HTML"""
        forms = []
        try:
            soup = BeautifulSoup(response.text, 'html.parser')
            for form in soup.find_all('form'):
                form_info = {
                    'action': form.get('action', ''),
                    'method': form.get('method', 'get').upper(),
                    'inputs': []
                }
                
                for input_tag in form.find_all(['input', 'textarea', 'select']):
                    input_info = {
                        'name': input_tag.get('name', ''),
                        'type': input_tag.get('type', 'text'),
                        'value': input_tag.get('value', '')
                    }
                    form_info['inputs'].append(input_info)
                
                forms.append(form_info)
        except Exception as e:
            if self.verbose:
                print(f"خطأ في استخراج النماذج: {str(e)}")
        
        return forms
    
    def _extract_links(self, response, base_url):
        """استخراج الروابط من صفحة HTML"""
        links = []
        try:
            soup = BeautifulSoup(response.text, 'html.parser')
            for a_tag in soup.find_all('a', href=True):
                href = a_tag['href']
                if href.startswith('http'):
                    links.append(href)
                elif href.startswith('/'):
                    links.append(f"{base_url}{href}")
                else:
                    links.append(f"{base_url}/{href}")
        except Exception as e:
            if self.verbose:
                print(f"خطأ في استخراج الروابط: {str(e)}")
        
        return links
    
    def _check_sql_injection(self, base_url, form):
        """فحص ثغرة SQL Injection في نموذج"""
        vulnerabilities = []
        
        # قائمة بحمولات SQL Injection
        payloads = [
            "' OR '1'='1",
            "' OR '1'='1' --",
            "' OR '1'='1' #",
            "1' OR '1'='1",
            "1' OR '1'='1' --",
            "1' OR '1'='1' #",
            "' UNION SELECT 1,2,3,4,5 --",
            "' UNION SELECT NULL,NULL,NULL,NULL,NULL --",
            "admin' --",
            "admin' #",
            "' OR 1=1 --",
            "' OR 1=1 #",
            "') OR ('1'='1",
            "')) OR (('1'='1"
        ]
        
        # قائمة بأنماط أخطاء SQL
        error_patterns = [
            "SQL syntax",
            "mysql_fetch_array",
            "mysql_fetch_assoc",
            "mysql_num_rows",
            "mysql_query",
            "mysqli_fetch_array",
            "mysqli_fetch_assoc",
            "mysqli_num_rows",
            "mysqli_query",
            "ORA-",
            "Oracle error",
            "PostgreSQL",
            "SQLite",
            "Syntax error",
            "ODBC Driver",
            "Microsoft SQL Server",
            "Microsoft OLE DB Provider for SQL Server",
            "Unclosed quotation mark",
            "DB2 SQL error",
            "SQLSTATE",
            "Warning: mysql_",
            "Warning: mysqli_",
            "Warning: pg_",
            "Warning: oci_",
            "Warning: sqlite_"
        ]
        
        # فحص كل حقل إدخال في النموذج
        for input_info in form['inputs']:
            if input_info['type'] not in ['submit', 'button', 'image', 'reset', 'file', 'checkbox', 'radio']:
                for payload in payloads:
                    # إنشاء بيانات النموذج
                    form_data = {}
                    for inp in form['inputs']:
                        if inp['name']:
                            if inp == input_info:
                                form_data[inp['name']] = payload
                            else:
                                form_data[inp['name']] = inp['value'] or 'test'
                    
                    # إرسال النموذج
                    url = form['action'] if form['action'].startswith('http') else f"{base_url}/{form['action']}"
                    
                    if form['method'] == 'GET':
                        response = self._make_request(url, method='GET', params=form_data)
                    else:
                        response = self._make_request(url, method='POST', data=form_data)
                    
                    if response:
                        # التحقق من وجود أخطاء SQL
                        for pattern in error_patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='SQL Injection',
                                    severity='critical',
                                    description='الموقع معرض لثغرة حقن SQL',
                                    location={
                                        'url': url,
                                        'form_action': form['action'],
                                        'form_method': form['method'],
                                        'parameter': input_info['name']
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'exploit_url': url if form['method'] == 'GET' else None,
                                        'exploit_data': form_data,
                                        'method': form['method']
                                    },
                                    recommendation='استخدام الاستعلامات المعدة مسبقاً وتنقية مدخلات المستخدم',
                                    references=[
                                        'https://owasp.org/www-community/attacks/SQL_Injection',
                                        'https://portswigger.net/web-security/sql-injection'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
        
        return vulnerabilities
    
    def _check_sql_injection_in_url(self, url):
        """فحص ثغرة SQL Injection في URL"""
        vulnerabilities = []
        
        # التحقق من وجود معلمات في URL
        parsed_url = urllib.parse.urlparse(url)
        if not parsed_url.query:
            return vulnerabilities
        
        # تحليل معلمات URL
        params = urllib.parse.parse_qs(parsed_url.query)
        
        # قائمة بحمولات SQL Injection
        payloads = [
            "' OR '1'='1",
            "' OR '1'='1' --",
            "1' OR '1'='1",
            "' UNION SELECT 1,2,3,4,5 --"
        ]
        
        # قائمة بأنماط أخطاء SQL
        error_patterns = [
            "SQL syntax",
            "mysql_fetch_array",
            "ORA-",
            "PostgreSQL",
            "SQLite",
            "Syntax error",
            "ODBC Driver",
            "Microsoft SQL Server",
            "Unclosed quotation mark",
            "SQLSTATE"
        ]
        
        # فحص كل معلمة في URL
        for param_name, param_values in params.items():
            for payload in payloads:
                # إنشاء URL جديد مع الحمولة
                new_params = params.copy()
                new_params[param_name] = [payload]
                
                new_query = urllib.parse.urlencode(new_params, doseq=True)
                new_url = urllib.parse.urlunparse((
                    parsed_url.scheme,
                    parsed_url.netloc,
                    parsed_url.path,
                    parsed_url.params,
                    new_query,
                    parsed_url.fragment
                ))
                
                # إرسال الطلب
                response = self._make_request(new_url)
                
                if response:
                    # التحقق من وجود أخطاء SQL
                    for pattern in error_patterns:
                        if pattern in response.text:
                            vuln = self.create_vulnerability(
                                vuln_type='SQL Injection',
                                severity='critical',
                                description='الموقع معرض لثغرة حقن SQL في معلمات URL',
                                location={
                                    'url': url,
                                    'parameter': param_name
                                },
                                exploit_info={
                                    'payload': payload,
                                    'exploit_url': new_url,
                                    'method': 'GET'
                                },
                                recommendation='استخدام الاستعلامات المعدة مسبقاً وتنقية مدخلات المستخدم',
                                references=[
                                    'https://owasp.org/www-community/attacks/SQL_Injection',
                                    'https://portswigger.net/web-security/sql-injection'
                                ]
                            )
                            vulnerabilities.append(vuln)
                            break
        
        return vulnerabilities
    
    def _check_xss(self, base_url, form):
        """فحص ثغرة XSS في نموذج"""
        vulnerabilities = []
        
        # قائمة بحمولات XSS
        payloads = [
            "<script>alert(1)</script>",
            "<img src=x onerror=alert(1)>",
            "<svg onload=alert(1)>",
            "<body onload=alert(1)>",
            "javascript:alert(1)",
            "\"><script>alert(1)</script>",
            "'><script>alert(1)</script>",
            "><script>alert(1)</script>",
            "</script><script>alert(1)</script>",
            "' onmouseover='alert(1)",
            "\" onmouseover=\"alert(1)",
            "onerror=alert(1) x="
        ]
        
        # فحص كل حقل إدخال في النموذج
        for input_info in form['inputs']:
            if input_info['type'] not in ['submit', 'button', 'image', 'reset', 'file', 'checkbox', 'radio']:
                for payload in payloads:
                    # إنشاء بيانات النموذج
                    form_data = {}
                    for inp in form['inputs']:
                        if inp['name']:
                            if inp == input_info:
                                form_data[inp['name']] = payload
                            else:
                                form_data[inp['name']] = inp['value'] or 'test'
                    
                    # إرسال النموذج
                    url = form['action'] if form['action'].startswith('http') else f"{base_url}/{form['action']}"
                    
                    if form['method'] == 'GET':
                        response = self._make_request(url, method='GET', params=form_data)
                    else:
                        response = self._make_request(url, method='POST', data=form_data)
                    
                    if response and payload in response.text:
                        vuln = self.create_vulnerability(
                            vuln_type='Cross-Site Scripting (XSS)',
                            severity='high',
                            description='الموقع معرض لثغرة XSS',
                            location={
                                'url': url,
                                'form_action': form['action'],
                                'form_method': form['method'],
                                'parameter': input_info['name']
                            },
                            exploit_info={
                                'payload': payload,
                                'exploit_url': url if form['method'] == 'GET' else None,
                                'exploit_data': form_data,
                                'method': form['method']
                            },
                            recommendation='تنقية مدخلات المستخدم وترميز المخرجات',
                            references=[
                                'https://owasp.org/www-community/attacks/xss/',
                                'https://portswigger.net/web-security/cross-site-scripting'
                            ]
                        )
                        vulnerabilities.append(vuln)
                        break
        
        return vulnerabilities
    
    def _check_xss_in_url(self, url):
        """فحص ثغرة XSS في URL"""
        vulnerabilities = []
        
        # التحقق من وجود معلمات في URL
        parsed_url = urllib.parse.urlparse(url)
        if not parsed_url.query:
            return vulnerabilities
        
        # تحليل معلمات URL
        params = urllib.parse.parse_qs(parsed_url.query)
        
        # قائمة بحمولات XSS
        payloads = [
            "<script>alert(1)</script>",
            "<img src=x onerror=alert(1)>",
            "<svg onload=alert(1)>"
        ]
        
        # فحص كل معلمة في URL
        for param_name, param_values in params.items():
            for payload in payloads:
                # إنشاء URL جديد مع الحمولة
                new_params = params.copy()
                new_params[param_name] = [payload]
                
                new_query = urllib.parse.urlencode(new_params, doseq=True)
                new_url = urllib.parse.urlunparse((
                    parsed_url.scheme,
                    parsed_url.netloc,
                    parsed_url.path,
                    parsed_url.params,
                    new_query,
                    parsed_url.fragment
                ))
                
                # إرسال الطلب
                response = self._make_request(new_url)
                
                if response and payload in response.text:
                    vuln = self.create_vulnerability(
                        vuln_type='Cross-Site Scripting (XSS)',
                        severity='high',
                        description='الموقع معرض لثغرة XSS في معلمات URL',
                        location={
                            'url': url,
                            'parameter': param_name
                        },
                        exploit_info={
                            'payload': payload,
                            'exploit_url': new_url,
                            'method': 'GET'
                        },
                        recommendation='تنقية مدخلات المستخدم وترميز المخرجات',
                        references=[
                            'https://owasp.org/www-community/attacks/xss/',
                            'https://portswigger.net/web-security/cross-site-scripting'
                        ]
                    )
                    vulnerabilities.append(vuln)
                    break
        
        return vulnerabilities
    
    def _check_csrf(self, base_url, form):
        """فحص ثغرة CSRF في نموذج"""
        vulnerabilities = []
        
        # التحقق من وجود حماية CSRF
        has_csrf_protection = False
        
        for input_info in form['inputs']:
            if input_info['name'].lower() in ['csrf', 'csrf_token', 'csrftoken', 'xsrf', 'xsrf_token', '_csrf', '_token']:
                has_csrf_protection = True
                break
        
        # إذا كان النموذج يستخدم طريقة POST ولا يحتوي على حماية CSRF
        if form['method'] == 'POST' and not has_csrf_protection:
            vuln = self.create_vulnerability(
                vuln_type='Cross-Site Request Forgery (CSRF)',
                severity='medium',
                description='النموذج معرض لثغرة CSRF',
                location={
                    'url': base_url,
                    'form_action': form['action'],
                    'form_method': form['method']
                },
                exploit_info={
                    'exploit_html': self._generate_csrf_poc(base_url, form),
                    'method': form['method']
                },
                recommendation='إضافة رمز CSRF إلى جميع نماذج POST',
                references=[
                    'https://owasp.org/www-community/attacks/csrf',
                    'https://portswigger.net/web-security/csrf'
                ]
            )
            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _generate_csrf_poc(self, base_url, form):
        """إنشاء إثبات مفهوم لثغرة CSRF"""
        url = form['action'] if form['action'].startswith('http') else f"{base_url}/{form['action']}"
        
        html = f"""
        <html>
            <body>
                <h1>CSRF PoC</h1>
                <form action="{url}" method="{form['method']}" id="csrf-form">
        """
        
        for input_info in form['inputs']:
            if input_info['name'] and input_info['type'] != 'submit':
                value = input_info['value'] or 'csrf_test'
                html += f'    <input type="hidden" name="{input_info["name"]}" value="{value}">\n'
        
        html += """
                </form>
                <script>
                    document.getElementById("csrf-form").submit();
                </script>
            </body>
        </html>
        """
        
        return html
    
    def _check_open_redirect(self, url):
        """فحص ثغرة Open Redirect في URL"""
        vulnerabilities = []
        
        # التحقق من وجود معلمات في URL
        parsed_url = urllib.parse.urlparse(url)
        if not parsed_url.query:
            return vulnerabilities
        
        # تحليل معلمات URL
        params = urllib.parse.parse_qs(parsed_url.query)
        
        # قائمة بمعلمات إعادة التوجيه المحتملة
        redirect_params = ['redirect', 'url', 'next', 'return', 'returnto', 'returnurl', 'goto', 'redir', 'redirect_uri', 'redirect_url', 'continue', 'destination', 'rurl']
        
        # قائمة بحمولات إعادة التوجيه
        payloads = [
            'https://evil.com',
            '//evil.com',
            'https:evil.com',
            'https:/evil.com'
        ]
        
        # فحص كل معلمة في URL
        for param_name, param_values in params.items():
            if param_name.lower() in redirect_params:
                for payload in payloads:
                    # إنشاء URL جديد مع الحمولة
                    new_params = params.copy()
                    new_params[param_name] = [payload]
                    
                    new_query = urllib.parse.urlencode(new_params, doseq=True)
                    new_url = urllib.parse.urlunparse((
                        parsed_url.scheme,
                        parsed_url.netloc,
                        parsed_url.path,
                        parsed_url.params,
                        new_query,
                        parsed_url.fragment
                    ))
                    
                    # إرسال الطلب بدون متابعة إعادة التوجيه
                    response = self._make_request(new_url, follow_redirects=False)
                    
                    if response and (response.status_code in [301, 302, 303, 307, 308]):
                        location = response.headers.get('Location', '')
                        if payload in location or 'evil.com' in location:
                            vuln = self.create_vulnerability(
                                vuln_type='Open Redirect',
                                severity='medium',
                                description='الموقع معرض لثغرة Open Redirect',
                                location={
                                    'url': url,
                                    'parameter': param_name
                                },
                                exploit_info={
                                    'payload': payload,
                                    'exploit_url': new_url,
                                    'redirect_to': location
                                },
                                recommendation='التحقق من صحة عناوين URL المستخدمة في إعادة التوجيه',
                                references=[
                                    'https://cheatsheetseries.owasp.org/cheatsheets/Unvalidated_Redirects_and_Forwards_Cheat_Sheet.html',
                                    'https://portswigger.net/kb/issues/00500100_open-redirection-reflected'
                                ]
                            )
                            vulnerabilities.append(vuln)
                            break
        
        return vulnerabilities
    
    def _check_clickjacking(self, url):
        """فحص ثغرة Clickjacking"""
        vulnerabilities = []
        
        response = self._make_request(url)
        if not response:
            return vulnerabilities
        
        # التحقق من وجود رأس X-Frame-Options
        x_frame_options = response.headers.get('X-Frame-Options', '')
        
        # التحقق من وجود سياسة Content-Security-Policy مع frame-ancestors
        csp = response.headers.get('Content-Security-Policy', '')
        frame_ancestors = re.search(r'frame-ancestors\s+([^;]+)', csp)
        
        if not x_frame_options and not frame_ancestors:
            vuln = self.create_vulnerability(
                vuln_type='Clickjacking',
                severity='medium',
                description='الموقع معرض لثغرة Clickjacking',
                location={
                    'url': url
                },
                exploit_info={
                    'exploit_html': self._generate_clickjacking_poc(url)
                },
                recommendation='إضافة رأس X-Frame-Options أو سياسة Content-Security-Policy مع frame-ancestors',
                references=[
                    'https://owasp.org/www-community/attacks/Clickjacking',
                    'https://portswigger.net/web-security/clickjacking'
                ]
            )
            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _generate_clickjacking_poc(self, url):
        """إنشاء إثبات مفهوم لثغرة Clickjacking"""
        html = f"""
        <html>
            <head>
                <title>Clickjacking PoC</title>
                <style>
                    iframe {{
                        width: 100%;
                        height: 100%;
                        position: absolute;
                        top: 0;
                        left: 0;
                        opacity: 0.5;
                        z-index: 1;
                    }}
                    button {{
                        position: absolute;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        z-index: 2;
                    }}
                </style>
            </head>
            <body>
                <button>انقر هنا للفوز بجائزة</button>
                <iframe src="{url}"></iframe>
            </body>
        </html>
        """
        
        return html
    
    def _check_security_headers(self, url):
        """فحص رؤوس الأمان المفقودة"""
        vulnerabilities = []
        
        response = self._make_request(url)
        if not response:
            return vulnerabilities
        
        # قائمة برؤوس الأمان المهمة
        security_headers = {
            'Strict-Transport-Security': 'HSTS غير مفعل',
            'Content-Security-Policy': 'CSP غير مفعل',
            'X-Frame-Options': 'X-Frame-Options غير مفعل',
            'X-XSS-Protection': 'الحماية من XSS غير مفعلة',
            'X-Content-Type-Options': 'X-Content-Type-Options غير مفعل'
        }
        
        for header, message in security_headers.items():
            if header not in response.headers:
                vuln = self.create_vulnerability(
                    vuln_type=f'Missing Security Header: {header}',
                    severity='low',
                    description=message,
                    location={
                        'url': url
                    },
                    recommendation=f'إضافة رأس {header} إلى استجابات الخادم',
                    references=[
                        'https://owasp.org/www-project-secure-headers/',
                        'https://cheatsheetseries.owasp.org/cheatsheets/HTTP_Headers_Cheat_Sheet.html'
                    ]
                )
                vulnerabilities.append(vuln)
        
        return vulnerabilities
