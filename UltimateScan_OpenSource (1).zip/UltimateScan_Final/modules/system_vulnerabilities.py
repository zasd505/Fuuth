#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص ثغرات الأنظمة
تتضمن فحوصات لثغرات الأنظمة مثل Buffer Overflow و Privilege Escalation وغيرها
"""

import re
import socket
import subprocess
import requests
import urllib.parse
from .base_scanner import VulnerabilityScanner

class SystemVulnerabilityScanner(VulnerabilityScanner):
    """فاحص ثغرات الأنظمة"""
    
    def __init__(self, config=None):
        """تهيئة الفاحص"""
        super().__init__(config)
        
    def get_description(self):
        """الحصول على وصف الفاحص"""
        return "فاحص ثغرات الأنظمة الشامل"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return [
            'Buffer Overflow',
            'Heap Overflow',
            'Memory Corruption',
            'Format String Attack',
            'Memory Leak',
            'Privilege Escalation',
            'Outdated Software Vulnerabilities',
            'Cloud Security Issues',
            'PowerShell Attacks',
            'Firmware Attacks',
            'Supply Chain Attacks',
            'Supply Chain Attacks on Open Source Software',
            'Supply Chain Compromise via Hardware'
        ]
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        vulnerabilities = []
        
        # الحصول على عنوان URL للهدف
        if target.get_hostname():
            base_url = f"http://{target.get_hostname()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_hostname()}"
            host = target.get_hostname()
        else:
            base_url = f"http://{target.get_ip()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_ip()}"
            host = target.get_ip()
        
        # فحص ثغرات الأنظمة
        try:
            # فحص البرامج القديمة
            outdated_vulns = self._check_outdated_software(target)
            vulnerabilities.extend(outdated_vulns)
            
            # فحص ثغرات Buffer Overflow
            buffer_vulns = self._check_buffer_overflow(target)
            vulnerabilities.extend(buffer_vulns)
            
            # فحص ثغرات Format String
            format_vulns = self._check_format_string(target)
            vulnerabilities.extend(format_vulns)
            
            # فحص ثغرات Memory Leak
            memory_vulns = self._check_memory_leak(target)
            vulnerabilities.extend(memory_vulns)
            
            # فحص ثغرات Privilege Escalation
            priv_vulns = self._check_privilege_escalation(target)
            vulnerabilities.extend(priv_vulns)
            
            # فحص ثغرات Cloud Security
            cloud_vulns = self._check_cloud_security(base_url)
            vulnerabilities.extend(cloud_vulns)
            
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص ثغرات الأنظمة: {str(e)}")
        
        # إضافة الثغرات إلى الهدف
        for vuln in vulnerabilities:
            target.add_vulnerability(vuln)
        
        return vulnerabilities
    
    def _make_request(self, url, method='GET', data=None, params=None, headers=None, follow_redirects=True):
        """إجراء طلب HTTP"""
        try:
            req_headers = {
                'User-Agent': 'UltimateScan/1.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            if headers:
                req_headers.update(headers)
                
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                response = requests.post(
                    url,
                    data=data,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            else:
                return None
            
            return response
        except Exception as e:
            if self.verbose:
                print(f"خطأ في إجراء طلب HTTP: {str(e)}")
            return None
    
    def _check_outdated_software(self, target):
        """فحص البرامج القديمة"""
        vulnerabilities = []
        
        # قائمة بالخدمات المعروفة والإصدارات القديمة
        outdated_versions = {
            'Apache': {
                'pattern': r'Apache/([0-9.]+)',
                'outdated': ['1.3', '2.0', '2.2', '2.4.0', '2.4.1', '2.4.2', '2.4.3', '2.4.4', '2.4.5', '2.4.6', '2.4.7', '2.4.8', '2.4.9']
            },
            'Nginx': {
                'pattern': r'nginx/([0-9.]+)',
                'outdated': ['1.0', '1.1', '1.2', '1.3', '1.4', '1.5', '1.6', '1.7', '1.8', '1.9', '1.10', '1.11', '1.12', '1.13', '1.14', '1.15', '1.16', '1.17', '1.18']
            },
            'PHP': {
                'pattern': r'PHP/([0-9.]+)',
                'outdated': ['5.0', '5.1', '5.2', '5.3', '5.4', '5.5', '5.6', '7.0', '7.1', '7.2', '7.3']
            },
            'OpenSSL': {
                'pattern': r'OpenSSL/([0-9.]+)',
                'outdated': ['0.9.8', '1.0.0', '1.0.1', '1.0.2', '1.1.0']
            },
            'MySQL': {
                'pattern': r'MySQL/([0-9.]+)',
                'outdated': ['4.0', '4.1', '5.0', '5.1', '5.5', '5.6', '5.7']
            },
            'WordPress': {
                'pattern': r'WordPress/([0-9.]+)',
                'outdated': ['1', '2', '3', '4.0', '4.1', '4.2', '4.3', '4.4', '4.5', '4.6', '4.7', '4.8', '4.9', '5.0', '5.1', '5.2', '5.3', '5.4', '5.5', '5.6', '5.7', '5.8']
            }
        }
        
        # فحص الخدمات المكتشفة
        for port, service in target.get_services().items():
            for software, info in outdated_versions.items():
                if software.lower() in service.lower():
                    # البحث عن الإصدار
                    match = re.search(info['pattern'], service)
                    if match:
                        version = match.group(1)
                        
                        # التحقق من الإصدار القديم
                        if any(version.startswith(outdated) for outdated in info['outdated']):
                            vuln = self.create_vulnerability(
                                vuln_type='Outdated Software',
                                severity='high',
                                description=f'تم اكتشاف برنامج قديم: {software} {version}',
                                location={
                                    'host': target.get_hostname() or target.get_ip(),
                                    'port': port,
                                    'service': service
                                },
                                recommendation=f'ترقية {software} إلى أحدث إصدار',
                                references=[
                                    f'https://www.cvedetails.com/vulnerability-list/vendor_id-0/product_id-0/version_id-0/keyword-{software.lower()}.html',
                                    'https://owasp.org/www-project-top-ten/2017/A9_2017-Using_Components_with_Known_Vulnerabilities'
                                ]
                            )
                            vulnerabilities.append(vuln)
        
        # فحص رؤوس HTTP
        for port in [80, 443, 8080, 8443]:
            if port in target.get_ports() and target.get_ports()[port] == 'open':
                protocol = 'https' if port in [443, 8443] else 'http'
                url = f"{protocol}://{target.get_hostname() or target.get_ip()}:{port}"
                
                response = self._make_request(url)
                
                if response:
                    # فحص رأس Server
                    server = response.headers.get('Server', '')
                    
                    for software, info in outdated_versions.items():
                        if software.lower() in server.lower():
                            # البحث عن الإصدار
                            match = re.search(info['pattern'], server)
                            if match:
                                version = match.group(1)
                                
                                # التحقق من الإصدار القديم
                                if any(version.startswith(outdated) for outdated in info['outdated']):
                                    vuln = self.create_vulnerability(
                                        vuln_type='Outdated Software',
                                        severity='high',
                                        description=f'تم اكتشاف برنامج قديم: {software} {version}',
                                        location={
                                            'url': url,
                                            'header': 'Server',
                                            'value': server
                                        },
                                        recommendation=f'ترقية {software} إلى أحدث إصدار وإخفاء إصدار الخادم في رؤوس HTTP',
                                        references=[
                                            f'https://www.cvedetails.com/vulnerability-list/vendor_id-0/product_id-0/version_id-0/keyword-{software.lower()}.html',
                                            'https://owasp.org/www-project-top-ten/2017/A9_2017-Using_Components_with_Known_Vulnerabilities'
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
                    
                    # فحص رأس X-Powered-By
                    powered_by = response.headers.get('X-Powered-By', '')
                    
                    for software, info in outdated_versions.items():
                        if software.lower() in powered_by.lower():
                            # البحث عن الإصدار
                            match = re.search(info['pattern'], powered_by)
                            if match:
                                version = match.group(1)
                                
                                # التحقق من الإصدار القديم
                                if any(version.startswith(outdated) for outdated in info['outdated']):
                                    vuln = self.create_vulnerability(
                                        vuln_type='Outdated Software',
                                        severity='high',
                                        description=f'تم اكتشاف برنامج قديم: {software} {version}',
                                        location={
                                            'url': url,
                                            'header': 'X-Powered-By',
                                            'value': powered_by
                                        },
                                        recommendation=f'ترقية {software} إلى أحدث إصدار وإخفاء رأس X-Powered-By',
                                        references=[
                                            f'https://www.cvedetails.com/vulnerability-list/vendor_id-0/product_id-0/version_id-0/keyword-{software.lower()}.html',
                                            'https://owasp.org/www-project-top-ten/2017/A9_2017-Using_Components_with_Known_Vulnerabilities'
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _check_buffer_overflow(self, target):
        """فحص ثغرات Buffer Overflow"""
        vulnerabilities = []
        
        # قائمة بالخدمات المعرضة لثغرات Buffer Overflow
        vulnerable_services = {
            'FTP': 21,
            'SSH': 22,
            'SMTP': 25,
            'DNS': 53,
            'TFTP': 69,
            'HTTP': 80,
            'POP3': 110,
            'IMAP': 143,
            'RPC': 135,
            'NetBIOS': 139,
            'SMB': 445,
            'MSSQL': 1433,
            'Oracle': 1521,
            'MySQL': 3306,
            'RDP': 3389,
            'PostgreSQL': 5432
        }
        
        # فحص الخدمات المكتشفة
        for service_name, port in vulnerable_services.items():
            if port in target.get_ports() and target.get_ports()[port] == 'open':
                # إنشاء حمولة كبيرة
                payload = 'A' * 4096
                
                try:
                    # إنشاء اتصال
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(self.timeout)
                    sock.connect((target.get_ip(), port))
                    
                    # إرسال الحمولة
                    sock.send(payload.encode())
                    
                    # انتظار الاستجابة
                    response = sock.recv(1024)
                    
                    # إغلاق الاتصال
                    sock.close()
                    
                    # التحقق من الاستجابة
                    if not response or len(response) == 0:
                        vuln = self.create_vulnerability(
                            vuln_type='Potential Buffer Overflow',
                            severity='high',
                            description=f'الخدمة {service_name} قد تكون معرضة لثغرة Buffer Overflow',
                            location={
                                'host': target.get_hostname() or target.get_ip(),
                                'port': port,
                                'service': service_name
                            },
                            exploit_info={
                                'payload': 'A' * 20 + '...',  # مختصر
                                'payload_length': len(payload)
                            },
                            recommendation=f'ترقية خدمة {service_name} إلى أحدث إصدار وتطبيق التصحيحات الأمنية',
                            references=[
                                'https://owasp.org/www-community/vulnerabilities/Buffer_Overflow',
                                'https://cwe.mitre.org/data/definitions/120.html'
                            ]
                        )
                        vulnerabilities.append(vuln)
                except:
                    pass
        
        return vulnerabilities
    
    def _check_format_string(self, target):
        """فحص ثغرات Format String"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/index.php', '/search.php', '/view.php', '/display.php', '/show.php',
            '/print.php', '/debug.php', '/log.php', '/error.php', '/info.php',
            '/test.php', '/query.php', '/result.php', '/output.php', '/format.php'
        ]
        
        # قائمة بالمعلمات المحتملة
        params = ['q', 'query', 'search', 'id', 'page', 'file', 'name', 'debug', 'log', 'error', 'format']
        
        # قائمة بحمولات Format String
        payloads = ['%x', '%s', '%n', '%p', '%d', '%i', '%u', '%c', '%x%x%x%x', '%p%p%p%p']
        
        # فحص كل مسار
        for port in [80, 443, 8080, 8443]:
            if port in target.get_ports() and target.get_ports()[port] == 'open':
                protocol = 'https' if port in [443, 8443] else 'http'
                base_url = f"{protocol}://{target.get_hostname() or target.get_ip()}:{port}"
                
                for path in paths:
                    url = f"{base_url}{path}"
                    
                    # فحص كل معلمة
                    for param in params:
                        for payload in payloads:
                            # إنشاء معلمات الطلب
                            params_data = {param: payload}
                            
                            # إرسال الطلب
                            response = self._make_request(url, params=params_data)
                            
                            if response:
                                # التحقق من وجود أنماط Format String
                                if '0x' in response.text or 'memory' in response.text.lower() or 'address' in response.text.lower() or 'segmentation' in response.text.lower():
                                    vuln = self.create_vulnerability(
                                        vuln_type='Format String Vulnerability',
                                        severity='high',
                                        description='الموقع معرض لثغرة Format String',
                                        location={
                                            'url': url,
                                            'parameter': param
                                        },
                                        exploit_info={
                                            'payload': payload,
                                            'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                            'method': 'GET'
                                        },
                                        recommendation='تنقية مدخلات المستخدم وتجنب استخدام دوال Format String مع مدخلات المستخدم',
                                        references=[
                                            'https://owasp.org/www-community/attacks/Format_string_attack',
                                            'https://cwe.mitre.org/data/definitions/134.html'
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
                                    break
        
        return vulnerabilities
    
    def _check_memory_leak(self, target):
        """فحص ثغرات Memory Leak"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/index.php', '/search.php', '/view.php', '/display.php', '/show.php',
            '/debug.php', '/log.php', '/error.php', '/info.php', '/test.php',
            '/query.php', '/result.php', '/output.php', '/memory.php', '/status.php'
        ]
        
        # قائمة بالمعلمات المحتملة
        params = ['debug', 'test', 'dev', 'development', 'verbose', 'memory', 'leak', 'check', 'status']
        
        # قائمة بحمولات Memory Leak
        payloads = ['1', 'true', 'yes', 'on', 'debug', 'test', 'memory', 'leak', 'check']
        
        # قائمة بأنماط Memory Leak
        patterns = [
            r'0x[0-9a-f]+', r'memory', r'leak', r'address', r'pointer',
            r'allocation', r'free', r'malloc', r'realloc', r'new', r'delete'
        ]
        
        # فحص كل مسار
        for port in [80, 443, 8080, 8443]:
            if port in target.get_ports() and target.get_ports()[port] == 'open':
                protocol = 'https' if port in [443, 8443] else 'http'
                base_url = f"{protocol}://{target.get_hostname() or target.get_ip()}:{port}"
                
                for path in paths:
                    url = f"{base_url}{path}"
                    
                    # فحص كل معلمة
                    for param in params:
                        for payload in payloads:
                            # إنشاء معلمات الطلب
                            params_data = {param: payload}
                            
                            # إرسال الطلب
                            response = self._make_request(url, params=params_data)
                            
                            if response:
                                # التحقق من وجود أنماط Memory Leak
                                for pattern in patterns:
                                    if re.search(pattern, response.text, re.IGNORECASE):
                                        vuln = self.create_vulnerability(
                                            vuln_type='Memory Leak',
                                            severity='medium',
                                            description='الموقع معرض لثغرة Memory Leak',
                                            location={
                                                'url': url,
                                                'parameter': param
                                            },
                                            exploit_info={
                                                'payload': payload,
                                                'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                                'method': 'GET'
                                            },
                                            recommendation='تعطيل وضع التصحيح في بيئة الإنتاج وتجنب عرض معلومات الذاكرة',
                                            references=[
                                                'https://owasp.org/www-community/vulnerabilities/Information_exposure_through_error_messages',
                                                'https://cwe.mitre.org/data/definitions/200.html'
                                            ]
                                        )
                                        vulnerabilities.append(vuln)
                                        break
        
        return vulnerabilities
    
    def _check_privilege_escalation(self, target):
        """فحص ثغرات Privilege Escalation"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/admin', '/administrator', '/wp-admin', '/admin/index.php',
            '/admin/login.php', '/admin/admin.php', '/admin/account.php',
            '/administrator/index.php', '/administrator/login.php',
            '/wp-login.php', '/login', '/login.php', '/auth', '/auth.php',
            '/user', '/user.php', '/profile', '/profile.php', '/account', '/account.php'
        ]
        
        # فحص كل مسار
        for port in [80, 443, 8080, 8443]:
            if port in target.get_ports() and target.get_ports()[port] == 'open':
                protocol = 'https' if port in [443, 8443] else 'http'
                base_url = f"{protocol}://{target.get_hostname() or target.get_ip()}:{port}"
                
                for path in paths:
                    url = f"{base_url}{path}"
                    
                    # إرسال الطلب
                    response = self._make_request(url)
                    
                    if response and response.status_code in [200, 301, 302, 401, 403]:
                        # التحقق من وجود صفحة تسجيل دخول أو صفحة إدارية
                        if 'login' in response.text.lower() or 'admin' in response.text.lower() or 'password' in response.text.lower():
                            # فحص IDOR
                            idor_params = ['id', 'user_id', 'account_id', 'uid', 'userid', 'user', 'profile_id']
                            
                            for param in idor_params:
                                # تجربة قيم مختلفة
                                for value in ['1', '2', '3', 'admin', 'administrator']:
                                    # إنشاء معلمات الطلب
                                    params_data = {param: value}
                                    
                                    # إرسال الطلب
                                    idor_response = self._make_request(url, params=params_data)
                                    
                                    if idor_response and idor_response.status_code == 200:
                                        vuln = self.create_vulnerability(
                                            vuln_type='Potential Privilege Escalation (IDOR)',
                                            severity='high',
                                            description='الموقع قد يكون معرضاً لثغرة Privilege Escalation عبر IDOR',
                                            location={
                                                'url': url,
                                                'parameter': param
                                            },
                                            exploit_info={
                                                'payload': value,
                                                'exploit_url': f"{url}?{param}={urllib.parse.quote(value)}",
                                                'method': 'GET'
                                            },
                                            recommendation='تنفيذ التحقق من الصلاحيات على جانب الخادم وعدم الاعتماد على معرفات المستخدم فقط',
                                            references=[
                                                'https://owasp.org/www-project-top-ten/2017/A5_2017-Broken_Access_Control',
                                                'https://cheatsheetseries.owasp.org/cheatsheets/Insecure_Direct_Object_Reference_Prevention_Cheat_Sheet.html'
                                            ]
                                        )
                                        vulnerabilities.append(vuln)
                                        break
        
        return vulnerabilities
    
    def _check_cloud_security(self, base_url):
        """فحص ثغرات Cloud Security"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/.aws/credentials', '/.aws/config', '/aws.json', '/aws.yml', '/aws.yaml',
            '/azure.json', '/azure.yml', '/azure.yaml', '/gcp.json', '/gcp.yml', '/gcp.yaml',
            '/credentials.json', '/credentials.yml', '/credentials.yaml',
            '/config.json', '/config.yml', '/config.yaml',
            '/.env', '/.env.local', '/.env.development', '/.env.production',
            '/terraform.tfstate', '/terraform.tfvars', '/terraform.tfvars.json'
        ]
        
        # قائمة بأنماط Cloud Security
        patterns = {
            'aws_access_key': r'(AKIA[0-9A-Z]{16})',
            'aws_secret_key': r'([0-9a-zA-Z/+]{40})',
            'azure_connection_string': r'(DefaultEndpointsProtocol=https?;AccountName=[^;]+;AccountKey=[^;]+)',
            'azure_key': r'([0-9a-zA-Z+/]{88}==)',
            'gcp_key': r'("type": "service_account")',
            'cloud_url': r'(https?://[a-zA-Z0-9-]+\.(amazonaws\.com|azurewebsites\.net|appspot\.com|cloudfunctions\.net))'
        }
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response and response.status_code == 200:
                # التحقق من وجود أنماط Cloud Security
                for pattern_name, pattern in patterns.items():
                    matches = re.findall(pattern, response.text)
                    
                    if matches:
                        vuln = self.create_vulnerability(
                            vuln_type='Cloud Security Issue',
                            severity='critical',
                            description=f'تم اكتشاف معلومات حساسة متعلقة بالسحابة: {pattern_name}',
                            location={
                                'url': url
                            },
                            recommendation='إزالة الملفات الحساسة من الخادم وتخزين بيانات الاعتماد بشكل آمن',
                            references=[
                                'https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure',
                                'https://www.nccgroup.com/uk/about-us/newsroom-and-events/blogs/2021/january/common-cloud-misconfiguration-exploits/'
                            ]
                        )
                        vulnerabilities.append(vuln)
        
        # فحص S3 Bucket
        response = self._make_request(base_url)
        
        if response:
            # البحث عن روابط S3 Bucket
            s3_pattern = r'https?://([a-zA-Z0-9-]+)\.s3\.amazonaws\.com'
            s3_matches = re.findall(s3_pattern, response.text)
            
            for bucket_name in s3_matches:
                # فحص الوصول إلى S3 Bucket
                bucket_url = f"https://{bucket_name}.s3.amazonaws.com"
                bucket_response = self._make_request(bucket_url)
                
                if bucket_response and bucket_response.status_code == 200:
                    if 'ListBucketResult' in bucket_response.text:
                        vuln = self.create_vulnerability(
                            vuln_type='S3 Bucket Misconfiguration',
                            severity='high',
                            description=f'تم اكتشاف S3 Bucket مفتوح: {bucket_name}',
                            location={
                                'url': bucket_url
                            },
                            recommendation='تكوين S3 Bucket بشكل صحيح لمنع الوصول العام',
                            references=[
                                'https://docs.aws.amazon.com/AmazonS3/latest/userguide/access-control-block-public-access.html',
                                'https://www.nccgroup.com/uk/about-us/newsroom-and-events/blogs/2021/january/common-cloud-misconfiguration-exploits/'
                            ]
                        )
                        vulnerabilities.append(vuln)
        
        return vulnerabilities
