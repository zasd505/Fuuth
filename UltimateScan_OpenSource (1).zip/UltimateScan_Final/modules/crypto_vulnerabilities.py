#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص ثغرات التشفير
تتضمن فحوصات لثغرات التشفير مثل Broken Cryptography و Side-channel Attacks وغيرها
"""

import socket
import ssl
import re
import requests
import urllib.parse
from .base_scanner import VulnerabilityScanner

class CryptoVulnerabilityScanner(VulnerabilityScanner):
    """فاحص ثغرات التشفير"""
    
    def __init__(self, config=None):
        """تهيئة الفاحص"""
        super().__init__(config)
        
    def get_description(self):
        """الحصول على وصف الفاحص"""
        return "فاحص ثغرات التشفير الشامل"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return [
            'Broken Cryptography',
            'Side-channel Attacks',
            'Advanced Side-channel Attacks',
            'Cache Timing Attack',
            'Quantum Attacks (theoretical)',
            'Zero Interaction Attacks (e.g. IoT)'
        ]
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        vulnerabilities = []
        
        # الحصول على عنوان URL للهدف
        if target.get_hostname():
            base_url = f"http://{target.get_hostname()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_hostname()}"
            host = target.get_hostname()
        else:
            base_url = f"http://{target.get_ip()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_ip()}"
            host = target.get_ip()
        
        # فحص ثغرات التشفير
        try:
            # فحص ثغرات SSL/TLS
            ssl_vulns = self._check_ssl_vulnerabilities(host)
            vulnerabilities.extend(ssl_vulns)
            
            # فحص استخدام خوارزميات تشفير ضعيفة
            crypto_vulns = self._check_weak_crypto(base_url)
            vulnerabilities.extend(crypto_vulns)
            
            # فحص ثغرات التشفير في الكوكيز
            cookie_vulns = self._check_cookie_crypto(base_url)
            vulnerabilities.extend(cookie_vulns)
            
            # فحص ثغرات التشفير في JWT
            jwt_vulns = self._check_jwt_vulnerabilities(base_url)
            vulnerabilities.extend(jwt_vulns)
            
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص ثغرات التشفير: {str(e)}")
        
        # إضافة الثغرات إلى الهدف
        for vuln in vulnerabilities:
            target.add_vulnerability(vuln)
        
        return vulnerabilities
    
    def _make_request(self, url, method='GET', data=None, params=None, headers=None, follow_redirects=True):
        """إجراء طلب HTTP"""
        try:
            req_headers = {
                'User-Agent': 'UltimateScan/1.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            if headers:
                req_headers.update(headers)
                
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                response = requests.post(
                    url,
                    data=data,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            else:
                return None
            
            return response
        except Exception as e:
            if self.verbose:
                print(f"خطأ في إجراء طلب HTTP: {str(e)}")
            return None
    
    def _check_ssl_vulnerabilities(self, host):
        """فحص ثغرات SSL/TLS"""
        vulnerabilities = []
        
        try:
            # فحص دعم بروتوكولات SSL/TLS القديمة
            protocols = {
                ssl.PROTOCOL_SSLv23: 'SSLv2/SSLv3',
                ssl.PROTOCOL_TLSv1: 'TLSv1.0',
                ssl.PROTOCOL_TLSv1_1: 'TLSv1.1'
            }
            
            for protocol, name in protocols.items():
                try:
                    context = ssl.SSLContext(protocol)
                    context.check_hostname = False
                    context.verify_mode = ssl.CERT_NONE
                    
                    with socket.create_connection((host, 443), timeout=self.timeout) as sock:
                        with context.wrap_socket(sock, server_hostname=host) as ssock:
                            cipher = ssock.cipher()
                            if cipher:
                                vuln = self.create_vulnerability(
                                    vuln_type='Outdated SSL/TLS Protocol',
                                    severity='high',
                                    description=f'الخادم يدعم بروتوكول SSL/TLS قديم: {name}',
                                    location={
                                        'host': host,
                                        'port': 443,
                                        'protocol': name
                                    },
                                    exploit_info={
                                        'cipher': cipher[0],
                                        'protocol': name
                                    },
                                    recommendation='تعطيل بروتوكولات SSL/TLS القديمة وتفعيل TLSv1.2 أو أحدث فقط',
                                    references=[
                                        'https://www.acunetix.com/vulnerabilities/web/outdated-ssl-protocol/',
                                        'https://www.owasp.org/index.php/Transport_Layer_Protection_Cheat_Sheet'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                except:
                    pass
            
            # فحص دعم خوارزميات التشفير الضعيفة
            try:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                with socket.create_connection((host, 443), timeout=self.timeout) as sock:
                    with context.wrap_socket(sock, server_hostname=host) as ssock:
                        cipher = ssock.cipher()
                        if cipher and any(weak in cipher[0].lower() for weak in ['rc4', 'des', '3des', 'md5', 'null', 'anon', 'export']):
                            vuln = self.create_vulnerability(
                                vuln_type='Weak SSL/TLS Cipher',
                                severity='high',
                                description=f'الخادم يدعم خوارزمية تشفير ضعيفة: {cipher[0]}',
                                location={
                                    'host': host,
                                    'port': 443,
                                    'cipher': cipher[0]
                                },
                                recommendation='تعطيل خوارزميات التشفير الضعيفة وتفعيل الخوارزميات القوية فقط',
                                references=[
                                    'https://www.acunetix.com/vulnerabilities/web/weak-ssl-tls-ciphers/',
                                    'https://www.owasp.org/index.php/Transport_Layer_Protection_Cheat_Sheet'
                                ]
                            )
                            vulnerabilities.append(vuln)
            except:
                pass
            
            # فحص ثغرة Heartbleed
            try:
                import struct
                import binascii
                
                # إنشاء حزمة Heartbeat
                heartbeat_payload = b'\x18\x03\x02\x00\x03\x01\x40\x00'
                
                with socket.create_connection((host, 443), timeout=self.timeout) as sock:
                    sock.send(heartbeat_payload)
                    response = sock.recv(1024)
                    
                    if len(response) > 8:
                        vuln = self.create_vulnerability(
                            vuln_type='Heartbleed Vulnerability',
                            severity='critical',
                            description='الخادم معرض لثغرة Heartbleed',
                            location={
                                'host': host,
                                'port': 443
                            },
                            recommendation='ترقية OpenSSL إلى أحدث إصدار',
                            references=[
                                'https://heartbleed.com/',
                                'https://www.acunetix.com/vulnerabilities/web/heartbleed-vulnerability/'
                            ]
                        )
                        vulnerabilities.append(vuln)
            except:
                pass
            
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص ثغرات SSL/TLS: {str(e)}")
        
        return vulnerabilities
    
    def _check_weak_crypto(self, base_url):
        """فحص استخدام خوارزميات تشفير ضعيفة"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/login', '/register', '/signup', '/account', '/profile',
            '/user', '/admin', '/dashboard', '/settings', '/config',
            '/api', '/api/v1', '/api/v2', '/rest', '/rest/v1', '/rest/v2'
        ]
        
        # قائمة بأنماط خوارزميات التشفير الضعيفة
        weak_crypto_patterns = {
            'md5': r'md5\(|MD5\(|hash\s*=\s*[\'"]md5[\'"]|encryption\s*=\s*[\'"]md5[\'"]',
            'sha1': r'sha1\(|SHA1\(|hash\s*=\s*[\'"]sha1[\'"]|encryption\s*=\s*[\'"]sha1[\'"]',
            'des': r'des\(|DES\(|encryption\s*=\s*[\'"]des[\'"]',
            'rc4': r'rc4\(|RC4\(|encryption\s*=\s*[\'"]rc4[\'"]',
            'base64': r'base64_encode\(|btoa\(|encryption\s*=\s*[\'"]base64[\'"]'
        }
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response:
                # التحقق من وجود أنماط خوارزميات التشفير الضعيفة
                for crypto_name, pattern in weak_crypto_patterns.items():
                    matches = re.findall(pattern, response.text)
                    
                    if matches:
                        vuln = self.create_vulnerability(
                            vuln_type='Weak Cryptography',
                            severity='high',
                            description=f'الموقع يستخدم خوارزمية تشفير ضعيفة: {crypto_name}',
                            location={
                                'url': url
                            },
                            recommendation='استخدام خوارزميات تشفير قوية مثل AES و SHA-256 وما فوق',
                            references=[
                                'https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure',
                                'https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html'
                            ]
                        )
                        vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _check_cookie_crypto(self, base_url):
        """فحص ثغرات التشفير في الكوكيز"""
        vulnerabilities = []
        
        # إرسال الطلب
        response = self._make_request(base_url)
        
        if response and response.cookies:
            # التحقق من وجود كوكيز غير آمنة
            for cookie in response.cookies:
                # التحقق من عدم وجود علامة Secure
                if not cookie.secure:
                    vuln = self.create_vulnerability(
                        vuln_type='Insecure Cookie',
                        severity='medium',
                        description=f'الكوكي {cookie.name} غير مؤمنة (بدون علامة Secure)',
                        location={
                            'url': base_url,
                            'cookie': cookie.name
                        },
                        recommendation='إضافة علامة Secure إلى جميع الكوكيز الحساسة',
                        references=[
                            'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/06-Session_Management_Testing/02-Testing_for_Cookies_Attributes',
                            'https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html'
                        ]
                    )
                    vulnerabilities.append(vuln)
                
                # التحقق من عدم وجود علامة HttpOnly
                if not cookie.has_nonstandard_attr('HttpOnly'):
                    vuln = self.create_vulnerability(
                        vuln_type='Insecure Cookie',
                        severity='medium',
                        description=f'الكوكي {cookie.name} غير مؤمنة (بدون علامة HttpOnly)',
                        location={
                            'url': base_url,
                            'cookie': cookie.name
                        },
                        recommendation='إضافة علامة HttpOnly إلى جميع الكوكيز الحساسة',
                        references=[
                            'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/06-Session_Management_Testing/02-Testing_for_Cookies_Attributes',
                            'https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html'
                        ]
                    )
                    vulnerabilities.append(vuln)
                
                # التحقق من عدم وجود علامة SameSite
                if not cookie.has_nonstandard_attr('SameSite'):
                    vuln = self.create_vulnerability(
                        vuln_type='Insecure Cookie',
                        severity='low',
                        description=f'الكوكي {cookie.name} غير مؤمنة (بدون علامة SameSite)',
                        location={
                            'url': base_url,
                            'cookie': cookie.name
                        },
                        recommendation='إضافة علامة SameSite=Strict أو SameSite=Lax إلى جميع الكوكيز',
                        references=[
                            'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/06-Session_Management_Testing/02-Testing_for_Cookies_Attributes',
                            'https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html'
                        ]
                    )
                    vulnerabilities.append(vuln)
                
                # التحقق من تشفير الكوكي
                if cookie.value and (len(cookie.value) % 4 == 0 or '=' in cookie.value):
                    try:
                        # محاولة فك تشفير Base64
                        import base64
                        decoded = base64.b64decode(cookie.value.strip('=') + '==')
                        
                        if decoded and len(decoded) > 0:
                            vuln = self.create_vulnerability(
                                vuln_type='Weak Cookie Encryption',
                                severity='high',
                                description=f'الكوكي {cookie.name} تستخدم تشفير ضعيف (Base64)',
                                location={
                                    'url': base_url,
                                    'cookie': cookie.name
                                },
                                recommendation='استخدام تشفير قوي للكوكيز الحساسة',
                                references=[
                                    'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/06-Session_Management_Testing/02-Testing_for_Cookies_Attributes',
                                    'https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html'
                                ]
                            )
                            vulnerabilities.append(vuln)
                    except:
                        pass
        
        return vulnerabilities
    
    def _check_jwt_vulnerabilities(self, base_url):
        """فحص ثغرات التشفير في JWT"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/login', '/api', '/api/v1', '/api/v2', '/rest', '/rest/v1', '/rest/v2',
            '/auth', '/auth/login', '/auth/token', '/token', '/oauth', '/oauth/token'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response:
                # التحقق من وجود JWT في الاستجابة
                jwt_pattern = r'eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+'
                jwt_matches = re.findall(jwt_pattern, response.text)
                
                # التحقق من وجود JWT في الكوكيز
                if response.cookies:
                    for cookie in response.cookies:
                        if re.match(jwt_pattern, cookie.value):
                            jwt_matches.append(cookie.value)
                
                # التحقق من وجود JWT في الرؤوس
                auth_header = response.headers.get('Authorization', '')
                if 'Bearer ' in auth_header:
                    token = auth_header.split('Bearer ')[1]
                    if re.match(jwt_pattern, token):
                        jwt_matches.append(token)
                
                # فحص كل JWT
                for jwt in jwt_matches:
                    # تحليل JWT
                    try:
                        import base64
                        import json
                        
                        # تقسيم JWT إلى أجزاء
                        parts = jwt.split('.')
                        if len(parts) != 3:
                            continue
                        
                        # فك تشفير الرأس
                        header_b64 = parts[0]
                        header_padding = '=' * (4 - len(header_b64) % 4)
                        header_json = base64.b64decode(header_b64 + header_padding).decode('utf-8')
                        header = json.loads(header_json)
                        
                        # التحقق من خوارزمية التوقيع
                        alg = header.get('alg', '')
                        
                        if alg == 'none':
                            vuln = self.create_vulnerability(
                                vuln_type='JWT None Algorithm',
                                severity='critical',
                                description='الموقع يستخدم JWT مع خوارزمية توقيع "none"',
                                location={
                                    'url': url
                                },
                                exploit_info={
                                    'jwt': jwt,
                                    'header': header
                                },
                                recommendation='عدم قبول JWT مع خوارزمية توقيع "none"',
                                references=[
                                    'https://auth0.com/blog/critical-vulnerabilities-in-json-web-token-libraries/',
                                    'https://www.nccgroup.com/uk/about-us/newsroom-and-events/blogs/2019/january/jwt-attack-walk-through/'
                                ]
                            )
                            vulnerabilities.append(vuln)
                        
                        if alg in ['HS256', 'HS384', 'HS512']:
                            # فحص استخدام مفتاح ضعيف
                            weak_keys = ['secret', 'key', 'password', '123456', 'qwerty', 'admin', 'test']
                            
                            for weak_key in weak_keys:
                                try:
                                    import hmac
                                    import hashlib
                                    
                                    # إنشاء توقيع جديد
                                    message = f"{parts[0]}.{parts[1]}"
                                    
                                    if alg == 'HS256':
                                        signature = hmac.new(weak_key.encode(), message.encode(), hashlib.sha256).digest()
                                    elif alg == 'HS384':
                                        signature = hmac.new(weak_key.encode(), message.encode(), hashlib.sha384).digest()
                                    else:  # HS512
                                        signature = hmac.new(weak_key.encode(), message.encode(), hashlib.sha512).digest()
                                    
                                    # تحويل التوقيع إلى Base64URL
                                    signature_b64 = base64.b64encode(signature).decode('utf-8').replace('+', '-').replace('/', '_').rstrip('=')
                                    
                                    if signature_b64 == parts[2]:
                                        vuln = self.create_vulnerability(
                                            vuln_type='JWT Weak Secret Key',
                                            severity='critical',
                                            description=f'الموقع يستخدم JWT مع مفتاح سري ضعيف: {weak_key}',
                                            location={
                                                'url': url
                                            },
                                            exploit_info={
                                                'jwt': jwt,
                                                'header': header,
                                                'weak_key': weak_key
                                            },
                                            recommendation='استخدام مفتاح سري قوي وعشوائي لتوقيع JWT',
                                            references=[
                                                'https://auth0.com/blog/brute-forcing-hs256-is-possible-the-importance-of-using-strong-keys-to-sign-jwts/',
                                                'https://www.nccgroup.com/uk/about-us/newsroom-and-events/blogs/2019/january/jwt-attack-walk-through/'
                                            ]
                                        )
                                        vulnerabilities.append(vuln)
                                        break
                                except:
                                    pass
                    except:
                        pass
        
        return vulnerabilities
