#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص الهجمات المتقدمة
تتضمن فحوصات للهجمات المتقدمة مثل Advanced Persistent Threats و Race Condition وغيرها
"""

import re
import time
import random
import requests
import urllib.parse
from .base_scanner import VulnerabilityScanner

class AdvancedAttackScanner(VulnerabilityScanner):
    """فاحص الهجمات المتقدمة"""
    
    def __init__(self, config=None):
        """تهيئة الفاحص"""
        super().__init__(config)
        
    def get_description(self):
        """الحصول على وصف الفاحص"""
        return "فاحص الهجمات المتقدمة الشامل"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return [
            'Race Condition',
            'Race Condition Exploits in Blockchain',
            'Advanced Persistent Threats (APT)',
            'Zero-day Vulnerabilities',
            'Cryptojacking',
            'Click Fraud',
            'Watering Hole Attack',
            'Logic Bombs',
            'Zero Interaction Attacks (e.g. IoT)',
            'Data Exfiltration via Covert Channels',
            'Social Media Exploits',
            'Phishing Kits',
            'Out-of-Band Exploits',
            'Malvertising'
        ]
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        vulnerabilities = []
        
        # الحصول على عنوان URL للهدف
        if target.get_hostname():
            base_url = f"http://{target.get_hostname()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_hostname()}"
            host = target.get_hostname()
        else:
            base_url = f"http://{target.get_ip()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_ip()}"
            host = target.get_ip()
        
        # فحص الهجمات المتقدمة
        try:
            # فحص ثغرات Race Condition
            race_vulns = self._check_race_condition(base_url)
            vulnerabilities.extend(race_vulns)
            
            # فحص ثغرات Cryptojacking
            crypto_vulns = self._check_cryptojacking(base_url)
            vulnerabilities.extend(crypto_vulns)
            
            # فحص ثغرات Logic Bombs
            logic_vulns = self._check_logic_bombs(base_url)
            vulnerabilities.extend(logic_vulns)
            
            # فحص ثغرات Data Exfiltration
            exfil_vulns = self._check_data_exfiltration(base_url)
            vulnerabilities.extend(exfil_vulns)
            
            # فحص ثغرات Phishing Kits
            phishing_vulns = self._check_phishing_kits(base_url)
            vulnerabilities.extend(phishing_vulns)
            
            # فحص ثغرات Malvertising
            malvert_vulns = self._check_malvertising(base_url)
            vulnerabilities.extend(malvert_vulns)
            
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص الهجمات المتقدمة: {str(e)}")
        
        # إضافة الثغرات إلى الهدف
        for vuln in vulnerabilities:
            target.add_vulnerability(vuln)
        
        return vulnerabilities
    
    def _make_request(self, url, method='GET', data=None, params=None, headers=None, json_data=None, follow_redirects=True):
        """إجراء طلب HTTP"""
        try:
            req_headers = {
                'User-Agent': 'UltimateScan/1.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            if headers:
                req_headers.update(headers)
                
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                if json_data:
                    response = requests.post(
                        url,
                        json=json_data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=False,
                        allow_redirects=follow_redirects
                    )
                else:
                    response = requests.post(
                        url,
                        data=data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=False,
                        allow_redirects=follow_redirects
                    )
            else:
                return None
            
            return response
        except Exception as e:
            if self.verbose:
                print(f"خطأ في إجراء طلب HTTP: {str(e)}")
            return None
    
    def _check_race_condition(self, base_url):
        """فحص ثغرات Race Condition"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/api/transfer', '/api/payment', '/api/transaction', '/api/order',
            '/api/purchase', '/api/credit', '/api/debit', '/api/withdraw',
            '/api/deposit', '/api/balance', '/api/account', '/api/user',
            '/api/profile', '/api/update', '/api/create', '/api/delete',
            '/transfer', '/payment', '/transaction', '/order', '/purchase',
            '/credit', '/debit', '/withdraw', '/deposit', '/balance',
            '/account', '/user', '/profile', '/update', '/create', '/delete'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إنشاء بيانات الطلب
            data = {
                'amount': '10',
                'from': 'account1',
                'to': 'account2',
                'id': str(random.randint(1000, 9999)),
                'token': str(random.randint(100000, 999999))
            }
            
            # إرسال طلبات متزامنة
            responses = []
            try:
                # إرسال 5 طلبات متزامنة
                import threading
                
                def send_request():
                    response = self._make_request(url, method='POST', json_data=data, headers={'Content-Type': 'application/json'})
                    if response:
                        responses.append(response)
                
                threads = []
                for _ in range(5):
                    thread = threading.Thread(target=send_request)
                    threads.append(thread)
                    thread.start()
                
                for thread in threads:
                    thread.join()
                
                # تحليل الاستجابات
                if len(responses) > 1:
                    status_codes = [response.status_code for response in responses]
                    response_texts = [response.text for response in responses]
                    
                    # التحقق من وجود اختلافات في الاستجابات
                    if len(set(status_codes)) > 1 or len(set(response_texts)) > 1:
                        vuln = self.create_vulnerability(
                            vuln_type='Race Condition',
                            severity='high',
                            description='الموقع قد يكون معرضاً لثغرة Race Condition',
                            location={
                                'url': url,
                                'method': 'POST'
                            },
                            exploit_info={
                                'data': data,
                                'method': 'POST',
                                'responses': [
                                    {
                                        'status_code': response.status_code,
                                        'content_length': len(response.text)
                                    } for response in responses[:3]  # أول 3 استجابات فقط
                                ]
                            },
                            recommendation='تنفيذ آليات التزامن المناسبة وقفل الموارد أثناء المعاملات',
                            references=[
                                'https://owasp.org/www-community/vulnerabilities/Race_Condition_Vulnerability',
                                'https://cwe.mitre.org/data/definitions/362.html'
                            ]
                        )
                        vulnerabilities.append(vuln)
            except:
                pass
        
        return vulnerabilities
    
    def _check_cryptojacking(self, base_url):
        """فحص ثغرات Cryptojacking"""
        vulnerabilities = []
        
        # إرسال الطلب
        response = self._make_request(base_url)
        
        if response:
            # قائمة بأنماط Cryptojacking
            patterns = [
                r'coinhive\.min\.js',
                r'\/lib\/cryptonight.*?\.js',
                r'\/lib\/cryptonight.*?\.wasm',
                r'coin-hive\.com',
                r'jsecoin\.com',
                r'crypto-loot\.com',
                r'webmine\.cz',
                r'miner\.start\(',
                r'new CoinHive\.Anonymous',
                r'new CryptoLoot\.Anonymous',
                r'\.startMining\(',
                r'deepMiner',
                r'minero\.cc',
                r'coinimp\.com',
                r'authedmine\.com',
                r'ppoi\.org',
                r'projectpoi\.com',
                r'monero\-miner',
                r'CryptoNoter',
                r'nerohut\.com',
                r'xmrstudio',
                r'coinrail\.io',
                r'minexmr\.com',
                r'cryptoloot\.pro',
                r'coinerra\.com',
                r'coin\-service\.com',
                r'minr\.pw',
                r'statdynamic\.com',
                r'browsermine\.com',
                r'service4refresh\.info',
                r'jquerystatistic\.com',
                r'cryweb\.github\.io',
                r'crywebber\.github\.io'
            ]
            
            # التحقق من وجود أنماط Cryptojacking
            for pattern in patterns:
                matches = re.findall(pattern, response.text, re.IGNORECASE)
                
                if matches:
                    vuln = self.create_vulnerability(
                        vuln_type='Cryptojacking',
                        severity='medium',
                        description='الموقع قد يحتوي على برامج تعدين العملات الرقمية',
                        location={
                            'url': base_url,
                            'matches': matches[:5]  # أول 5 تطابقات فقط
                        },
                        recommendation='إزالة برامج تعدين العملات الرقمية من الموقع وفحص الموقع للتأكد من عدم وجود اختراق',
                        references=[
                            'https://www.malwarebytes.com/cryptojacking',
                            'https://www.imperva.com/learn/application-security/cryptojacking/'
                        ]
                    )
                    vulnerabilities.append(vuln)
                    break
        
        return vulnerabilities
    
    def _check_logic_bombs(self, base_url):
        """فحص ثغرات Logic Bombs"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/admin', '/admin/index.php', '/admin/login.php', '/admin/admin.php',
            '/administrator', '/administrator/index.php', '/administrator/login.php',
            '/wp-admin', '/wp-login.php', '/login', '/login.php', '/auth', '/auth.php',
            '/dashboard', '/dashboard.php', '/panel', '/panel.php', '/cp', '/cp.php',
            '/control', '/control.php', '/manage', '/manage.php', '/management', '/management.php'
        ]
        
        # قائمة بالمعلمات المحتملة
        params = {
            'date': [
                '2099-12-31', '2100-01-01', '2038-01-19', '1970-01-01', '1969-12-31',
                '0000-00-00', '9999-99-99', '0', '-1', '1', 'null', 'undefined'
            ],
            'time': [
                '23:59:59', '00:00:00', '12:00:00', '0', '-1', '1', 'null', 'undefined'
            ],
            'admin': [
                'true', 'false', '1', '0', 'yes', 'no', 'on', 'off', 'null', 'undefined'
            ],
            'debug': [
                'true', 'false', '1', '0', 'yes', 'no', 'on', 'off', 'null', 'undefined'
            ],
            'test': [
                'true', 'false', '1', '0', 'yes', 'no', 'on', 'off', 'null', 'undefined'
            ],
            'mode': [
                'debug', 'test', 'development', 'production', 'staging', 'qa', 'null', 'undefined'
            ]
        }
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # فحص كل معلمة
            for param_name, param_values in params.items():
                for param_value in param_values:
                    # إنشاء معلمات الطلب
                    params_data = {param_name: param_value}
                    
                    # إرسال الطلب
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط Logic Bombs
                        if 'admin' in response.text.lower() and ('login' not in response.text.lower() or 'password' not in response.text.lower()):
                            vuln = self.create_vulnerability(
                                vuln_type='Potential Logic Bomb',
                                severity='high',
                                description='الموقع قد يحتوي على قنبلة منطقية',
                                location={
                                    'url': url,
                                    'parameter': param_name,
                                    'value': param_value
                                },
                                exploit_info={
                                    'exploit_url': f"{url}?{param_name}={urllib.parse.quote(param_value)}",
                                    'method': 'GET'
                                },
                                recommendation='مراجعة الكود للتحقق من وجود شروط خاصة قد تؤدي إلى سلوك غير متوقع',
                                references=[
                                    'https://owasp.org/www-community/attacks/Logic_Flaws',
                                    'https://cwe.mitre.org/data/definitions/511.html'
                                ]
                            )
                            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _check_data_exfiltration(self, base_url):
        """فحص ثغرات Data Exfiltration"""
        vulnerabilities = []
        
        # إرسال الطلب
        response = self._make_request(base_url)
        
        if response:
            # قائمة بأنماط Data Exfiltration
            patterns = [
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.pastebin\.com\/[a-zA-Z0-9]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.github\.io\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.s3\.amazonaws\.com\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.storage\.googleapis\.com\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.azureedge\.net\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.blob\.core\.windows\.net\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.appspot\.com\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.herokuapp\.com\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.glitch\.me\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.repl\.co\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.ngrok\.io\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.serveo\.net\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.loca\.lt\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.pagekite\.me\/[a-zA-Z0-9\-\.\/]+)',
                r'(https?:\/\/[a-zA-Z0-9\-\.]+\.localtunnel\.me\/[a-zA-Z0-9\-\.\/]+)',
                r'document\.location\s*=\s*[\'"]https?:\/\/[^\'"]+[\'"]\s*\+\s*document\.cookie',
                r'new\s+Image\(\)\.src\s*=\s*[\'"]https?:\/\/[^\'"]+[\'"]\s*\+\s*document\.cookie',
                r'fetch\([\'"]https?:\/\/[^\'"]+[\'"]\s*\+\s*document\.cookie\)',
                r'XMLHttpRequest\([\'"]https?:\/\/[^\'"]+[\'"]\s*\+\s*document\.cookie\)',
                r'navigator\.sendBeacon\([\'"]https?:\/\/[^\'"]+[\'"]\s*\+\s*document\.cookie\)',
                r'WebSocket\([\'"]wss?:\/\/[^\'"]+[\'"]\s*\+\s*document\.cookie\)'
            ]
            
            # التحقق من وجود أنماط Data Exfiltration
            for pattern in patterns:
                matches = re.findall(pattern, response.text, re.IGNORECASE)
                
                if matches:
                    vuln = self.create_vulnerability(
                        vuln_type='Data Exfiltration',
                        severity='high',
                        description='الموقع قد يحتوي على آليات لتسريب البيانات',
                        location={
                            'url': base_url,
                            'matches': matches[:5]  # أول 5 تطابقات فقط
                        },
                        recommendation='مراجعة الكود للتحقق من وجود آليات لتسريب البيانات وإزالتها',
                        references=[
                            'https://owasp.org/www-community/attacks/Cross_Site_Scripting_(XSS)',
                            'https://portswigger.net/web-security/cross-site-scripting'
                        ]
                    )
                    vulnerabilities.append(vuln)
                    break
        
        return vulnerabilities
    
    def _check_phishing_kits(self, base_url):
        """فحص ثغرات Phishing Kits"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/admin.php', '/admin.html', '/admin/', '/administrator/', '/login.php',
            '/login.html', '/login/', '/wp-login.php', '/sign-in.php', '/signin.php',
            '/sign-in.html', '/signin.html', '/sign-in/', '/signin/', '/auth.php',
            '/auth.html', '/auth/', '/webmail.php', '/webmail.html', '/webmail/',
            '/mail.php', '/mail.html', '/mail/', '/outlook.php', '/outlook.html',
            '/outlook/', '/office365.php', '/office365.html', '/office365/',
            '/microsoft.php', '/microsoft.html', '/microsoft/', '/google.php',
            '/google.html', '/google/', '/gmail.php', '/gmail.html', '/gmail/',
            '/yahoo.php', '/yahoo.html', '/yahoo/', '/facebook.php', '/facebook.html',
            '/facebook/', '/twitter.php', '/twitter.html', '/twitter/', '/linkedin.php',
            '/linkedin.html', '/linkedin/', '/instagram.php', '/instagram.html',
            '/instagram/', '/apple.php', '/apple.html', '/apple/', '/icloud.php',
            '/icloud.html', '/icloud/', '/paypal.php', '/paypal.html', '/paypal/',
            '/bank.php', '/bank.html', '/bank/', '/chase.php', '/chase.html', '/chase/',
            '/wellsfargo.php', '/wellsfargo.html', '/wellsfargo/', '/citibank.php',
            '/citibank.html', '/citibank/', '/bankofamerica.php', '/bankofamerica.html',
            '/bankofamerica/', '/amazon.php', '/amazon.html', '/amazon/', '/ebay.php',
            '/ebay.html', '/ebay/', '/netflix.php', '/netflix.html', '/netflix/',
            '/hulu.php', '/hulu.html', '/hulu/', '/spotify.php', '/spotify.html',
            '/spotify/', '/steam.php', '/steam.html', '/steam/', '/epicgames.php',
            '/epicgames.html', '/epicgames/', '/battle.net.php', '/battle.net.html',
            '/battle.net/', '/blizzard.php', '/blizzard.html', '/blizzard/',
            '/rockstar.php', '/rockstar.html', '/rockstar/', '/origin.php',
            '/origin.html', '/origin/', '/ubisoft.php', '/ubisoft.html', '/ubisoft/',
            '/discord.php', '/discord.html', '/discord/', '/slack.php', '/slack.html',
            '/slack/', '/zoom.php', '/zoom.html', '/zoom/', '/dropbox.php',
            '/dropbox.html', '/dropbox/', '/onedrive.php', '/onedrive.html',
            '/onedrive/', '/gdrive.php', '/gdrive.html', '/gdrive/', '/googledrive.php',
            '/googledrive.html', '/googledrive/'
        ]
        
        # قائمة بأنماط Phishing Kits
        phishing_patterns = [
            r'<title>[^<]*(?:sign\s*in|log\s*in|login|signin|sign\s*on|signon|account)[^<]*</title>',
            r'<form[^>]*(?:login|signin|sign\s*in|sign\s*on|signon)[^>]*>',
            r'<input[^>]*(?:user|email|mail|login|account|name)[^>]*>.*?<input[^>]*(?:pass|pwd)[^>]*>',
            r'<input[^>]*(?:pass|pwd)[^>]*>.*?<input[^>]*(?:user|email|mail|login|account|name)[^>]*>',
            r'<img[^>]*(?:logo|brand|header)[^>]*(?:microsoft|google|apple|facebook|twitter|linkedin|instagram|paypal|bank|chase|wellsfargo|citibank|bankofamerica|amazon|ebay|netflix|hulu|spotify|steam|epicgames|battle\.net|blizzard|rockstar|origin|ubisoft|discord|slack|zoom|dropbox|onedrive|gdrive|googledrive)[^>]*>',
            r'<div[^>]*(?:logo|brand|header)[^>]*(?:microsoft|google|apple|facebook|twitter|linkedin|instagram|paypal|bank|chase|wellsfargo|citibank|bankofamerica|amazon|ebay|netflix|hulu|spotify|steam|epicgames|battle\.net|blizzard|rockstar|origin|ubisoft|discord|slack|zoom|dropbox|onedrive|gdrive|googledrive)[^>]*>',
            r'action\s*=\s*[\'"][^\'"]*\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*post\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*process\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*submit\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*login\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*signin\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*validate\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*verify\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*auth\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*next\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*redirect\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*check\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*confirm\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*secure\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*security\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*update\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*upgrade\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*verification\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*validation\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*authenticate\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*authorization\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*authorisation\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*session\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*token\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*cookie\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*credentials\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*password\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*passwd\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*pwd\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*pass\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*user\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*username\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*userid\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*email\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*mail\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*account\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*profile\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*dashboard\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*panel\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*control\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*manage\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*management\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*admin\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*administrator\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*webmaster\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*master\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*root\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*system\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*sys\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*config\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*configuration\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*setup\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*install\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*installation\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*settings\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*options\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*preferences\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*prefs\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*pref\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*opt\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*option\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*setting\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*config\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*conf\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*configuration\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*configure\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*setup\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*install\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*installation\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*installer\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*installing\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*setup\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*install\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*installation\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*installer\.php[\'"]\s*',
            r'action\s*=\s*[\'"][^\'"]*installing\.php[\'"]\s*'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response and response.status_code == 200:
                # التحقق من وجود أنماط Phishing Kits
                for pattern in phishing_patterns:
                    if re.search(pattern, response.text, re.IGNORECASE):
                        vuln = self.create_vulnerability(
                            vuln_type='Phishing Kit',
                            severity='critical',
                            description='الموقع قد يحتوي على أدوات تصيد',
                            location={
                                'url': url
                            },
                            recommendation='إزالة أدوات التصيد من الموقع وفحص الموقع للتأكد من عدم وجود اختراق',
                            references=[
                                'https://www.phishing.org/what-is-phishing',
                                'https://www.imperva.com/learn/application-security/phishing-attack-scam/'
                            ]
                        )
                        vulnerabilities.append(vuln)
                        break
        
        return vulnerabilities
    
    def _check_malvertising(self, base_url):
        """فحص ثغرات Malvertising"""
        vulnerabilities = []
        
        # إرسال الطلب
        response = self._make_request(base_url)
        
        if response:
            # قائمة بأنماط Malvertising
            patterns = [
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.ru\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cn\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.xyz\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.top\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.club\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.site\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.online\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.fun\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.space\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.stream\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.pw\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cc\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.vip\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.win\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.bid\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.loan\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.men\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.gdn\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.kim\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.buzz\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.party\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.review\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.date\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.faith\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.cricket\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.science\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.racing\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.download\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.accountant\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.trade\/[^\'"]*[\'"]\s*',
                r'<iframe[^>]*src\s*=\s*[\'"]https?:\/\/[^\'"]+\.webcam\/[^\'"]*[\'"]\s*'
            ]
            
            # التحقق من وجود أنماط Malvertising
            for pattern in patterns:
                matches = re.findall(pattern, response.text, re.IGNORECASE)
                
                if matches:
                    vuln = self.create_vulnerability(
                        vuln_type='Malvertising',
                        severity='high',
                        description='الموقع قد يحتوي على إعلانات ضارة',
                        location={
                            'url': base_url,
                            'matches': matches[:5]  # أول 5 تطابقات فقط
                        },
                        recommendation='إزالة الإعلانات الضارة من الموقع وفحص الموقع للتأكد من عدم وجود اختراق',
                        references=[
                            'https://www.malwarebytes.com/malvertising',
                            'https://www.imperva.com/learn/application-security/malvertising/'
                        ]
                    )
                    vulnerabilities.append(vuln)
                    break
        
        return vulnerabilities
