#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة الماسح الأساسية
تتضمن الفئات الأساسية للماسح وأهداف الفحص
"""

import re
import uuid
import datetime
import requests
import urllib3
import os
import sys
import platform

# تعطيل تحذيرات SSL فقط إذا كان المستخدم قد طلب ذلك صراحة
# بشكل افتراضي، نحن نفعل التحقق من الشهادات
DISABLE_SSL_WARNINGS = os.environ.get('ULTIMATESCAN_DISABLE_SSL_WARNINGS', 'false').lower() == 'true'

# تكوين التحقق من شهادات SSL
if DISABLE_SSL_WARNINGS:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    print("[تحذير] تم تعطيل التحقق من شهادات SSL. هذا غير آمن!")

# التحقق من وجود شهادات CA في بيئة Termux
def check_ca_certificates():
    """التحقق من وجود شهادات CA في بيئة Termux"""
    is_termux = 'com.termux' in os.environ.get('PREFIX', '')
    
    if is_termux:
        ca_path = '/data/data/com.termux/files/usr/etc/tls/cert.pem'
        if not os.path.exists(ca_path):
            print("[تحذير] لم يتم العثور على شهادات CA في Termux.")
            print("[معلومات] قم بتثبيت شهادات CA باستخدام الأمر: pkg install ca-certificates")
            return False
    return True

# التحقق من وجود شهادات CA عند بدء التشغيل
check_ca_certificates()

class Target:
    """فئة هدف الفحص"""
    
    def __init__(self, ip=None, hostname=None):
        """تهيئة الهدف"""
        self.ip = ip
        self.hostname = hostname
        self.ports = {}
        self.vulnerabilities = []
    
    def get_ip(self):
        """الحصول على عنوان IP"""
        return self.ip
    
    def get_hostname(self):
        """الحصول على اسم المضيف"""
        return self.hostname
    
    def add_port(self, port, status):
        """إضافة منفذ"""
        self.ports[port] = status
    
    def get_ports(self):
        """الحصول على المنافذ"""
        return self.ports
    
    def add_vulnerability(self, vulnerability):
        """إضافة ثغرة"""
        self.vulnerabilities.append(vulnerability)
    
    def get_vulnerabilities(self):
        """الحصول على الثغرات"""
        return self.vulnerabilities
    
    def to_dict(self):
        """تحويل الهدف إلى قاموس"""
        return {
            'ip': self.ip,
            'hostname': self.hostname,
            'ports': self.ports,
            'vulnerabilities': self.vulnerabilities
        }

class VulnerabilityScanner:
    """الفئة الأساسية لماسح الثغرات"""
    
    def __init__(self, config=None):
        """تهيئة الماسح"""
        self.config = config or {}
        self.verbose = self.config.get('verbose', False)
        self.timeout = self.config.get('timeout', 10)
        self.verify_ssl = self.config.get('verify_ssl', True)
        
        # إذا كان المستخدم قد طلب تعطيل التحقق من الشهادات
        if self.config.get('disable_ssl_warnings', False):
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            if self.verbose:
                print("[تحذير] تم تعطيل التحقق من شهادات SSL. هذا غير آمن!")
    
    def get_description(self):
        """الحصول على وصف الماسح"""
        return "الماسح الأساسي"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return []
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        raise NotImplementedError("يجب تنفيذ هذه الدالة في الفئات الفرعية")
    
    def create_vulnerability(self, vuln_type, severity, description, location, exploit_info=None, recommendation=None, references=None):
        """إنشاء ثغرة"""
        vuln_id = str(uuid.uuid4())
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        vulnerability = {
            'id': vuln_id,
            'type': vuln_type,
            'severity': severity,
            'description': description,
            'location': location,
            'timestamp': timestamp
        }
        
        if exploit_info:
            vulnerability['exploit_info'] = exploit_info
        
        if recommendation:
            vulnerability['recommendation'] = recommendation
        
        if references:
            vulnerability['references'] = references
        
        return vulnerability
    
    def make_request(self, url, method='GET', data=None, params=None, headers=None, json_data=None, follow_redirects=True):
        """إجراء طلب HTTP مع التحقق من شهادات SSL بشكل افتراضي"""
        try:
            req_headers = {
                'User-Agent': 'UltimateScan/2.0 (Open Source)',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            if headers:
                req_headers.update(headers)
                
            # استخدام التحقق من الشهادات بشكل افتراضي
            verify = self.verify_ssl
            
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=verify,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                if json_data:
                    response = requests.post(
                        url,
                        json=json_data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=verify,
                        allow_redirects=follow_redirects
                    )
                else:
                    response = requests.post(
                        url,
                        data=data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=verify,
                        allow_redirects=follow_redirects
                    )
            elif method.upper() == 'PUT':
                if json_data:
                    response = requests.put(
                        url,
                        json=json_data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=verify,
                        allow_redirects=follow_redirects
                    )
                else:
                    response = requests.put(
                        url,
                        data=data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=verify,
                        allow_redirects=follow_redirects
                    )
            elif method.upper() == 'DELETE':
                response = requests.delete(
                    url,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=verify,
                    allow_redirects=follow_redirects
                )
            else:
                return None
            
            return response
        except requests.exceptions.SSLError as e:
            if self.verbose:
                print(f"[خطأ SSL] {str(e)}")
                print("[معلومات] قد تحتاج إلى تثبيت شهادات CA باستخدام: pkg install ca-certificates")
            return None
        except Exception as e:
            if self.verbose:
                print(f"[خطأ] {str(e)}")
            return None
