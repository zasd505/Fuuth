#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UltimateScan - أداة فحص الثغرات الأمنية الشاملة (مفتوحة المصدر)
تدعم فحص واستغلال أكثر من 88 نوع من الثغرات الأمنية
متوافقة مع Termux على الأجهزة المحمولة
"""

import os
import sys
import time
import json
import argparse
import datetime
import threading
import importlib
import traceback
import urllib3
import requests
from pathlib import Path

# إضافة مسار المشروع إلى مسارات البحث
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

# تكوين التحقق من شهادات SSL
VERIFY_SSL = os.environ.get('ULTIMATESCAN_DISABLE_SSL_VERIFY', 'false').lower() != 'true'
if not VERIFY_SSL:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    print("[تحذير] تم تعطيل التحقق من شهادات SSL. هذا غير آمن!")

# استيراد الوحدات
from modules.base_scanner import Target, VulnerabilityScanner, check_ca_certificates
from utils.report_generator import ReportGenerator
from exploits.exploit_tools import ExploitManager

# قائمة بالوحدات المتاحة
AVAILABLE_MODULES = [
    'modules.web_vulnerabilities',
    'modules.network_vulnerabilities',
    'modules.application_vulnerabilities',
    'modules.crypto_vulnerabilities',
    'modules.system_vulnerabilities',
    'modules.api_vulnerabilities',
    'modules.advanced_attacks'
]

class UltimateScan:
    """الفئة الرئيسية لأداة UltimateScan"""
    
    def __init__(self, config=None):
        """تهيئة الأداة"""
        self.config = config or {}
        self.verbose = self.config.get('verbose', False)
        self.scanners = []
        self.targets = []
        self.scan_results = {
            'start_time': '',
            'end_time': '',
            'duration': '',
            'targets': []
        }
        
        # التحقق من وجود شهادات CA
        check_ca_certificates()
        
        # تكوين التحقق من شهادات SSL
        self.config['verify_ssl'] = VERIFY_SSL
        
        self.exploit_manager = ExploitManager(self.config)
        self.report_generator = ReportGenerator(self.config)
        
        # تحميل الماسحات
        self._load_scanners()
    
    def _load_scanners(self):
        """تحميل الماسحات المتاحة"""
        for module_name in AVAILABLE_MODULES:
            try:
                module = importlib.import_module(module_name)
                
                # البحث عن جميع الفئات التي ترث من VulnerabilityScanner
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if isinstance(attr, type) and issubclass(attr, VulnerabilityScanner) and attr != VulnerabilityScanner:
                        scanner = attr(self.config)
                        self.scanners.append(scanner)
                        
                        if self.verbose:
                            print(f"تم تحميل الماسح: {scanner.get_description()}")
            except Exception as e:
                if self.verbose:
                    print(f"خطأ في تحميل الوحدة {module_name}: {str(e)}")
    
    def add_target(self, target):
        """إضافة هدف للفحص"""
        if isinstance(target, Target):
            self.targets.append(target)
        elif isinstance(target, str):
            # التحقق مما إذا كان الهدف عنوان IP أو اسم مضيف
            if self._is_ip(target):
                self.targets.append(Target(ip=target))
            else:
                self.targets.append(Target(hostname=target))
        else:
            raise ValueError("الهدف يجب أن يكون كائن Target أو سلسلة نصية")
    
    def _is_ip(self, s):
        """التحقق مما إذا كانت السلسلة النصية عنوان IP"""
        parts = s.split('.')
        if len(parts) != 4:
            return False
        for part in parts:
            try:
                num = int(part)
                if num < 0 or num > 255:
                    return False
            except ValueError:
                return False
        return True
    
    def scan(self, progress_callback=None):
        """فحص الأهداف"""
        if not self.targets:
            raise ValueError("لا توجد أهداف للفحص")
        
        if not self.scanners:
            raise ValueError("لا توجد ماسحات متاحة")
        
        # تسجيل وقت البدء
        start_time = datetime.datetime.now()
        self.scan_results['start_time'] = start_time.strftime('%Y-%m-%d %H:%M:%S')
        
        # فحص كل هدف
        for target_index, target in enumerate(self.targets):
            if self.verbose:
                print(f"فحص الهدف {target_index + 1}/{len(self.targets)}: {target.get_hostname() or target.get_ip()}")
            
            # فحص كل ماسح
            for scanner_index, scanner in enumerate(self.scanners):
                if self.verbose:
                    print(f"  استخدام الماسح {scanner_index + 1}/{len(self.scanners)}: {scanner.get_description()}")
                
                # تحديث التقدم
                if progress_callback:
                    progress = {
                        'target_index': target_index,
                        'target_count': len(self.targets),
                        'scanner_index': scanner_index,
                        'scanner_count': len(self.scanners),
                        'target': target.get_hostname() or target.get_ip(),
                        'scanner': scanner.get_description()
                    }
                    progress_callback(progress)
                
                # فحص الهدف
                try:
                    vulnerabilities = scanner.scan(target, progress_callback)
                    
                    if self.verbose and vulnerabilities:
                        print(f"    تم العثور على {len(vulnerabilities)} ثغرة")
                except Exception as e:
                    if self.verbose:
                        print(f"    خطأ في الفحص: {str(e)}")
                        traceback.print_exc()
            
            # إضافة الهدف إلى نتائج الفحص
            self.scan_results['targets'].append(target.to_dict())
        
        # تسجيل وقت الانتهاء
        end_time = datetime.datetime.now()
        self.scan_results['end_time'] = end_time.strftime('%Y-%m-%d %H:%M:%S')
        
        # حساب المدة
        duration = end_time - start_time
        hours, remainder = divmod(duration.total_seconds(), 3600)
        minutes, seconds = divmod(remainder, 60)
        self.scan_results['duration'] = f"{int(hours)}:{int(minutes)}:{int(seconds)}"
        
        return self.scan_results
    
    def exploit_vulnerability(self, vulnerability, target=None, progress_callback=None):
        """استغلال ثغرة"""
        return self.exploit_manager.exploit_vulnerability(vulnerability, target, progress_callback)
    
    def generate_report(self, report_type='html', output_file=None):
        """إنشاء تقرير"""
        return self.report_generator.generate_report(self.scan_results, report_type, output_file)
    
    def open_report(self, report_file):
        """فتح التقرير"""
        return self.report_generator.open_report(report_file)


class ProgressBar:
    """شريط التقدم"""
    
    def __init__(self, total=100, prefix='', suffix='', decimals=1, length=50, fill='█', print_end='\r'):
        """تهيئة شريط التقدم"""
        self.total = total
        self.prefix = prefix
        self.suffix = suffix
        self.decimals = decimals
        self.length = length
        self.fill = fill
        self.print_end = print_end
        self.iteration = 0
        self.start_time = time.time()
    
    def update(self, iteration=None):
        """تحديث شريط التقدم"""
        if iteration is not None:
            self.iteration = iteration
        else:
            self.iteration += 1
        
        percent = ("{0:." + str(self.decimals) + "f}").format(100 * (self.iteration / float(self.total)))
        filled_length = int(self.length * self.iteration // self.total)
        bar = self.fill * filled_length + '-' * (self.length - filled_length)
        
        # حساب الوقت المتبقي
        elapsed_time = time.time() - self.start_time
        if self.iteration > 0:
            eta = elapsed_time * (self.total / self.iteration - 1)
            eta_str = self._format_time(eta)
        else:
            eta_str = "؟"
        
        # طباعة شريط التقدم
        print(f'\r{self.prefix} |{bar}| {percent}% {self.suffix} (المتبقي: {eta_str})', end=self.print_end)
        
        # إذا اكتمل، انتقل إلى سطر جديد
        if self.iteration == self.total:
            print()
    
    def _format_time(self, seconds):
        """تنسيق الوقت"""
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            minutes, seconds = divmod(seconds, 60)
            return f"{int(minutes)}m {int(seconds)}s"
        else:
            hours, remainder = divmod(seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            return f"{int(hours)}h {int(minutes)}m {int(seconds)}s"


def parse_args():
    """تحليل معلمات سطر الأوامر"""
    parser = argparse.ArgumentParser(description='UltimateScan - أداة فحص الثغرات الأمنية الشاملة (مفتوحة المصدر)')
    
    # معلمات الهدف
    target_group = parser.add_argument_group('الهدف')
    target_group.add_argument('-t', '--target', help='هدف الفحص (عنوان IP أو اسم مضيف)')
    target_group.add_argument('-f', '--file', help='ملف يحتوي على قائمة بالأهداف (سطر لكل هدف)')
    
    # معلمات الفحص
    scan_group = parser.add_argument_group('الفحص')
    scan_group.add_argument('-p', '--ports', help='المنافذ للفحص (مثال: 80,443,8080)')
    scan_group.add_argument('-m', '--modules', help='وحدات الفحص للاستخدام (مثال: web,network,api)')
    scan_group.add_argument('-a', '--all', action='store_true', help='استخدام جميع وحدات الفحص')
    
    # معلمات التقرير
    report_group = parser.add_argument_group('التقرير')
    report_group.add_argument('-o', '--output', help='ملف الإخراج للتقرير')
    report_group.add_argument('-r', '--report-type', choices=['html', 'json', 'text'], default='html', help='نوع التقرير')
    
    # معلمات الأمان
    security_group = parser.add_argument_group('الأمان')
    security_group.add_argument('--disable-ssl-verify', action='store_true', help='تعطيل التحقق من شهادات SSL (غير آمن)')
    
    # معلمات أخرى
    parser.add_argument('-v', '--verbose', action='store_true', help='عرض معلومات مفصلة')
    parser.add_argument('--version', action='version', version='UltimateScan 2.1 (Open Source)')
    
    return parser.parse_args()


def progress_callback(progress):
    """دالة استدعاء التقدم"""
    target_index = progress.get('target_index', 0)
    target_count = progress.get('target_count', 0)
    scanner_index = progress.get('scanner_index', 0)
    scanner_count = progress.get('scanner_count', 0)
    target = progress.get('target', '')
    scanner = progress.get('scanner', '')
    
    # حساب التقدم الإجمالي
    total_progress = (target_index * scanner_count + scanner_index) / (target_count * scanner_count) * 100
    
    # طباعة التقدم
    print(f"\rالتقدم: {total_progress:.1f}% | الهدف: {target} | الماسح: {scanner}", end='')


def main():
    """الدالة الرئيسية"""
    # تحليل معلمات سطر الأوامر
    args = parse_args()
    
    # تكوين التحقق من شهادات SSL
    if args.disable_ssl_verify:
        os.environ['ULTIMATESCAN_DISABLE_SSL_VERIFY'] = 'true'
        print("[تحذير] تم تعطيل التحقق من شهادات SSL. هذا غير آمن!")
    
    # إنشاء كائن UltimateScan
    config = {
        'verbose': args.verbose,
        'disable_ssl_warnings': args.disable_ssl_verify
    }
    scanner = UltimateScan(config)
    
    # إضافة الأهداف
    targets = []
    
    if args.target:
        targets.append(args.target)
    
    if args.file:
        try:
            with open(args.file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        targets.append(line)
        except Exception as e:
            print(f"خطأ في قراءة ملف الأهداف: {str(e)}")
            return
    
    if not targets:
        print("يجب تحديد هدف واحد على الأقل")
        return
    
    # إضافة الأهداف إلى الماسح
    for target in targets:
        scanner.add_target(target)
    
    # إنشاء شريط التقدم
    total_scans = len(targets) * len(scanner.scanners)
    progress_bar = ProgressBar(total=total_scans, prefix='التقدم:', suffix='اكتمل', length=50)
    
    # دالة استدعاء التقدم
    def update_progress(progress):
        target_index = progress.get('target_index', 0)
        scanner_index = progress.get('scanner_index', 0)
        target_count = progress.get('target_count', 0)
        scanner_count = progress.get('scanner_count', 0)
        
        # حساب التقدم الإجمالي
        total_progress = target_index * scanner_count + scanner_index + 1
        
        # تحديث شريط التقدم
        progress_bar.update(total_progress)
    
    # بدء الفحص
    print(f"بدء فحص {len(targets)} هدف باستخدام {len(scanner.scanners)} ماسح...")
    scan_results = scanner.scan(update_progress)
    
    # إنشاء التقرير
    output_file = args.output
    if not output_file:
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f"report_{timestamp}.{args.report_type}"
    
    report_file = scanner.generate_report(args.report_type, output_file)
    print(f"تم إنشاء التقرير: {report_file}")
    
    # فتح التقرير
    if args.report_type == 'html':
        scanner.open_report(report_file)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\nتم إلغاء الفحص بواسطة المستخدم")
    except Exception as e:
        print(f"خطأ: {str(e)}")
        traceback.print_exc()
